// ==UserScript==
// @name         POS hourly Refresh
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Auto-refresh POS at specific times with 5s toast countdown; ESC cancels
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

// ==UserScript==
// @name         POS Auto Refresh Toast (Manual Position)
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Auto-refresh POS at specific times with 5s toast countdown; ESC cancels; manual toast position
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';

    const refreshTimes = ["08:08:08",
                          "09:09:09",
                          "10:10:10",
                          "11:11:11",
                          "12:12:12",
                          "14:14:14",
                          "15:15:15",
                          "16:16:16",
                          "17:17:17",
                          "18:18:18",
                          "19:19:19",
                          "20:20:20"
                         ]; // scheduled refresh HH:MM:SS
    const countdownSeconds = 7;

    // ======= MANUAL POSITION =======
    const toastPosition = {
    //    top: '100px',     // change this
     //   right: '111px',    // change this
        bottom: '19px', // optional alternative
        left: '1203px',   // optional alternative
    };

    let countdownInterval = null;
    let countdownToast = null;
    let stopped = false;

    function removeToast() {
        if (countdownToast) {
            countdownToast.remove();
            countdownToast = null;
        }
    }

    function cancelRefresh() {
        stopped = true;
        if (countdownInterval) clearInterval(countdownInterval);
        removeToast();
        console.log('POS auto-refresh canceled by ESC');
    }

    window.addEventListener('keydown', e => {
        if (e.key === 'Escape') cancelRefresh();
    }, { capture: true, passive: true });

    function showToast() {
        if (countdownToast || stopped) return;

        countdownToast = document.createElement('div');
        Object.assign(countdownToast.style, {
            position: 'fixed',
            background: 'rgba(0,0,0,0.85)',
            color: '#fff',
            padding: '12px 20px',
            borderRadius: '6px',
            fontSize: '22px',
            fontWeight: '700',
            zIndex: 99999,
            pointerEvents: 'auto',
            boxShadow: '0 4px 12px rgba(0,0,0,0.4)',
            ...toastPosition, // apply manual position
        });
        document.body.appendChild(countdownToast);

        let secLeft = countdownSeconds;
        countdownToast.textContent = `refresh in ${secLeft}s`;

        countdownInterval = setInterval(() => {
            if (stopped) return clearInterval(countdownInterval);

            secLeft--;
            if (secLeft <= 0) {
                clearInterval(countdownInterval);
                removeToast();
                location.reload();
            } else {
                countdownToast.textContent = `refresh in ${secLeft}s`;
            }
        }, 1000);
    }

    function getCurrentHHMMSS() {
        const now = new Date();
        return `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}:${String(now.getSeconds()).padStart(2,'0')}`;
    }

    setInterval(() => {
        if (stopped) return;
        const hhmmss = getCurrentHHMMSS();
        if (refreshTimes.includes(hhmmss)) {
            showToast();
        }
    }, 500);

})();