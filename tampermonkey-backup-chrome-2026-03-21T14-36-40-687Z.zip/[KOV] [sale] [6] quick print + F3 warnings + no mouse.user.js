// ==UserScript==
// @name         [KOV] [sale] [6] quick print + F3 warnings + no mouse
// @namespace    http://tampermonkey.net/
// @version      2.6
// @description  Skip 'mã chưa vào' warning when typing manually; show only for scanner input; includes quick print, toast, success, focus guard + disable mouse until moved
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    /*** === CONFIG === ***/
    const scanDelay = 30; // ms between chars = scanner input

    const FOCUS_GUARD_DURATION = 1000;

    const errorSoundUrl = "https://github.com/tasuaongvang/kov-count/raw/refs/heads/main/missed.mp3"
    const toastSoundUrl = "https://github.com/tasuaongvang/kov-count/raw/refs/heads/main/mncc.mp3"
    const successDuration = 1800;
    const PRINT_COOLDOWN = 3000;

    /*** === FLAGS ===***/
    let printing = false;
    let lastPrint = 0;

    /*** === HELPERS ===***/
    function playSound(url) {
        const audio = new Audio(url);
        audio.play().catch(() => {});
    }

    function getSearchInput() {
        return document.querySelector("input[placeholder*='F3'], input[placeholder*='F7']") ||
               [...document.querySelectorAll("input")].find(i =>
                   i.placeholder && (i.placeholder.includes("F3") || i.placeholder.includes("F7"))
               );
    }

    function createBox(id, bgColor, blur, text) {
        const box = document.createElement('div');
        box.id = id;
        Object.assign(box.style, {
            position: 'fixed',
            padding: '0',
            background: bgColor,
            color: '#000',
            fontSize: '20px',
            borderRadius: '6px',
            boxShadow: '0 2px 6px rgba(0,0,0,0.2)',
            zIndex: '99999',
            opacity: '1',
            transition: 'opacity 0.5s ease',
            textAlign: 'right',
            pointerEvents: 'none',
            backdropFilter: `blur(${blur}px)`,
            WebkitBackdropFilter: `blur(${blur}px)`
        });
        box.textContent = text;
        document.body.appendChild(box);
        return box;
    }

    function positionBox(box) {
        const input = document.getElementById('productSearchInput') || getSearchInput();
        if (!input) return;
        const rect = input.getBoundingClientRect();
        Object.assign(box.style, {
            top: `${rect.top + window.scrollY}px`,
            left: `${rect.left + window.scrollX}px`,
            width: `${rect.width}px`,
            height: `${rect.height}px`,
            lineHeight: `${rect.height}px`
        });
    }

    // UI boxes
    const warningBox = createBox('scanner-warning', 'rgba(255,77,79,0.25)', 2, 'mã chưa vào ⚠️ㅤㅤㅤㅤㅤ');
    const successBox = createBox('scanner-success', 'rgba(82,196,26,0.35)', 4, 'vào rồi ✔️ㅤㅤㅤㅤㅤ');
    positionBox(warningBox);
    positionBox(successBox);

    function showBox(box, duration = 3000) {
        positionBox(box);
        box.style.opacity = '1';
        box.style.pointerEvents = 'auto';
        if (duration > 0) {
            setTimeout(() => {
                box.style.opacity = '0';
                box.style.pointerEvents = 'none';
            }, duration);
        }
    }

    /*** === CUSTOM TOAST ===***/
    function showCustomToast(message) {
        const oldToast = document.getElementById('custom-toast');
        if (oldToast) oldToast.remove();

        const toast = createBox('custom-toast', 'rgba(255, 0, 0, 0.4)', 3, message);
        positionBox(toast);
        toast.style.opacity = '1';
        playSound(toastSoundUrl);

        const input = getSearchInput();
        if (input) {
            const hideToast = () => {
                toast.style.opacity = '0';
                input.removeEventListener('keydown', hideToast);
                input.removeEventListener('input', hideToast);
            };
            input.addEventListener('keydown', hideToast);
            input.addEventListener('input', hideToast);
        }
    }

    const observerToast = new MutationObserver(mutations => {
        mutations.forEach(mutation => {
            mutation.addedNodes.forEach(node => {
                if (node.nodeType === 1 && node.id === 'toast-container') {
                    const messageNode = node.querySelector('.toast-message');
                    if (messageNode && messageNode.textContent.includes('Không tìm thấy sản phẩm')) {
                        showCustomToast('hông có mã này bé ơi 😂ㅤㅤㅤㅤㅤ');
                        node.remove();
                    }
                }
            });
        });
    });
    observerToast.observe(document.body, { childList: true, subtree: true });

    /*** === SCANNER WARNING + SUCCESS ===***/
    let buffer = "";
    let bufferStartTime = 0;
    let lastKeyTime = 0;
    let warningVisible = false;
    let showSuccessAfterWarning = false;
    let successTimeout;

    function showWarning() {
        positionBox(warningBox);
        warningBox.style.opacity = '1';
        warningBox.style.pointerEvents = 'auto';
        warningVisible = true;
        showSuccessAfterWarning = true;
        playSound(errorSoundUrl);
        const input = getSearchInput();
        if (input) { input.focus(); input.select(); }
    }

    function hideWarning() {
        warningBox.style.opacity = '0';
        warningBox.style.pointerEvents = 'none';
        warningVisible = false;
    }

    function showSuccess() {
        positionBox(successBox);
        successBox.style.opacity = '1';
        successBox.style.pointerEvents = 'auto';
        clearTimeout(successTimeout);
        successTimeout = setTimeout(() => {
            successBox.style.opacity = '0';
            successBox.style.pointerEvents = 'none';
        }, successDuration);
    }

    function hideWarningOnAction() {
        if (warningVisible) hideWarning();
    }
    document.addEventListener("keydown", hideWarningOnAction);
    document.addEventListener("mousedown", hideWarningOnAction);

    /*** === MAIN KEYDOWN LISTENER ===***/
    document.addEventListener("keydown", function (e) {
        if (!e.isTrusted || printing) return;

        const now = Date.now();
        const isPrintableChar = e.key && e.key.length === 1;

        if (isPrintableChar) {
            if (now - lastKeyTime > scanDelay || buffer === "") {
                buffer = e.key;
                bufferStartTime = now;
            } else {
                buffer += e.key;
            }
            lastKeyTime = now;
            return;
        }

        if (e.key === "Enter") {
            if (!buffer) {
                lastKeyTime = now;
                return;
            }

            const totalDuration = now - bufferStartTime;
            const avgPerChar = totalDuration / Math.max(1, buffer.length);
            const looksLikeCode = buffer.length >= 4;
            const fastEnough = avgPerChar < scanDelay;
            const printableOnly = /^[\x20-\x7E]+$/.test(buffer);
            const isScannerEnter = looksLikeCode && fastEnough && printableOnly;
            const manualTyping = !isScannerEnter;

            const active = document.activeElement;
            const isInputActive =
                active && (active.tagName === "INPUT" || active.tagName === "TEXTAREA") &&
                active.type !== "button";

            const isKiotSearch =
                active &&
                (active.placeholder?.includes("F3") ||
                 active.placeholder?.includes("F7") ||
                 active.className.includes("search") ||
                 active.className.includes("k-input"));

            if (manualTyping) {
                console.log('[KOV] Enter from manual typing → skip warning');
                const input = getSearchInput();
                if (input) { input.focus(); input.select(); }
                buffer = "";
                lastKeyTime = now;
                return;
            }

            if (!isInputActive || !isKiotSearch) {
                showWarning();
            } else if (isKiotSearch && showSuccessAfterWarning) {
                hideWarning();
                showSuccess();
                showSuccessAfterWarning = false;
            }

            const input = getSearchInput();
            if (input) {
                input.focus();
                input.select();

                const startTime = Date.now();
                const focusGuard = setInterval(() => {
                    if (Date.now() - startTime > FOCUS_GUARD_DURATION) {
                        clearInterval(focusGuard);
                        return;
                    }
                    if (document.activeElement !== input) {
                        input.focus();
                        input.select();
                    }
                }, 100);
            }

            buffer = "";
            lastKeyTime = now;
            return;
        }

        buffer = "";
        lastKeyTime = now;
    });

    /*** === QUICK PRINT Ctrl+` ===***/
    (function quickPrint() {
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.key === '`') {
                e.preventDefault();
                const now = Date.now();
                if (now - lastPrint < PRINT_COOLDOWN) return;
                lastPrint = now;
                printing = true;

                const printBtn = document.querySelector('#printTransaction, #printOrder');
                if (!printBtn) {
                    console.log('Print button not found on this page');
                    printing = false;
                    return;
                }

                printBtn.click();
                setTimeout(() => { printing = false; }, PRINT_COOLDOWN);
            }
        });
    })();

    /*** === DISABLE Ctrl+P ===***/
    (function disableCtrlP() {
        window.addEventListener('keydown', function(e) {
            if (e.ctrlKey && (e.key === 'p' || e.key === 'P')) {
                e.preventDefault();
                e.stopPropagation();
                console.log('Ctrl+P blocked on this page');
            }
        }, true);
    })();

    /*** === EXTRA SECTION: Disable Mouse Until Moved (Every Typing) ===***/
 (function disableMouseUntilMoved() {
    let blocked = false;
    let unblockHandler = null;
    let autoUnblockTimer = null;

    function blockMouse() {
        if (blocked) return;
        blocked = true;

        document.body.style.cursor = 'none';

        const blocker = document.createElement('div');
        blocker.id = 'mouseBlocker';
        Object.assign(blocker.style, {
            position: 'fixed',
            inset: '0',
            zIndex: '999999',
            background: 'transparent',
            cursor: 'none'
        });
        document.body.appendChild(blocker);

        console.log('[KOV] Mouse visually disabled — move your physical mouse to restore.');

        unblockHandler = () => unblockMouse();
        window.addEventListener('mousemove', unblockHandler, { once: true });

        // Auto-unhide safety (15 s)
        clearTimeout(autoUnblockTimer);
        autoUnblockTimer = setTimeout(unblockMouse, 15000);
    }

    function unblockMouse() {
        const blocker = document.getElementById('mouseBlocker');
        if (blocker) blocker.remove();
        document.body.style.cursor = '';
        blocked = false;
        clearTimeout(autoUnblockTimer);
        console.log('[KOV] Mouse re-enabled.');
    }

    function isPrintableKey(e) {
        return e.key.length === 1 && !e.ctrlKey && !e.altKey && !e.metaKey;
    }

    function attachTypingListener() {
        const input = document.querySelector('#productSearchInput') || getSearchInput();
        if (!input) return false;

        input.addEventListener('keydown', (e) => {
            // Only hide if real typing in F3/F7 box
            if (document.activeElement !== input) return;
            if (!isPrintableKey(e)) return;
            blockMouse();
        });

        console.log('[KOV] Safe mouse disable listener attached to search input.');
        return true;
    }

    const waitInput = setInterval(() => {
        if (attachTypingListener()) clearInterval(waitInput);
    }, 500);
})();



})();
