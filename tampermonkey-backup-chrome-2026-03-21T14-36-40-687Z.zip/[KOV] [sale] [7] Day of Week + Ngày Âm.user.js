// ==UserScript==
// @name         [KOV] [sale] [7] Day of Week + Ngày Âm
// @namespace    http://tampermonkey.net/
// @version      5.0
// @description  Vietnamese lunar date using built-in calendar (no bugs)
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
'use strict';

/* =========================
   BUILT-IN LUNAR CALENDAR
========================= */

const lunarFormatter = new Intl.DateTimeFormat('vi-VN-u-ca-chinese', {
    day: 'numeric',
    month: 'numeric',
    timeZone: 'Asia/Ho_Chi_Minh'
});

const weekdayFormatter = new Intl.DateTimeFormat('vi-VN', {
    weekday: 'long',
    timeZone: 'Asia/Ho_Chi_Minh'
});

function getLunarVN() {
    const now = new Date();

    const parts = lunarFormatter.formatToParts(now);

    let day, month;
    for (const p of parts) {
        if (p.type === 'day') day = p.value;
        if (p.type === 'month') month = p.value;
    }

    const weekday = weekdayFormatter.format(now);

    return { day, month, weekday };
}

/* =========================
   UI UPDATE
========================= */


function updatePlaceholder() {

    const input = document.querySelector('#productSearchInput');
    if (!input) return;

    const lunar = getLunarVN();

    /* ---------- weekday rule ---------- */
    let weekday = lunar.weekday;
    if (weekday.toLowerCase() === "chủ nhật") {
        weekday = "Thứ Tám";
    }

    /* ---------- lunar day rule ---------- */
    let lunarDayText = lunar.day;
    if (lunar.day === "15") {
        lunarDayText = "Rằm";
    }

    /* ---------- lunar month names ---------- */
    let lunarMonthText = lunar.month;

    if (lunar.month === "1") {
        lunarMonthText = "Giêng";
    } else if (lunar.month === "12") {
        lunarMonthText = "Chạp";
    }

    input.placeholder =
        `nay ${weekday} (âm ${lunarDayText} tháng ${lunarMonthText}) - F3 tìm hàng hóa`;
}


/* =========================
   SPA SAFE WATCHER
========================= */

new MutationObserver(updatePlaceholder)
    .observe(document.body, { childList: true, subtree: true });

setInterval(updatePlaceholder, 60000);

console.log('[KOV Lunar FINAL ✔] running');

})();