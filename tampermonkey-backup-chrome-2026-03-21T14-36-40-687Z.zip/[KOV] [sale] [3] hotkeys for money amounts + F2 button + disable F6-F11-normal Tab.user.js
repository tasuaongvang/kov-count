// ==UserScript==
// @name         [KOV] [sale] [3] hotkeys for money amounts + F2 button + disable F6/F11/normal Tab
// @namespace    http://tampermonkey.net/
// @version      3.1
// @match        https://cov.kiotviet.vn/sale/*
// @description  Ctrl+Numpad=100k..900k / Numpad0=1M, Shift+Numpad=1.1M..1.9M / Shift+0=2M; Tab+1..9=10k..90k; Tab+0=0; F2 clicks change-type button; disable F6/F11 and normal Tab
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const INPUT_SELECTOR  = '#payingAmtInvoice';
    const SEARCH_SELECTOR = '#productSearchInput';
let tabHeld = false;
    let rightCtrlHeld = false;
    document.addEventListener('keydown', e => { if (e.code === 'ControlRight') rightCtrlHeld = true;  }, true);
    document.addEventListener('keyup',   e => { if (e.code === 'ControlRight') rightCtrlHeld = false; }, true);
    // ── Native input value setter (bypasses Angular's value hijack) ──────────────
    const nativeSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;

    // ── Payment type detection ────────────────────────────────────────────────────
    function isCashPayment() {
        const radios = document.querySelectorAll('input[type="radio"]');
        for (const r of radios) {
            const ngm = r.getAttribute('ng-model') || '';
            if (/singlePaymentType/.test(ngm) && r.checked) {
                return Number(r.value) === 0 || Number(r.getAttribute('ng-value')) === 0;
            }
        }
        const cashRadio = document.querySelector('input[type=radio][value="0"], input[type=radio][ng-value="0"]');
        if (cashRadio) return cashRadio.checked;
        try {
            const scope = window.angular?.element(document.body)?.scope?.();
            const t = scope?.$root?.activeCart?.singlePaymentType;
            if (t !== undefined) return t === 0;
        } catch (_) {}
        return true;
    }

    // ── Apply amount ─────────────────────────────────────────────────────────────
function applyAmount(amount) {
        const input = document.querySelector(INPUT_SELECTOR);
        if (!input) return;

        const raw       = String(Math.round(amount));
        const formatted = Math.round(amount).toLocaleString('en-US'); // 60,000

        // Step 1: raw value → Angular reads and updates its model
// Tell the debt script: this is just a hotkey setup, not a real payment
        window._gmnHotkeyActive = true;
        clearTimeout(window._gmnHotkeyTimer);
        window._gmnHotkeyTimer = setTimeout(() => { window._gmnHotkeyActive = false; }, 3000);

        nativeSetter.call(input, raw);
        input.dispatchEvent(new Event('input',  { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));

        // Step 2: swap to formatted display only — no extra events
        nativeSetter.call(input, formatted);

        const prev = input.style.boxShadow;
        input.style.boxShadow = '0 0 0 3px rgba(46,204,113,0.55)';
        setTimeout(() => { input.style.boxShadow = prev; }, 350);

        setTimeout(() => {
            const f3 = document.querySelector(SEARCH_SELECTOR);
            if (f3) { f3.focus(); f3.select(); }
        }, 300);
    }

    // ── Amount calculation ────────────────────────────────────────────────────────
    function calcAmount(keyNum, useShift) {
        if (useShift) return keyNum === 0 ? 2_000_000 : 1_000_000 + keyNum * 100_000;
        return keyNum === 0 ? 1_000_000 : keyNum * 100_000;
    }

// ── Left Ctrl + Numpad (100k–1M) / Right Ctrl + Numpad (1.1M–2M) ────────────
    document.addEventListener('keydown', e => {
        if (!e.ctrlKey) return;
        if (!isCashPayment()) return;

        const m = /^Numpad([0-9])$/.exec(e.code || '');
        const keyNum = m ? Number(m[1])
            : (e.location === 3 && /^[0-9]$/.test(e.key)) ? Number(e.key)
            : null;
        if (keyNum === null) return;

        e.preventDefault();
        e.stopImmediatePropagation();
        applyAmount(calcAmount(keyNum, rightCtrlHeld));
    }, true);

    // ── Tab + digit combos ────────────────────────────────────────────────────────
    document.addEventListener('keydown', e => {
        if (e.key === 'Tab') {
            e.preventDefault();
            e.stopImmediatePropagation();
            tabHeld = true;
            return;
        }
        if (tabHeld && /^[0-9]$/.test(e.key)) {
            if (!isCashPayment()) return;
            e.preventDefault();
            e.stopImmediatePropagation();
            const keyNum = Number(e.key);
            applyAmount(keyNum === 0 ? 0 : keyNum * 10_000);
        }
    }, true);

    document.addEventListener('keyup', e => {
        if (e.key === 'Tab') tabHeld = false;
    }, true);

    // ── F2 / F6 / F11 ────────────────────────────────────────────────────────────
    document.addEventListener('keydown', e => {
        if (e.key === 'F2') {
            e.preventDefault();
            e.stopImmediatePropagation();
            document.querySelector('button.btn-change-type')?.click();
        } else if (e.key === 'F6' || e.key === 'F11') {
            e.preventDefault();
            e.stopImmediatePropagation();
        }
    }, true);

})();