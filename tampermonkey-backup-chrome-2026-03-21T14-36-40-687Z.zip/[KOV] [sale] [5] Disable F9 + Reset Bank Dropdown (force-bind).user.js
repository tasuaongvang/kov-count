// ==UserScript==
// @name         [KOV] [sale] [5] Disable F9 + Reset Bank Dropdown (force-bind)
// @namespace    http://tampermonkey.net/
// @version      1.9
// @description  Disable Thanh toán/Đặt hàng if bank dropdown empty, F9 block + beep/shake + reset bank dropdown to first real bank (force-bind)
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const BUTTON_IDS = ['saveTransaction', 'saveOrder'];
    let isDisabled = false;
    let isActionBeeping = false; // throttle action beep/shake

    /* ========================
       Beep sound + shake CSS
       ======================== */
    function beep() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = "square";
            osc.frequency.value = 520;
            gain.gain.value = 0.15;
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            setTimeout(() => osc.stop(), 130);
        } catch {}
    }

    const css = `
        .btn-disabled-shake {
            animation: shake 0.28s ease-in-out;
        }
        @keyframes shake {
            0% { transform: translateX(0); }
            25% { transform: translateX(-4px); }
            50% { transform: translateX(4px); }
            75% { transform: translateX(-2px); }
            100% { transform: translateX(0); }
        }
        #saveTransaction, #saveOrder {
            transition: opacity 0.25s ease, transform 0.25s ease;
        }
    `;
    const style = document.createElement("style");
    style.textContent = css;
    document.head.appendChild(style);

    /* ========================
       Bank Input detection
       ======================== */
    function getBankInput() {
        const bankDropdownWrap = document.querySelector('#bankAccountDropdown');
        if (!bankDropdownWrap) return null;
        const inputSpan = bankDropdownWrap.closest('span.k-widget')?.querySelector('span.k-input');
        return inputSpan || null;
    }

    function updateButtonsState() {
        const bankInput = getBankInput();
        if (!bankInput) return;

        // Disabled if empty OR placeholder "tài khoản nhận"
        isDisabled = bankInput.textContent.trim() === '' || bankInput.textContent.toLowerCase().includes("tài khoản nhận");

        BUTTON_IDS.forEach(id => {
            const btn = document.getElementById(id);
            if (!btn) return;
            btn.disabled = isDisabled;
            btn.style.opacity = isDisabled ? 0.5 : 1;
            btn.style.cursor = isDisabled ? 'not-allowed' : '';
            btn.title = isDisabled ? 'Chọn tài khoản trước khi thanh toán/đặt hàng' : '';
        });
    }

    // Beep + shake feedback
    function actionFeedback(btn) {
        if (!btn || isActionBeeping) return;
        isActionBeeping = true;
        btn.classList.add('btn-disabled-shake');
        beep();
        setTimeout(() => {
            btn.classList.remove('btn-disabled-shake');
            isActionBeeping = false;
        }, 280);
    }

    document.addEventListener('click', (e) => {
        BUTTON_IDS.forEach(id => {
            const btn = document.getElementById(id);
            if (btn && isDisabled && e.target.closest(`#${id}`)) {
                e.preventDefault();
                actionFeedback(btn);
            }
        });
    });

    window.addEventListener('keydown', (e) => {
        if (isDisabled && e.key === 'F9') {
            e.preventDefault();
            e.stopPropagation();
            BUTTON_IDS.forEach(id => {
                const btn = document.getElementById(id);
                actionFeedback(btn);
            });
            console.log("F9 blocked — bank not selected");
        }
    }, true);

    /* ========================
       Reset Kendo Bank Dropdown (force-bind selection)
       ======================== */
    function resetBankDropdownKendo() {
        const dropdownEl = document.querySelector('#bankAccountDropdown');
        if (!dropdownEl) return;

        // ensure jQuery + kendo available
        if (typeof $ === 'undefined' || !$.fn) return;
        const kendoWidget = $(dropdownEl).data('kendoDropDownList');
        if (!kendoWidget) return;

        const firstRealItem = kendoWidget.dataSource.at(1); // skip placeholder
        if (firstRealItem) {
            try {
                // 1) select the item by index (ensures internal selection state)
                kendoWidget.select(1);

                // 2) set the widget value (Id) so Kendo model updates
                kendoWidget.value(firstRealItem.Id);

                // 3) trigger Kendo change handlers
                if (typeof kendoWidget.trigger === 'function') {
                    kendoWidget.trigger('change');
                } else if (typeof kendoWidget._change === 'function') {
                    // fallback to internal change call if available
                    try { kendoWidget._change(); } catch(e) {}
                }

                // 4) also fire a native change event on the original DOM element (for non-Kendo bindings)
                try {
                    const evt = new Event('change', { bubbles: true });
                    dropdownEl.dispatchEvent(evt);

                    // If jQuery present, also trigger jQuery change
                    if (typeof $ === 'function') {
                        $(dropdownEl).trigger('change');
                    }
                } catch (e) {
                    // ignore dispatch errors
                }

                console.log('Bank dropdown reset (force-bound) to first real bank:', firstRealItem.Account, firstRealItem.Id);
            } catch (err) {
                console.log('resetBankDropdownKendo error:', err);
            }
        }
    }

    /* ========================
       MutationObserver for dynamic content
       ======================== */
    const observer = new MutationObserver((mutations) => {
        updateButtonsState(); // update buttons
        mutations.forEach(mutation => {
            mutation.addedNodes.forEach(node => {
                if (node.nodeType === 1 && node.querySelector) {
                    if (node.querySelector('#bankAccountDropdown')) {
                        // wait a bit for Kendo to initialize then force-bind
                        setTimeout(resetBankDropdownKendo, 120);
                    }
                }
            });
        });
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // Initial setup
    setTimeout(() => {
        updateButtonsState();
        resetBankDropdownKendo();
    }, 700);

    // Periodic button check
    setInterval(updateButtonsState, 500);
        /* ========================
       Auto beep+shake every second
       when bank = "tài khoản nhận"
       ======================== */
    setInterval(() => {
        if (!isDisabled) return; // only when placeholder bank is active

        BUTTON_IDS.forEach(id => {
            const btn = document.getElementById(id);
            if (btn) actionFeedback(btn); // reuse your shake+beep function
        });

    }, 1000); // 1 second

/* ========================
   Pricebook ↔ Payment Match
   ======================== */

let isPricebookMismatch = false;

// read pricebook text (from k-input)
function getPricebookValue() {
    const el = document.querySelector('#pricebook')?.closest('.k-widget')?.querySelector('.k-input span');
    if (!el) return null;
    return el.textContent.trim();
}

// read payment method (0=cash,2=transfer)
function getPaymentMethod() {
    const checked = document.querySelector('.form-check-input[ng-model="$root.activeCart.singlePaymentType"]:checked');
    if (!checked) return null;
    return checked.value; // "0", "2", "1", etc
}
    function isPaymentUIVisible() {
    const paymentContainer = document.querySelector('.form-check-methods');
    if (!paymentContainer) return false;
    return paymentContainer.offsetParent !== null; // visible?
}


function checkPricebookPaymentMatch() {
    const pb = getPricebookValue();
    const pay = getPaymentMethod();

// if payment UI is hidden, disable mismatch check
if (!isPaymentUIVisible()) {
    isPricebookMismatch = false;
    return;
}

// if UI visible but data missing, also no mismatch
if (!pb || !pay) {
    isPricebookMismatch = false;
    return;
}


    // matching rules:
    // "Bảng giá chung" → Transfer (2)
    // "Tiền mặt" → Cash (0)
    let mismatch = false;

    if (pb === "Bảng giá chung" && pay !== "2") mismatch = true;
    if (pb === "Tiền mặt" && pay !== "0") mismatch = true;

    isPricebookMismatch = mismatch;
}

// extend your btn state updater
// unified button state controller
updateButtonsState = function () {
    const bankInput = getBankInput();
    let bankEmpty = false;

    if (bankInput) {
        bankEmpty = bankInput.textContent.trim() === '' ||
                    bankInput.textContent.toLowerCase().includes("tài khoản nhận");
    }

    checkPricebookPaymentMatch(); // updates isPricebookMismatch

    const finalDisabled = bankEmpty || isPricebookMismatch;

    BUTTON_IDS.forEach(id => {
        const btn = document.getElementById(id);
        if (!btn) return;

        btn.disabled = finalDisabled;
        btn.style.opacity = finalDisabled ? 0.5 : 1;
        btn.style.cursor = finalDisabled ? 'not-allowed' : '';

        if (bankEmpty)
            btn.title = 'Chọn tài khoản trước khi thanh toán/đặt hàng';
        else if (isPricebookMismatch)
            btn.title = 'Sai bảng giá ↔ sai phương thức thanh toán';
        else
            btn.title = '';
    });
};


/* ========================
   Auto beep+shake on mismatch
   ======================== */
setInterval(() => {
if (!isPricebookMismatch || !isPaymentUIVisible()) return;

    BUTTON_IDS.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) actionFeedback(btn);
    });
}, 1000);





})();
