// ==UserScript==
// @name         NumPad + CapsLock warning!
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  Warn when NumLock is OFF or CapsLock is ON
// @match        https://*/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function () {
  'use strict';

  // --- Create popup element ---
  const popup = document.createElement('div');
  popup.id = 'keyboard-warning-popup';
  Object.assign(popup.style, {
    position: 'fixed',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    background: 'rgba(0, 0, 0, 0.85)',
    color: 'white',
    padding: '20px 40px',
    fontSize: '24px',
    fontWeight: 'bold',
    borderRadius: '12px',
    zIndex: '999999',
    textAlign: 'center',
    display: 'none',
    boxShadow: '0 0 15px rgba(0,0,0,0.4)',
  });

  document.body.appendChild(popup);

  // --- Track states ---
  let numLockOn = true;
  let capsLockOn = false;

  function updatePopup() {
    if (!numLockOn) {
      popup.textContent = 'NUMPAD IS OFF';
      popup.style.display = 'block';
    } else if (capsLockOn) {
      popup.textContent = 'CAPSLOCK IS ON';
      popup.style.display = 'block';
    } else {
      popup.style.display = 'none';
    }
  }

function checkLocks(e) {
  if (!e.isTrusted) return; // ← FIX

  const newNum = e.getModifierState('NumLock');
  const newCaps = e.getModifierState('CapsLock');

  if (newNum !== numLockOn || newCaps !== capsLockOn) {
    numLockOn = newNum;
    capsLockOn = newCaps;
    updatePopup();
  }
}

  // --- Attach listeners ---
  document.addEventListener('keydown', checkLocks, true);
  document.addEventListener('keyup', checkLocks, true);

  console.log('[Keyboard Monitor] Running');
})();