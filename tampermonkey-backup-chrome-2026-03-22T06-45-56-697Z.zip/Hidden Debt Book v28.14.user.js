// ==UserScript==
// @name         Hidden Debt Book v28.14
// @namespace    http://tampermonkey.net/
// @version      28.14
// @description  Hidden Debt Book — sổ đối soát chuyển khoản. Ctrl+K+K để mở/đóng.
// @author       Combined
// @match        https://*.kiotviet.vn/sale/*
// @grant        GM_addStyle
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_xmlhttpRequest
// @grant        unsafeWindow
// @connect      raw.githubusercontent.com
// @connect      api.github.com
// @require      https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js
// ==/UserScript==

(function() {
    'use strict';

    // ─── CONFIG ──────────────────────────────────────────────────────────────────
    // Vị trí QR theo chiều ngang trong vùng ⅔ bên trái màn hình.
    // 50 = giữa vùng ⅔ (mặc định), 0 = sát trái, 100 = sát phải vùng ⅔
    const QR_POSITION_PCT = 50;
    // ─────────────────────────────────────────────────────────────────────────────


    // Cập nhật URL ở đây nếu cần thay file. Bấm nút ↻ Sync để tải lại vào storage.
    const ASSET_ICON_BEE = {
        key: 'gmn_asset_icon_bee',
        url: 'https://raw.githubusercontent.com/tasuaongvang/cov/3e0b04046371f0ac22385aed78c7fa2db69a3e61/icon_bee.PNG',
        mime: 'image/png',
    };
    const ASSET_SKELETON = {
        key: 'gmn_asset_skeleton',
        url: 'https://png.pngtree.com/png-clipart/20230913/original/pngtree-cute-skeleton-png-image_11078487.png',
        mime: 'image/png',
    };
    const ALL_ASSETS = [ASSET_ICON_BEE, ASSET_SKELETON];

    // Trả về data URI từ cache, fallback về URL gốc nếu chưa sync
    function assetSrc(asset) {
        const b64 = GM_getValue(asset.key, null);
        return b64 ? 'data:' + asset.mime + ';base64,' + b64 : asset.url;
    }

    // Fetch 1 asset về, lưu vào GM storage
    function syncAsset(asset, onDone) {
        GM_xmlhttpRequest({
            method: 'GET',
            url: asset.url + '?t=' + Date.now(),
            responseType: 'arraybuffer',
            onload(res) {
                try {
                    const bytes = new Uint8Array(res.response);
                    let b64 = '';
                    const chunk = 8192;
                    for (let i = 0; i < bytes.length; i += chunk) {
                        b64 += String.fromCharCode(...bytes.subarray(i, i + chunk));
                    }
                    b64 = btoa(b64);
                    GM_setValue(asset.key, b64);
                    if (onDone) onDone(true);
                } catch(e) { if (onDone) onDone(false); }
            },
            onerror() { if (onDone) onDone(false); }
        });
    }

    // Sync toàn bộ assets, gọi onDone(okCount, totalCount)
    function syncAllAssets(onDone) {
        let ok = 0, done = 0;
        ALL_ASSETS.forEach(a => syncAsset(a, (success) => {
            if (success) ok++;
            if (++done === ALL_ASSETS.length && onDone) onDone(ok, ALL_ASSETS.length);
        }));
    }
    // ─────────────────────────────────────────────────────────────────────────────


    // ─── CONTACTS ────────────────────────────────────────────────────────────────
    const CONTACTS_URL = 'https://raw.githubusercontent.com/tasuaongvang/cov/refs/heads/main/bakist.txt';
    const CONTACTS_KEY = 'gmn_contacts_cache';
    const CONTACTS_TS  = 'gmn_contacts_ts';

    function parseTxt(raw) {
        return raw.split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('#'))
            .map(l => {
                const p = l.split('|').map(s => s.trim());
return { code: p[0]||'', name: p[1]||'', bankId: (p[2]||'').toUpperCase(), accountNo: p[3]||'' };
            }).filter(c => c.code && c.bankId && c.accountNo);
    }
    function syncContacts(onDone) {
        GM_xmlhttpRequest({
            method: 'GET', url: CONTACTS_URL + '?t=' + Date.now(),
            onload(res) {
                try {
                    const data = parseTxt(res.responseText);
                    if (!data.length) throw new Error('empty');
                    GM_setValue(CONTACTS_KEY, data);
                    GM_setValue(CONTACTS_TS, Date.now());
                    if (onDone) onDone(true);
                } catch(e) { if (onDone) onDone(false); }
            },
            onerror() { if (onDone) onDone(false); }
        });
    }
    function getContacts() { return GM_getValue(CONTACTS_KEY, []); }
    function lookupByCode(code) { return getContacts().find(c => c.code.toLowerCase() === (code||'').toLowerCase()) || null; }
    if (getContacts().length === 0) syncContacts();

    // ─── GITHUB BACKUP CONFIG ────────────────────────────────────────────────────
    // Fill in these values to enable GitHub backup / restore.
    // Leave GH_TOKEN empty ('') to disable all GitHub backup features.
    const GH_TOKEN              = '';                   // GitHub PAT — fine-grained, Contents: read+write
    const GH_OWNER              = 'tasuaongvang';       // GitHub username / org
    const GH_REPO               = 'cov';                // repository name
    const GH_FOLDER             = 'backups';            // folder inside repo (no slashes)
    const GH_MAX_FILES          = 10;                   // max backup files to keep (oldest deleted)
    const GH_INTERVAL_HOURS     = 6;                    // auto-export every N hours (0 = off)
    // ─────────────────────────────────────────────────────────────────────────────

    const GH_LAST_EXPORT_KEY = 'gmn_gh_last_export';

    function ghEnabled() { return GH_TOKEN.trim() !== ''; }

    function ghApi(method, path, body, onDone) {
        GM_xmlhttpRequest({
            method,
            url: 'https://api.github.com/repos/' + GH_OWNER + '/' + GH_REPO + '/contents/' + GH_FOLDER + (path ? '/' + path : ''),
            headers: {
                'Authorization': 'Bearer ' + GH_TOKEN,
                'Accept': 'application/vnd.github+json',
                'Content-Type': 'application/json',
                'X-GitHub-Api-Version': '2022-11-28'
            },
            data: body ? JSON.stringify(body) : undefined,
            onload(res) {
                try {
                    const data = JSON.parse(res.responseText);
                    onDone(res.status >= 200 && res.status < 300, data);
                } catch(e) { onDone(false, null); }
            },
            onerror() { onDone(false, null); }
        });
    }

    // fetch list of backup files, sorted newest-first
    function ghFetchList(onDone) {
        if (!ghEnabled()) { onDone(false, []); return; }
        ghApi('GET', '', null, (ok, data) => {
            if (!ok || !Array.isArray(data)) { onDone(false, []); return; }
            const files = data
                .filter(f => f.type === 'file' && f.name.endsWith('.json'))
                .sort((a, b) => b.name.localeCompare(a.name));
            onDone(true, files);
        });
    }

    // load a specific file by name, return parsed JSON
    function ghLoadFile(name, onDone) {
        if (!ghEnabled()) { onDone(false, null); return; }
        ghApi('GET', name, null, (ok, data) => {
            if (!ok || !data.content) { onDone(false, null); return; }
            try {
                const json = JSON.parse(atob(data.content.replace(/\s/g, '')));
                onDone(true, json, data.content.replace(/\s/g, ''));
            } catch(e) { onDone(false, null); }
        });
    }

    // export current state to GitHub, prune old files if over limit
    function ghExportBackup(onDone) {
        if (!ghEnabled()) { onDone(false, 'not configured'); return; }
        const ts      = new Date().toISOString().slice(0,19).replace(/[T:]/g,'-');
        const fname   = 'hdebt_book_log_' + ts + '.json';
        const payload = GM_getValue("hdebt_book_v1", {});
        const content = btoa(unescape(encodeURIComponent(JSON.stringify(payload, null, 2))));
        // first push new file
        ghApi('PUT', fname, { message: 'auto-backup ' + ts, content }, (ok) => {
            if (!ok) { onDone(false, 'upload failed'); return; }
            GM_setValue(GH_LAST_EXPORT_KEY, Date.now());
            // then prune oldest if over limit
            ghFetchList((listOk, files) => {
                if (!listOk || files.length <= GH_MAX_FILES) { onDone(true, fname); return; }
                const toDelete = files.slice(GH_MAX_FILES);
                let pending = toDelete.length;
                toDelete.forEach(f => {
                    ghApi('GET', f.name, null, (ok2, fd) => {
                        if (!ok2 || !fd.sha) { if (--pending === 0) onDone(true, fname); return; }
                        ghApi('DELETE', f.name, { message: 'prune old backup', sha: fd.sha }, () => {
                            if (--pending === 0) onDone(true, fname);
                        });
                    });
                });
            });
        });
    }


    // ─── VIETQR OFFLINE ──────────────────────────────────────────────────────────
    const BANK_BIN = {
        'VCB':      '970436', 'VIETCOMBANK': '970436',
        'BIDV':     '970418',
        'VTB':      '970415', 'CTG': '970415', 'VIETINBANK': '970415',
        'AGR':      '970405', 'AGRI': '970405',
        'MB':       '970422', 'MBB': '970422',
        'TCB':      '970407', 'TECHCOMBANK': '970407',
        'ACB':      '970416',
        'VPB':      '970432', 'VPBANK': '970432',
        'TPB':      '970423', 'TPBANK': '970423',
        'STB':      '970403', 'SACOMBANK': '970403',
        'HDB':      '970437',
        'VIB':      '970441',
        'SCB':      '970429',
        'MSB':      '970426',
        'SHB':      '970443',
        'EIB':      '970431', 'EXIMBANK': '970431',
        'OCB':      '970448',
        'LPB':      '970449', 'LPBANK': '970449',
        'NCB':      '970419', 'NVB': '970419',
        'ABB':      '970425',
        'BAB':      '970409',
        'CTBC':     '967009',
        'KB':       '970462', 'KBB': '970462', 'KBHCM': '970462',
        'CAKE':     '546034',
        'UBANK':    '546035',
        'WOORI':    '970457',
        'IBK':      '970455',
        'NAB':      '970428',
        'BVB':      '970454', 'VCCB': '970454',
        'SEAB':     '970440',
        'PGB':      '970430',
        'GPB':      '970408',
        'OJB':      '970463',
    };

    function _crc16(str) {
        let crc = 0xFFFF;
        for (let i = 0; i < str.length; i++) {
            crc ^= str.charCodeAt(i) << 8;
            for (let j = 0; j < 8; j++) {
                crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) : (crc << 1);
                crc &= 0xFFFF;
            }
        }
        return crc;
    }

    function _tlv(tag, value) {
        return tag + String(value.length).padStart(2, '0') + value;
    }

    // Trả về chuỗi EMVCo/VietQR, hoặc null nếu BIN không có trong map
    function buildVietQR(bankId, accountNo, amount, addInfo) {
        const bin6 = BANK_BIN[(bankId || '').toUpperCase()];
        if (!bin6) return null;

        // sub-01 của tag38: chỉ chứa BIN + accountNo (KHÔNG có QRIBFTTA ở đây)
        const acctInner = _tlv('00', bin6) + _tlv('01', accountNo);
        // tag38: sub-00=GUID, sub-01=acctInner, sub-02=QRIBFTTA (ngang hàng với sub-00/01)
        const tag38 = _tlv('00', 'A000000727') + _tlv('01', acctInner) + _tlv('02', 'QRIBFTTA');

        let s = '';
        s += _tlv('00', '00');   // Payload format: NAPAS VietQR dùng '00' không phải '01'
        s += _tlv('01', '12');   // Dynamic QR
        s += _tlv('38', tag38);  // Merchant account info
        s += _tlv('53', '704'); // Currency VND
        if (amount > 0) s += _tlv('54', String(Math.round(amount)));
        s += _tlv('58', 'VN');  // Country
        s += '6304';
        s += _crc16(s).toString(16).toUpperCase().padStart(4, '0');
        return s;
    }
    // ─────────────────────────────────────────────────────────────────────────────

    // ─── DEBUG (xoá sau khi fix xong) ────────────────────────────────────────────
    unsafeWindow._hdebt_debug = {
        buildVietQR,
        QRCodeLoaded: () => typeof QRCode !== 'undefined',
        testQR: (bankId, acctNo, amount) => {
            const s = buildVietQR(bankId, acctNo, amount || 0, 'test');
            console.log('QRCode.js loaded:', typeof QRCode !== 'undefined');
            console.log('QR string:', s);
            return s;
        }
    };
    // ─────────────────────────────────────────────────────────────────────────────

    // ─── 1. STATE ───────────────────────────────────────────────────────────────
    let savedData = GM_getValue("hdebt_book_v1", { tabs: [], activeTabId: null, selectedMiniTabId: null });
let state = {
    tabs: savedData.tabs || [],
    activeTabId: savedData.activeTabId || null,
    selectedMiniTabId: null,
    isOpen: false
};

    let deleteTimer = null, delCountdown = 6, isConfirmReady = false, copySuccessTimer = null;

    // ─── 2. HELPERS ─────────────────────────────────────────────────────────────
    const formatK = (n) => {
        const val = parseFloat(n) || 0;
        const rounded = Math.round(val / 1000);
        const abs = new Intl.NumberFormat('vi-VN').format(Math.abs(rounded)).replace(/\./g, ',') + "k";
        return rounded < 0 ? '\u2212 ' + abs : abs;
    };
    const parseK    = (val) => (parseFloat(val.toString().replace(/[^0-9.-]/g, '')) || 0) * 1000;
    const calcDebt  = (t)   => (parseFloat(t.initialDebt)||0)
                              + (parseFloat(t.carryOver)||0)
                              + (parseFloat(t.extraDebt1)||0) + (parseFloat(t.extraDebt2)||0)
                              + (parseFloat(t.extraDebt3)||0) + (parseFloat(t.extraDebt4)||0)
                              + (parseFloat(t.extraDebt5)||0) + (parseFloat(t.extraDebt6)||0)
                              - (t.payments || []).reduce((a, b) => a + (parseFloat(b.amount)||0), 0);


    // ── payment note helpers ─────────────────────────────────────────────────
    const payNote = (label) => {
        const now = new Date();
        const dd  = String(now.getDate()).padStart(2,'0');
        const mon = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'][now.getMonth()];
        const yy  = String(now.getFullYear()).slice(-2);
        const hh  = String(now.getHours()).padStart(2,'0');
        const mm  = String(now.getMinutes()).padStart(2,'0');
        const ss  = String(now.getSeconds()).padStart(2,'0');
        return { sysTs: dd + ' ' + mon + ' ' + yy + ', ' + hh + ':' + mm + ':' + ss, sysLabel: label, userNote: '' };
    };
    // build the display string for system note on a payment
    const getSysNote = (p) => {
        if (!p.sysTs) {
            // legacy: old payment with plain `note` — show as user note, no sys note
            return '';
        }
        let s = '[' + p.sysTs + '] - [' + p.sysLabel + ']';
        if (p.isMatched) s += ' - [đã khớp ảnh]';
        return s;
    };

    const saveAndRenderAll = (focusId = null) => {
        state.tabs.sort((a, b) => {
            if (a.isPinned && !b.isPinned) return -1;
            if (!a.isPinned && b.isPinned) return 1;
            return calcDebt(b) - calcDebt(a);
        });
GM_setValue("hdebt_book_v1", { tabs: state.tabs, activeTabId: state.activeTabId });
        renderMain(focusId);
        refreshButtonContent();
    };

    // ─── 3. STYLES ──────────────────────────────────────────────────────────────
    GM_addStyle(`
        #bakist-debt-main {
            --bg:        #f9f7f4;
            --surface:   #f3f1ec;
            --surface2:  #eceae4;
            --border:    #e8e5de;
            --border2:   #d8d5ce;
            --accent:    #008f52;
            --accent-dim:#006b3d;
            --danger:    #cc2200;
            --blue:      #1a5fd4;
            --yellow:    #a67000;
            --text:      #1a1a1a;
            --text-sub:  #5a5a5a;
            --text-dim:  #9a9a9a;
            --mono:      'SF Mono', 'Fira Code', 'Consolas', monospace;
        }
        #bakist-debt-main {
            position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
            background: var(--bg); z-index: 2147483647;
            display: none; flex-direction: column;
            font-family: -apple-system, 'Segoe UI', sans-serif;
            color: var(--text);
        }
        .bakist-head {
            background: var(--surface);
            border-bottom: 1px solid var(--border);
            padding: 0 14px;
            height: 48px;
            display: flex; align-items: center; gap: 10px;
            flex-shrink: 0;
            overflow: hidden;
        }
        .bakist-tabs { display: flex; flex: 1; overflow-x: auto; gap: 5px; align-items: center; }
        .bakist-tabs::-webkit-scrollbar { height: 0; }
        .bakist-t {
            padding: 0 18px; cursor: pointer;
            font-size: 24px; white-space: nowrap;
            display: flex; align-items: center; height: 44px;
            border-radius: 5px; font-weight: 500;
            color: var(--text-sub); background: transparent;
            border: 1px solid var(--border);
            transition: all 0.15s;
        }
        .bakist-t:hover { color: var(--text); background: var(--surface2); }
        .bakist-t.active { background: var(--surface2) !important; color: var(--accent) !important; border-color: var(--accent) !important; font-weight: 600; }
        .bakist-t.is-pnd { color: var(--accent) !important; }
        #add-v6-btn { border-style: dashed !important; border-color: var(--border) !important; color: var(--accent) !important; background: transparent !important; }
        #add-v6-btn:hover { background: var(--surface2) !important; border-color: var(--accent) !important; }
        .bakist-main-split { display: flex; flex: 1; overflow: hidden; }
        .split-left {
            width: 260px; padding: 12px; flex-shrink: 0;
            border-right: 1px solid var(--border);
            background: var(--surface);
            display: flex; flex-direction: column; gap: 0;
            overflow-y: auto;
        }
        .sl-row { margin-bottom: 6px; }
        .sl-sep  { height: 1px; background: var(--border); margin: 8px 0; }
        .input-card {
            display: flex; align-items: center;
            border: 1px solid var(--border2); border-radius: 7px;
            background: var(--bg); height: 40px; transition: border-color 0.15s;
        }
        .input-card:focus-within { border-color: var(--accent); }
        .input-card input { border: none; outline: none; flex: 1; padding: 0 12px; font-size: 14px; font-weight: 600; background: transparent; color: var(--text); font-family: inherit; }
        .input-card input::placeholder { color: var(--text-dim); font-weight: 400; }
        .input-card.locked { background: var(--surface2); border-color: var(--border2); }
        .input-card.locked input { color: var(--text-sub); cursor: not-allowed; font-family: var(--mono); }
        .ic-lock { padding: 0 10px; cursor: pointer; font-size: 13px; color: var(--text-dim); transition: color 0.15s; flex-shrink: 0; }
        .ic-lock:hover { color: var(--accent); }
        .remain-box {
            background: var(--surface2); border: 1px solid var(--border);
            border-left: 3px solid var(--danger);
            padding: 12px 14px; border-radius: 7px; margin-top: 4px;
        }
        .remain-box.zero { border-left-color: var(--accent); }
        .remain-box.neg  { border-left-color: var(--blue); }
        .remain-title { font-size: 13px; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase; display: block; margin-bottom: 6px; }
        .remain-val { font-size: 52px; font-weight: 900; font-family: var(--mono); display: block; line-height: 1; letter-spacing: -1px; white-space: nowrap; }
        .bakist-locked-ui { opacity: 0.12; pointer-events: none; }
.split-right { flex: 1; display: flex; flex-direction: column; background: #dedad2; padding: 16px; overflow: hidden; }
        .v6-pay-top {
            width: 100%; box-sizing: border-box; border: 1px solid var(--border); border-radius: 8px;
            padding: 0 16px; height: 48px; font-size: 20px; font-weight: 700; font-family: var(--mono);
            outline: none; background: var(--surface); color: var(--accent); margin-bottom: 14px;
            letter-spacing: 0.02em; transition: border-color 0.15s, box-shadow 0.15s;
        }
        .v6-pay-top:focus { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(0,143,82,0.12); }
        .v6-pay-top::placeholder { color: var(--text-dim); font-size: 13px; font-weight: 400; font-family: -apple-system, 'Segoe UI', sans-serif; }
        .v6-pay-top.all-matched { border-color: #a67000; box-shadow: 0 0 0 3px rgba(166,112,0,0.18); }
        .v6-pay-top.all-matched::placeholder { color: #a67000; font-weight: 600; font-size: 14px; font-family: -apple-system, 'Segoe UI', sans-serif; }
        #v6-list-container { display: grid; gap: 8px; align-content: start; overflow: hidden; flex: 1; }
        .pay-card {
            border: 1px solid var(--border2); border-radius: 8px; padding: var(--card-pad, 10px);
            background: var(--surface); position: relative; display: flex; flex-direction: column;
            text-align: center; justify-content: center; transition: border-color 0.15s, opacity 0.15s;
            overflow: hidden; min-height: 0; cursor: default;
        }
        .pay-card:active { cursor: grabbing; }
        .card-drag-hint { position: absolute; bottom: 4px; right: 6px; font-size: var(--card-meta, 10px); opacity: 0.3; user-select: none; -webkit-user-select: none; line-height: 1; cursor: grab; }
        .card-drag-hint:active { cursor: grabbing; }
        .pay-card:hover .card-drag-hint { opacity: 0.7; }
        .pay-card:hover { border-color: var(--border); }
        .pay-card.is-matched { background: rgba(0,143,82,0.10); border-color: var(--accent); border-width: 2px; }
        .pay-card.dragging-src { opacity: 0.35; border-style: dashed; }
        .pay-card.drag-over    { border-color: var(--accent); border-width: 2px; background: var(--surface2); }
        .drag-handle:hover { color: var(--accent); }
        .drag-handle:active { cursor: grabbing; }
.pay-num { position: absolute; top: 6px; left: 8px; font-size: var(--card-num, 54px); color: var(--text-dim); font-family: var(--mono); font-weight: 900; line-height: 1; opacity: 0.18; }
        .del-p { position: absolute; top: 4px; right: 6px; cursor: pointer; color: var(--text-dim); font-size: var(--card-meta, 10px); padding: 3px 4px; border-radius: 3px; line-height: 1; transition: all 0.25s; }
        .del-p:hover { color: var(--danger); background: rgba(204,34,0,0.12); }
        .del-p.alt-corner { top: auto; right: auto; bottom: 4px; left: 6px; color: var(--danger); }
        .del-p.alt-corner:hover { background: rgba(204,34,0,0.12); }
        .pay-amt { font-size: var(--card-amt, 24px); font-weight: 800; color: var(--accent); font-family: var(--mono); line-height: 1; margin: var(--card-gap, 6px) 0; display: block; letter-spacing: -0.5px; }
        .pay-card.is-matched .pay-amt { color: var(--text-sub); }
        .sys-note { display:block; font-size:calc(var(--card-meta, 10px) * 1.2); color:var(--text-dim); font-family:var(--mono); line-height:1.4; text-align:center; letter-spacing:0.02em; word-break:break-word; padding:0 4px; }
        .pay-card.is-matched .sys-note { color:var(--text-dim); opacity:0.7; }
        .row-note { border:none !important; border-bottom:1px solid var(--border2) !important; padding:2px 4px !important; font-size:calc(var(--card-meta, 10px) * 1.2) !important; background:transparent !important; color:var(--text-sub) !important; outline:none !important; min-width:52px; width:auto; max-width:100%; box-sizing:border-box; text-align:center; font-family:inherit; }
        .row-note:focus { border-bottom-color:var(--accent) !important; color:var(--text) !important; }
        .row-note::placeholder { color:var(--text-dim); opacity:0.5; font-size:0.9em; }
        .btn-match { position: absolute; bottom: 5px; left: 50%; transform: translateX(-50%); cursor: pointer; border-radius: 20px; line-height: 1; display: inline-flex; align-items: center; justify-content: center; gap: 3px; padding: 3px 10px; font-size: var(--card-meta, 10px); font-weight: 700; letter-spacing: 0.04em; border: 1.5px solid #c8a200 !important; background: rgba(200,162,0,0.08) !important; color: #a67000 !important; transition: all 0.18s; white-space: nowrap; user-select: none; -webkit-user-select: none; }
        .btn-match:hover { background: rgba(200,162,0,0.18) !important; border-color: #a67000 !important; transform: translateX(-50%) scale(1.06); }
        .btn-match.matched { border: 1.5px solid var(--accent) !important; background: rgba(0,143,82,0.35) !important; color: var(--accent) !important; box-shadow: 0 0 6px rgba(0,143,82,0.3); }
        .btn-match.matched:hover { background: rgba(0,143,82,0.50) !important; transform: translateX(-50%) scale(1.06); }
        .bakist-foots { padding: 10px 16px; display: flex; gap: 8px; background: var(--surface); border-top: 1px solid var(--border); flex-shrink: 0; }
        .bakist-b { height: 38px; border: none; border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 12px; letter-spacing: 0.03em; color: var(--bg); flex: 1; transition: all 0.15s; opacity: 0.92; }
        .bakist-b:hover { opacity: 1; transform: translateY(-1px); }
        .bakist-b:active { transform: translateY(0); opacity: 0.8; }
        .b-close   { background: #111; border: 1px solid #444; flex: 0 0 auto; padding: 0 13px; color: #fff !important; font-size: 16px; font-weight: 700; min-width: 0; }
        .b-close:hover { background: #2a2a2a !important; border-color: #666 !important; }
        .b-export  { background: #0e7490; flex: 0 0 auto; padding: 0 13px; font-size: 15px; font-weight: 800; letter-spacing: -0.02em; min-width: 0; }
        .b-import  { background: #3730a3; flex: 0 0 auto; padding: 0 13px; color: #fff !important; font-size: 15px; font-weight: 800; letter-spacing: -0.02em; min-width: 0; }
        .b-import:hover { background: #4338ca !important; }
        .b-sync    { background: #0f766e; flex: 0 0 auto; padding: 0 13px; font-size: 16px; min-width: 0; }
        .b-paste   { background: #0284c7; }
        .b-summary { background: #b45309; }
        .b-summary.copied { background: var(--accent); }
        .b-img     { background: #7c3aed; }
        .b-img.copied { background: var(--accent); }
        .b-pin     { background: #0f6e5e; }
        .b-del     { background: #f85149; }
        #bakist-import-modal {
            position: fixed; inset: 0; z-index: 2147483648;
            background: #000;
            display: none; flex-direction: column;
            align-items: center; justify-content: center;
            font-family: 'SF Mono','Fira Code','Consolas',monospace;
        }
        #bakist-import-modal.open { display: flex; }
        #bakist-import-modal::before {
            content: '';
            position: absolute; inset: 0;
            background: repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,80,0.018) 2px, rgba(0,255,80,0.018) 4px);
            pointer-events: none;
        }
        .bakist-modal-box {
            position: relative; z-index: 1;
            width: 820px; max-width: 95vw;
            display: flex; flex-direction: column; gap: 16px;
        }
        .bakist-modal-box h3 {
            margin: 0; font-size: 11px; font-weight: 700;
            letter-spacing: 0.18em; text-transform: uppercase;
            color: #00ff50; opacity: 0.7;
        }
        .bakist-modal-box p { display: none; }
        .bakist-modal-warn {
            font-size: 11px; color: #ff4444; letter-spacing: 0.06em;
            border: none; background: none; padding: 0;
            opacity: 0.8;
        }
        #bakist-import-file {
            font-size: 12px; color: #00cc40; cursor: pointer;
            background: transparent;
            border: 1px dashed rgba(0,255,80,0.25); border-radius: 4px;
            padding: 8px 10px; width: 100%; box-sizing: border-box;
            letter-spacing: 0.05em;
        }
        #bakist-import-file::-webkit-file-upload-button {
            background: rgba(0,255,80,0.12); border: 1px solid rgba(0,255,80,0.4);
            color: #00ff50; border-radius: 3px; padding: 3px 10px;
            cursor: pointer; font-family: inherit; font-size: 11px; letter-spacing: 0.06em;
        }
        #bakist-import-textarea {
            width: 100%; box-sizing: border-box; height: 200px;
            background: rgba(0,255,80,0.03);
            border: 1px solid rgba(0,255,80,0.2); border-radius: 4px;
            padding: 12px; resize: none;
            color: #00dd44; font-family: inherit; font-size: 12px;
            outline: none; line-height: 1.6; letter-spacing: 0.03em;
        }
        #bakist-import-textarea:focus { border-color: rgba(0,255,80,0.55); box-shadow: 0 0 12px rgba(0,255,80,0.08); }
        #bakist-import-textarea::placeholder { color: rgba(0,255,80,0.22); }
        .bakist-modal-row { display: flex; gap: 10px; justify-content: flex-end; align-items: center; }
        .bakist-modal-btn {
            height: 36px; border-radius: 4px; font-size: 11px; font-weight: 700;
            cursor: pointer; padding: 0 18px; font-family: inherit; letter-spacing: 0.1em; text-transform: uppercase;
        }
        .bakist-modal-cancel {
            background: transparent; color: rgba(0,255,80,0.45);
            border: 1px solid rgba(0,255,80,0.2);
        }
        .bakist-modal-cancel:hover { color: #00ff50; border-color: rgba(0,255,80,0.5); }
        .bakist-modal-confirm {
            background: rgba(0,255,80,0.12); color: #00ff50;
            border: 1px solid rgba(0,255,80,0.45);
        }
        .bakist-modal-confirm:hover { background: rgba(0,255,80,0.22); border-color: #00ff50; }
        #bakist-import-close-btn {
            position: absolute; top: 24px; right: 24px; z-index: 2;
            background: transparent; border: 1px solid rgba(0,255,80,0.2);
            color: rgba(0,255,80,0.4); font-size: 18px; width: 34px; height: 34px;
            border-radius: 4px; cursor: pointer; display: flex; align-items: center; justify-content: center;
            font-family: inherit; transition: all 0.15s;
        }
        #bakist-import-close-btn:hover { color: #00ff50; border-color: rgba(0,255,80,0.6); }

        .bakist-import-cols { display:flex; gap:0; min-height:260px; }
        .bakist-import-col { flex:1; display:flex; flex-direction:column; gap:10px; }
        .bakist-import-col-divider { width:1px; background:rgba(0,255,80,0.12); margin:0 20px; flex-shrink:0; }
        .bakist-import-col-title { font-size:9px; font-weight:700; letter-spacing:0.14em; color:rgba(0,255,80,0.35); text-transform:uppercase; }
        #bakist-gh-list {
            flex:1; overflow-y:auto; display:flex; flex-direction:column; gap:6px;
            padding-right:4px;
        }
        #bakist-gh-list::-webkit-scrollbar { width:3px; }
        #bakist-gh-list::-webkit-scrollbar-thumb { background:rgba(0,255,80,0.2); border-radius:2px; }
        .bakist-gh-file {
            padding:8px 10px; border:1px solid rgba(0,255,80,0.15); border-radius:3px;
            cursor:pointer; font-size:11px; color:rgba(0,255,80,0.6); letter-spacing:0.04em;
            transition:all 0.12s; display:flex; align-items:center; justify-content:space-between;
            background:rgba(0,255,80,0.02);
        }
        .bakist-gh-file:hover { background:rgba(0,255,80,0.08); border-color:rgba(0,255,80,0.45); color:#00ff50; }
        .bakist-gh-file.selected { background:rgba(0,255,80,0.12); border-color:#00ff50; color:#00ff50; }
        .bakist-gh-file .gf-name { font-weight:600; }
        .bakist-gh-file .gf-size { font-size:9px; opacity:0.5; }
        .bakist-gh-status { font-size:11px; color:rgba(0,255,80,0.3); letter-spacing:0.06em; padding:8px 0; }
        .bakist-gh-status.err { color:rgba(255,60,60,0.6); }
        .remain-box.neg { cursor: grab; }
        .remain-box.neg:active { cursor: grabbing; }
        .remain-box.neg.dragging { opacity: 0.5; }
        .remain-box:not(.zero) { cursor: grab; }
        .remain-box:not(.zero):active { cursor: grabbing; }
        .remain-box.dragging { opacity: 0.5; }
        .v6-pay-top.drop-over { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(0,143,82,0.25); }
        .bakist-t.drop-target { background: rgba(0,143,82,0.15) !important; border-color: var(--accent) !important; color: var(--accent) !important; }
        @keyframes gmnShake { 0%,100%{transform:translateX(0)} 25%{transform:translateX(-6px)} 75%{transform:translateX(6px)} }
        .bakist-shake { animation: gmnShake 0.35s ease; }
        #bakist-fixed-wrap { position: fixed; z-index: 2147483648; display: flex; flex-direction: column; gap: 8px; pointer-events: none; font-family: "Segoe UI", Roboto, sans-serif; opacity: 0; left: -9999px; transition: opacity 0.08s ease; }
        #bakist-fixed-wrap.visible { pointer-events: auto; opacity: 1; transition: opacity 0.08s ease; }
        .bakist-grid { display: grid; gap: 8px; width: 100%; grid-template-columns: repeat(auto-fit, minmax(30%, 1fr)); }
.bakist-btn { height: 54px; color: #fff; font-weight: 700; border-radius: 8px; cursor: pointer; display: flex; align-items: center; justify-content: center; border: none; padding: 0 14px; font-size: 16px; letter-spacing: 0.01em; box-shadow: 0 2px 6px rgba(0,0,0,0.2); transition: filter 0.12s, box-shadow 0.12s; white-space: nowrap; text-shadow: 0 1px 2px rgba(0,0,0,0.25); user-select: none; -webkit-user-select: none; font-family: -apple-system, 'Segoe UI', sans-serif; }
        .bakist-btn:hover  { filter: brightness(1.12); transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,0.3); }
        .bakist-btn:active { transform: translateY(1px); box-shadow: none; }
        .bakist-btn-active   { background-color: #0070c0; border-bottom: 3px solid #005a9a; }
        .bakist-btn-inactive { background-color: #7f8c8d; border-bottom: 3px solid #5e6b6c; }
        .bakist-btn-empty    { background-color: #7f8c8d; border-bottom: 3px solid #5e6b6c; cursor: default; }
        .bakist-icon-star  { filter: hue-rotate(200deg) saturate(3) brightness(1.4); }
        .bakist-icon-heart { filter: hue-rotate(110deg) saturate(4) brightness(1.1); }
        .bakist-icon-pin   { filter: hue-rotate(280deg) saturate(3) brightness(1.3); }

        #bakist-qr-float { position:fixed; z-index:2147483648; display:none; flex-direction:column; align-items:center; pointer-events:none; }
        #bakist-qr-wrap { position:relative; width:200px; height:200px; border-radius:8px; overflow:hidden; box-shadow:0 4px 20px rgba(0,0,0,0.25); }
        #bakist-qr-canvas { width:200px; height:200px; display:block; }
        #bakist-qr-canvas img, #bakist-qr-canvas canvas { width:200px !important; height:200px !important; display:block; }
        @keyframes gmnBtnFlash { 0% { filter: brightness(1); } 50% { filter: brightness(2); } 100% { filter: brightness(1); } }
        .flash-capture { animation: gmnBtnFlash 0.5s ease-in-out; }
        @keyframes gmnLauncherIn { from { opacity:0; } to { opacity:1; } }
        #bakist-qr-launcher-backdrop { display:none !important; }
        #bakist-qr-launcher {
            position:fixed; inset:0; z-index:2147483645; display:none;
            background:#0d0d0d;
            flex-direction:column;
            font-family:-apple-system,'Segoe UI',sans-serif;
            overflow:hidden;
        }
        #bakist-qr-launcher.open { display:flex; animation: gmnLauncherIn 0.15s ease forwards; }
        #bakist-qr-launcher-title {
            flex-shrink:0;
            font-size:30px; font-weight:700; letter-spacing:0.12em; text-transform:uppercase;
            color:#d0d0d0; padding:28px 32px 0; display:flex; flex-direction:column; gap:12px; user-select:none;
        }
        #bakist-qr-launcher-title .lt-row { display:flex; align-items:center; gap:14px; }
        #bakist-qr-launcher-title .lt-dot { width:14px; height:14px; border-radius:50%; background:#008f52; box-shadow:0 0 10px #008f52; flex-shrink:0; }
        #bakist-qr-launcher-title .lt-dot-red { background:#cc2200; box-shadow:0 0 10px #cc2200; }
        #bakist-qr-launcher-grid {
            flex:1;
            display:flex;
            flex-direction:row;
            flex-wrap:nowrap;
            align-items:center;
            justify-content:center;
            gap:18px;
            padding:0 48px;
            overflow-x:auto;
        }
        #bakist-qr-launcher-grid::-webkit-scrollbar { height:4px; }
        #bakist-qr-launcher-grid::-webkit-scrollbar-thumb { background:#2a2a2a; border-radius:2px; }
        .bakist-launcher-btn {
            width:180px; flex-shrink:0; height:90px;
            background:#1a1a1a; border:1.5px solid #525252; border-radius:14px;
            cursor:pointer;
            display:flex; flex-direction:column; align-items:center; justify-content:center; gap:5px;
            transition:background 0.11s, border-color 0.11s, transform 0.11s, box-shadow 0.11s;
            user-select:none; -webkit-user-select:none;
            position:relative;
        }
        .bakist-launcher-btn:hover { background:#252525; border-color:#909090; transform:translateY(-2px); box-shadow:0 10px 28px rgba(0,0,0,0.6); }
        .bakist-launcher-btn:active { transform:translateY(1px); box-shadow:none; background:#161616; }
        .bakist-launcher-btn.qr-active { border-color:#008f52 !important; box-shadow:0 0 0 2px rgba(0,143,82,0.3) !important; background:#182018 !important; }
        .bakist-launcher-btn .lb-name { font-size:18px; font-weight:800; color:#f2f2f2; letter-spacing:0.01em; }
        .bakist-launcher-btn .lb-debt { font-size:12px; font-family:'SF Mono','Fira Code',Consolas,monospace; color:#c04040; font-weight:700; }
        .bakist-launcher-btn.linked .lb-debt { color:#00c46a; }
        .bakist-launcher-btn.zero .lb-debt { color:#4a8a4a; }
        #bakist-qr-launcher-footer { flex-shrink:0; padding:14px 32px 22px; font-size:10px; color:#2a2a2a; text-align:center; letter-spacing:0.06em; user-select:none; }
        #bakist-qr-float { z-index:2147483650 !important; }
        .bakist-welcome {
            flex:1; display:flex; align-items:center; justify-content:center; gap:48px;
        }
        .bakist-welcome-btn {
            display:flex; flex-direction:column; align-items:center; justify-content:center; gap:10px;
            cursor:pointer; user-select:none; -webkit-user-select:none;
            opacity:0.55; transition:opacity 0.18s, transform 0.18s;
        }
        .bakist-welcome-btn:hover { opacity:1; transform:translateY(-3px); }
        .bakist-welcome-btn:active { transform:translateY(0); opacity:0.8; }
        .bakist-welcome-icon {
            font-size:72px; line-height:1;
            color:var(--text-dim);
        }
        .bakist-welcome-label {
            font-size:11px; font-weight:600; letter-spacing:0.1em; text-transform:uppercase;
            color:var(--text-dim);
        }
    `);

    // ─── 4. DOM ELEMENTS ────────────────────────────────────────────────────────
    const mainOverlay = document.createElement('div');
    mainOverlay.id = 'bakist-debt-main';
    mainOverlay.oncontextmenu = e => e.preventDefault();
    document.body.appendChild(mainOverlay);

    const importModal = document.createElement('div');
    importModal.id = 'bakist-import-modal';
    importModal.innerHTML = `
        <button id="bakist-import-close-btn" title="Đóng (Esc)">✕</button>
        <div class="bakist-modal-box">
            <h3>// import :: restore từ json backup</h3>
            <div class="bakist-import-cols">
                <div class="bakist-import-col" id="bakist-gh-col">
                    <div class="bakist-import-col-title">// github backups</div>
                    <div id="bakist-gh-list"><span class="bakist-gh-status">// đang tải...</span></div>
                </div>
                <div class="bakist-import-col-divider"></div>
                <div class="bakist-import-col">
                    <div class="bakist-import-col-title">// paste hoặc chọn file thủ công</div>
                    <input type="file" id="bakist-import-file" accept=".json">
                    <textarea id="bakist-import-textarea" placeholder='// hoặc dán thẳng json vào đây&#10;{"tabs":[...],"activeTabId":...}'></textarea>
                </div>
            </div>
            <div class="bakist-modal-warn">// cảnh báo: toàn bộ dữ liệu hiện tại sẽ bị ghi đè — hãy export backup trước</div>
            <div class="bakist-modal-row">
                <button class="bakist-modal-btn bakist-modal-cancel" id="bakist-import-cancel">[ huỷ ]</button>
                <button class="bakist-modal-btn bakist-modal-confirm" id="bakist-import-confirm">[ ghi đè &amp; restore ]</button>
            </div>
        </div>`;
    document.body.appendChild(importModal);


// Canvas for the trapezoid cone effect — append TRƯỚC qrFloat để qrFloat luôn on top
const qrConnector = document.createElement('canvas');
qrConnector.id = 'bakist-qr-connector';
qrConnector.style.cssText = 'position:fixed;top:0;left:0;pointer-events:none;z-index:2147483649;display:none;';
document.body.appendChild(qrConnector);

    const qrFloat = document.createElement('div');
    qrFloat.id = 'bakist-qr-float';
 qrFloat.innerHTML = '<div id="bakist-qr-wrap"><div id="bakist-qr-canvas"></div></div>';
document.body.appendChild(qrFloat);

const qrDot = document.createElement('div');
qrDot.id = 'bakist-qr-dot';
qrDot.style.cssText = 'display:none;';
document.body.appendChild(qrDot);

    // khai báo sớm để click/ESC listeners dùng được
    let btnWrapForceHidden = false;
    const btnWrap = document.createElement('div');
    btnWrap.id = 'bakist-fixed-wrap';
    const btnGrid = document.createElement('div');
    btnGrid.className = 'bakist-grid';
    btnWrap.appendChild(btnGrid);
    document.body.appendChild(btnWrap);

document.addEventListener('click', () => {
    qrFloat.style.display = 'none';
    btnGrid.querySelectorAll('.bakist-btn[data-mid]').forEach(b => b.style.visibility = '');
    if (qrConnector.getContext) { qrConnector.getContext('2d').clearRect(0, 0, qrConnector.width, qrConnector.height); }
    if (qrConnector.getContext) { qrConnector.getContext('2d').clearRect(0,0,qrConnector.width,qrConnector.height); } qrConnector.style.display = 'none';
}, true);

// ── QR LAUNCHER ────────────────────────────────────────────────────────────

const qrLauncher = document.createElement('div');
qrLauncher.id = 'bakist-qr-launcher';
qrLauncher.innerHTML = `
    <div id="bakist-qr-launcher-title">
        <div class="lt-row"><span class="lt-dot"></span><span>mở chuột phải tại từng ncc để hiện QR ck</span></div>
        <div class="lt-row"><span class="lt-dot lt-dot-red"></span><span>ESC để thoát</span></div>
    </div>
    <div id="bakist-qr-launcher-grid"></div>
    <div id="bakist-qr-launcher-footer">chuột phải vào ncc để xem QR &nbsp;·&nbsp; nhập số tiền trực tiếp trên điện thoại &nbsp;·&nbsp; Ctrl+Home / Option+Q hoặc Esc để đóng</div>
`;
document.body.appendChild(qrLauncher);

function openQRLauncher() {
    const grid = document.getElementById('bakist-qr-launcher-grid');
    grid.innerHTML = '';
    if (state.tabs.length === 0) {
        grid.innerHTML = '<div style="color:#555;font-size:13px;padding:10px 0;">Chưa có NCC nào trong hdebt book.</div>';
    } else {
        state.tabs.forEach(t => {
            const debt = calcDebt(t);
            const isZero = debt === 0;
            const btn  = document.createElement('div');
            btn.className = 'bakist-launcher-btn' + (isZero ? ' zero' : (t.linkedContact ? ' linked' : ''));
            btn.innerHTML = `
                <span class="lb-name">${(t.name || 'NCC').toLowerCase()}</span>
                <span class="lb-debt">${formatK(debt)}</span>
            `;
            btn.oncontextmenu = e => {
                e.preventDefault();
                e.stopPropagation();
                grid.querySelectorAll('.bakist-launcher-btn').forEach(b => b.classList.remove('qr-active'));
                btn.classList.add('qr-active');
                const debt = calcDebt(t);
                const amount = e.getModifierState('CapsLock') && debt > 0 ? debt : 0;
                showQRModal(t, amount, btn, true);
            };
            grid.appendChild(btn);
        });
    }
    btnWrap.classList.remove('visible');
    qrLauncher.classList.add('open');
    qrLauncher.focus();
}

function closeQRLauncher() {
    qrLauncher.classList.remove('open');
    qrFloat.style.display = 'none';
    if (qrConnector.getContext) { qrConnector.getContext('2d').clearRect(0,0,qrConnector.width,qrConnector.height); } qrConnector.style.display = 'none';
    qrDot.style.display = 'none';
    const grid = document.getElementById('bakist-qr-launcher-grid');
    if (grid) grid.querySelectorAll('.bakist-launcher-btn').forEach(b => b.classList.remove('qr-active'));
}

qrLauncher.addEventListener('click', e => e.stopPropagation());
qrLauncher.oncontextmenu = e => e.preventDefault();
qrLauncher.setAttribute('tabindex', '-1');

    function showQRModal(tab, amount, anchorBtn, launcherMode) {
        const c      = tab.linkedContact;
        const wrap   = document.getElementById('bakist-qr-canvas');
        wrap.innerHTML = '';

        if (c) {
            const amtNum  = Math.round(Math.abs(amount));
            const addInfo = 'chuyen khoan';
            const qrStr   = buildVietQR(c.bankId, c.accountNo, amtNum, addInfo);            if (qrStr && typeof QRCode !== 'undefined') {
                // offline: QRCode.js render trực tiếp
                new QRCode(wrap, {
                    text: qrStr, width: 200, height: 200,
                    colorDark: '#000000', colorLight: '#ffffff',
                    correctLevel: QRCode.CorrectLevel.M,
                });
            } else {
                // fallback: VietQR API (cần internet)
                const img = document.createElement('img');
                img.style.cssText = 'width:200px;height:200px;display:block;';
                img.src = 'https://img.vietqr.io/image/' + c.bankId + '-' + c.accountNo +
                          '-qr_only.png?amount=' + amtNum + '&addInfo=' + encodeURIComponent(addInfo);
                wrap.appendChild(img);
            }
        } else {
            // chưa link contact → skeleton
            const img = document.createElement('img');
            img.style.cssText = 'width:200px;height:200px;display:block;filter:grayscale(1);opacity:0.6;';
            img.src = assetSrc(ASSET_SKELETON);
            wrap.appendChild(img);
        }
const QR_W = 200;
const QR_H = 200;
qrFloat.style.display = 'flex';
if (!launcherMode) {
    // ẩn các button khác để glow không bị che
    btnGrid.querySelectorAll('.bakist-btn[data-mid]').forEach(b => {
        if (b !== anchorBtn) b.style.visibility = 'hidden';
    });
}
if (launcherMode) {
    if (qrConnector.getContext) { qrConnector.getContext('2d').clearRect(0,0,qrConnector.width,qrConnector.height); } qrConnector.style.display = 'none';
    qrDot.style.display = 'none';
    requestAnimationFrame(() => {
        const btnRect = anchorBtn.getBoundingClientRect();
        const btnCX   = btnRect.left + btnRect.width / 2;
        const qrLeft  = Math.max(4, Math.min(btnCX - QR_W / 2, window.innerWidth - QR_W - 4));
        const qrTop   = btnRect.top - QR_H - 120;
        qrFloat.style.left = qrLeft + 'px';
        qrFloat.style.top  = Math.max(4, qrTop) + 'px';
    });
} else {
    qrConnector.style.display = 'block';
    requestAnimationFrame(() => {
        const btnRect = anchorBtn.getBoundingClientRect();
        const amtInp  = document.getElementById('payingAmtInvoice')
                     || document.querySelector('input[ng-model*="payingAmt"]');
        const amtR    = amtInp ? amtInp.getBoundingClientRect() : null;
        const W = window.innerWidth, H = window.innerHeight;
        const PAD = 8, qr = 12, br = 10, ar = 6;

        // button box
        const bx = btnRect.left - PAD, by = btnRect.top - PAD;
        const bw = btnRect.width + PAD*2, bh = btnRect.height + PAD*2;

        // amount box (chỉ field số, không label)
        const ax  = amtR ? amtR.left   - PAD : bx;
        const ay  = amtR ? amtR.top    - PAD : by - 60;
        const aw  = amtR ? amtR.width  + PAD*2 : bw;
        const ah  = amtR ? amtR.height + PAD*2 : 36;

        // connectors
        const c1X = bx + bw/2;   // giữa cạnh trên button
        const c1Y = ay + ah;      // giữa cạnh dưới amount → vertical connector
        const c2X = ax;           // giữa cạnh trái amount
        const c2Y = ay + ah/2;    // giữa cạnh trái amount (horizontal connector)

        // QR position: tịnh tiến trong vùng ⅔ bên trái theo QR_POSITION_PCT
        const zone     = W * (2/3);                        // ⅔ màn hình
        const zoneMin  = 8;
        const zoneMax  = zone - QR_W - 8;
        const qrLeft   = Math.round(zoneMin + (zoneMax - zoneMin) * QR_POSITION_PCT / 100);
        const qrTop    = Math.max(12, Math.min(c2Y - QR_H/2, H - QR_H - 12));
        qrFloat.style.left = qrLeft + 'px';
        qrFloat.style.top  = qrTop  + 'px';

        const qx = qrLeft - PAD, qy = qrTop - PAD;
        const qw = QR_W + PAD*2,  qh = QR_H + PAD*2;
        const qRX = qx + qw;         // giữa cạnh phải QR
        const qRY = qy + qh/2;

        qrConnector.width = W; qrConnector.height = H;
        qrConnector.style.width = W+'px'; qrConnector.style.height = H+'px';
        const ctx = qrConnector.getContext('2d');
        ctx.clearRect(0, 0, W, H);

        // ── clip region: toàn canvas TRỪ phần bên trong 3 boxes ─────────────
        const clipOut = () => {
            ctx.beginPath();
            // outer rect = toàn canvas
            ctx.rect(0, 0, W, H);
            // cut out amount interior
            ctx.moveTo(ax+ar,ay); ctx.lineTo(ax+aw-ar,ay);
            ctx.arcTo(ax+aw,ay, ax+aw,ay+ar, ar);
            ctx.lineTo(ax+aw,ay+ah-ar);
            ctx.arcTo(ax+aw,ay+ah, ax+aw-ar,ay+ah, ar);
            ctx.lineTo(ax+ar,ay+ah);
            ctx.arcTo(ax,ay+ah, ax,ay+ah-ar, ar);
            ctx.lineTo(ax,ay+ar);
            ctx.arcTo(ax,ay, ax+ar,ay, ar);
            ctx.closePath();
            // cut out button interior
            ctx.moveTo(bx+br,by); ctx.lineTo(bx+bw-br,by);
            ctx.arcTo(bx+bw,by, bx+bw,by+br, br);
            ctx.lineTo(bx+bw,by+bh-br);
            ctx.arcTo(bx+bw,by+bh, bx+bw-br,by+bh, br);
            ctx.lineTo(bx+br,by+bh);
            ctx.arcTo(bx,by+bh, bx,by+bh-br, br);
            ctx.lineTo(bx,by+br);
            ctx.arcTo(bx,by, bx+br,by, br);
            ctx.closePath();
            // cut out QR interior
            ctx.moveTo(qx+qr,qy); ctx.lineTo(qx+qw-qr,qy);
            ctx.arcTo(qx+qw,qy, qx+qw,qy+qr, qr);
            ctx.lineTo(qx+qw,qy+qh-qr);
            ctx.arcTo(qx+qw,qy+qh, qx+qw-qr,qy+qh, qr);
            ctx.lineTo(qx+qr,qy+qh);
            ctx.arcTo(qx,qy+qh, qx,qy+qh-qr, qr);
            ctx.lineTo(qx,qy+qr);
            ctx.arcTo(qx,qy, qx+qr,qy, qr);
            ctx.closePath();
            ctx.clip('evenodd');
        };

        // ── path connectors ───────────────────────────────────────────────────
        const buildConnectors = () => {
            ctx.beginPath();
            // vertical: button top → c2Y (full, clip ẩn phần qua box)
            ctx.moveTo(c1X, by);
            ctx.lineTo(c1X, c2Y);
            // nối ngang từ junction đến amount left rồi tiếp tục đến QR
            ctx.lineTo(c2X, c2Y);
            ctx.moveTo(c2X, c2Y);
            ctx.lineTo(qRX, qRY);
        };

        // ── path borders ──────────────────────────────────────────────────────
        const buildBorders = () => {
            ctx.beginPath();
            // button border
            ctx.moveTo(c1X,      by);
            ctx.lineTo(bx+bw-br, by);
            ctx.arcTo(bx+bw,by,   bx+bw,by+br,     br);
            ctx.lineTo(bx+bw,    by+bh-br);
            ctx.arcTo(bx+bw,by+bh,bx+bw-br,by+bh,  br);
            ctx.lineTo(bx+br,    by+bh);
            ctx.arcTo(bx,by+bh,   bx,by+bh-br,      br);
            ctx.lineTo(bx,       by+br);
            ctx.arcTo(bx,by,      bx+br,by,          br);
            ctx.lineTo(c1X,      by);
            // amount border
            ctx.moveTo(c2X,      c2Y);
            ctx.lineTo(ax,       ay+ar);
            ctx.arcTo(ax,ay,      ax+ar,ay,           ar);
            ctx.lineTo(ax+aw-ar, ay);
            ctx.arcTo(ax+aw,ay,   ax+aw,ay+ar,        ar);
            ctx.lineTo(ax+aw,    ay+ah-ar);
            ctx.arcTo(ax+aw,ay+ah,ax+aw-ar,ay+ah,     ar);
            ctx.lineTo(ax+ar,    ay+ah);
            ctx.arcTo(ax,ay+ah,   ax,ay+ah-ar,         ar);
            ctx.lineTo(c2X,      c2Y);
            // QR border
            ctx.moveTo(qRX,      qRY);
            ctx.lineTo(qx+qw,    qy+qr);
            ctx.arcTo(qx+qw,qy,  qx+qw-qr,qy,       qr);
            ctx.lineTo(qx+qr,    qy);
            ctx.arcTo(qx,qy,      qx,qy+qr,           qr);
            ctx.lineTo(qx,       qy+qh-qr);
            ctx.arcTo(qx,qy+qh,  qx+qr,qy+qh,        qr);
            ctx.lineTo(qx+qw-qr, qy+qh);
            ctx.arcTo(qx+qw,qy+qh,qx+qw,qy+qh-qr,   qr);
            ctx.lineTo(qRX,      qRY);
        };

        ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.setLineDash([]);

        // Glow chỉ ra ngoài: clipOut cắt phần bên trong boxes
        // Nhiều lớp mỏng → gradient falloff mượt
        // blur tỉ lệ chiều cao từng box
        const glowLayers = [
            { frac: 1.0, alpha: 0.55, lw: 2 },
            { frac: 0.75, alpha: 0.45, lw: 2 },
            { frac: 0.55, alpha: 0.35, lw: 2 },
            { frac: 0.38, alpha: 0.28, lw: 1.5 },
            { frac: 0.22, alpha: 0.18, lw: 1.5 },
            { frac: 0.10, alpha: 0.10, lw: 1 },
        ];

        glowLayers.forEach(({ frac, alpha, lw }) => {
            ctx.save(); clipOut();
            ctx.strokeStyle = `rgba(255,185,0,${alpha})`;
            ctx.shadowColor  = 'rgba(255,200,0,1)';
            // button
            ctx.shadowBlur = bh * frac; ctx.lineWidth = lw;
            ctx.beginPath();
            ctx.moveTo(c1X,by); ctx.lineTo(bx+bw-br,by);
            ctx.arcTo(bx+bw,by,bx+bw,by+br,br); ctx.lineTo(bx+bw,by+bh-br);
            ctx.arcTo(bx+bw,by+bh,bx+bw-br,by+bh,br); ctx.lineTo(bx+br,by+bh);
            ctx.arcTo(bx,by+bh,bx,by+bh-br,br); ctx.lineTo(bx,by+br);
            ctx.arcTo(bx,by,bx+br,by,br); ctx.lineTo(c1X,by);
            ctx.stroke();
            // amount
            ctx.shadowBlur = ah * frac;
            ctx.beginPath();
            ctx.moveTo(c2X,c2Y); ctx.lineTo(ax,ay+ar);
            ctx.arcTo(ax,ay,ax+ar,ay,ar); ctx.lineTo(ax+aw-ar,ay);
            ctx.arcTo(ax+aw,ay,ax+aw,ay+ar,ar); ctx.lineTo(ax+aw,ay+ah-ar);
            ctx.arcTo(ax+aw,ay+ah,ax+aw-ar,ay+ah,ar); ctx.lineTo(ax+ar,ay+ah);
            ctx.arcTo(ax,ay+ah,ax,ay+ah-ar,ar); ctx.lineTo(c2X,c2Y);
            ctx.stroke();
            // QR
            ctx.shadowBlur = qh * frac;
            ctx.beginPath();
            ctx.moveTo(qRX,qRY); ctx.lineTo(qx+qw,qy+qr);
            ctx.arcTo(qx+qw,qy,qx+qw-qr,qy,qr); ctx.lineTo(qx+qr,qy);
            ctx.arcTo(qx,qy,qx,qy+qr,qr); ctx.lineTo(qx,qy+qh-qr);
            ctx.arcTo(qx,qy+qh,qx+qr,qy+qh,qr); ctx.lineTo(qx+qw-qr,qy+qh);
            ctx.arcTo(qx+qw,qy+qh,qx+qw,qy+qh-qr,qr); ctx.lineTo(qRX,qRY);
            ctx.stroke();
            // connectors
            ctx.shadowBlur = bh * frac * 0.4;
            buildConnectors(); ctx.stroke();
            ctx.restore();
        });

        // ── dash chính sắc nét ────────────────────────────────────────────────
        ctx.shadowBlur = 0;
        ctx.setLineDash([7, 16]);
        ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(190,130,0,0.95)';
        ctx.shadowColor = 'rgba(220,160,0,0.95)'; ctx.shadowBlur = 10;
        ctx.save(); clipOut();
        buildConnectors(); ctx.stroke();
        ctx.restore();
        buildBorders(); ctx.stroke();

        ctx.shadowBlur = 0; ctx.setLineDash([]);
    });
}
}


    // ─── 5. FLOATING BUTTON LOGIC ───────────────────────────────────────────────
    // ── payment method detection ─────────────────────────────────────────────
    function getPaymentMethodText() {
        // This is the bank account dropdown (shows "Trung Gian", "KB HCM - Bees Ngáo Ngơ -", etc.)
        const dropdown = document.querySelector('.k-widget.k-dropdown[aria-owns="bankAccountDropdown_listbox"]');
        if (!dropdown) return '';
        const selectedArea = dropdown.querySelector('.k-dropdown-wrap .k-input');
        if (!selectedArea) return '';
        if (dropdown.getAttribute('aria-expanded') === 'true') return ''; // mid-open, ignore
        return (selectedArea.innerText || '').trim();
    }

    function isTrungGianSelected() {
        return getPaymentMethodText().includes('Trung Gian');
    }

    function isBeesNgaoNgoSelected() {
        return getPaymentMethodText().toLowerCase().includes('bees ngáo ngơ');
    }

    // a tab is a "bee tab" if its name contains "bee"
    function isBeeTab(tab) {
        return tab && (tab.name || '').toLowerCase().includes('bee');
    }

    // floating buttons visible when TG or Bees Ngáo Ngơ is selected
    function shouldShowButtons() {
        return isTrungGianSelected() || isBeesNgaoNgoSelected();
    }

    // which tabs to show in the floating grid
    function getVisibleTabs() {
        if (isBeesNgaoNgoSelected()) return state.tabs.filter(t => isBeeTab(t));
        if (isTrungGianSelected())   return state.tabs.filter(t => !isBeeTab(t));
        return [];
    }

    function refreshButtonContent() {
        btnGrid.innerHTML = '';
        const visibleTabs = getVisibleTabs();
        if (state.tabs.length === 0) {
            const emptyBtn = document.createElement('div');
            emptyBtn.className = 'bakist-btn bakist-btn-empty';
            emptyBtn.textContent = 'Hdebt Book chưa có dữ liệu';
            emptyBtn.style.cursor = 'pointer';
            emptyBtn.onclick = () => { state.isOpen = true; renderMain(); };
            btnGrid.appendChild(emptyBtn);
            return;
        }
        const validSelected = visibleTabs.find(t => t.id === state.selectedMiniTabId);
        if (!validSelected && visibleTabs.length > 0) {
            const pinned = visibleTabs.find(t => t.isPinned);
            state.selectedMiniTabId = pinned ? pinned.id : visibleTabs[0].id;
        }
        visibleTabs.forEach(t => {
            const isActive = (t.id === state.selectedMiniTabId);
            const btn = document.createElement('div');
            btn.className = `bakist-btn ${isActive ? 'bakist-btn-active' : 'bakist-btn-inactive'}`;
            btn.dataset.mid = t.id;
            const debt = calcDebt(t);
            const shortName = (t.name || 'NCC').split(' ')[0].toLowerCase();
            btn.style.position = 'relative';
btn.innerHTML = `${isActive ? '<span class="bakist-icon-star" style="position:absolute;top:4px;left:6px;font-size:11px;line-height:1;pointer-events:none;opacity:0.9;">⭐</span>' : ''}<span class="bakist-btn-heart bakist-icon-heart" style="position:absolute;top:4px;right:6px;font-size:11px;line-height:1;pointer-events:none;display:none;">💗</span>${formatK(debt)} (<span class="bakist-btn-name">${shortName}</span>)${t.isPinned ? '<span class="bakist-icon-pin" style="position:absolute;bottom:4px;right:6px;font-size:11px;line-height:1;pointer-events:none;opacity:0.8;">📌</span>' : ''}`;
            btn.onclick = () => {
                state.selectedMiniTabId = t.id;
                GM_setValue("hdebt_book_v1", { tabs: state.tabs, activeTabId: state.activeTabId, selectedMiniTabId: state.selectedMiniTabId });
                // swap active/inactive classes in-place — no re-render, no flash
                btnGrid.querySelectorAll('.bakist-btn[data-mid]').forEach(b => {
                    const isNowActive = (b.dataset.mid == t.id);
                    b.classList.toggle('bakist-btn-active',   isNowActive);
                    b.classList.toggle('bakist-btn-inactive', !isNowActive);
                    // star icon
                    let star = b.querySelector('.bakist-icon-star');
                    if (isNowActive && !star) {
                        star = document.createElement('span');
                        star.className = 'bakist-icon-star';
                        star.style.cssText = 'position:absolute;top:4px;left:6px;font-size:11px;line-height:1;pointer-events:none;opacity:0.9;';
                        star.textContent = '⭐';
                        b.appendChild(star);
                    } else if (!isNowActive && star) {
                        star.remove();
                    }
                });
            };
            btn.oncontextmenu = e => {
                e.preventDefault();
                const payInput = document.getElementById('payingAmtInvoice') || document.querySelector('input[ng-model*="payingAmt"]');
                const amount = payInput ? (parseFloat(payInput.value.replace(/[^0-9]/g,'')) || 0) : 0;
                showQRModal(t, amount, btn);
            };
            btnGrid.appendChild(btn);
        });
    }

    // ── strikethrough + heart icon ────────────────────────────────────────────
    function updateStrikethrough() {
        const payInput = document.getElementById('payingAmtInvoice')
                      || document.querySelector('input[ng-model*="payingAmt"]');
        const payAmt = payInput ? (parseFloat(payInput.value.replace(/[^0-9]/g, '')) || 0) : 0;

        // find the best-match tab: smallest positive debt >= payAmt
        let heartTabId = null;
        if (payAmt > 0) {
            let bestDebt = Infinity;
            btnGrid.querySelectorAll('.bakist-btn[data-mid]').forEach(btn => {
                const tab = state.tabs.find(t => t.id == btn.dataset.mid);
                if (!tab) return;
                const debt = calcDebt(tab);
                if (debt >= payAmt && debt < bestDebt) { bestDebt = debt; heartTabId = tab.id; }
            });
        }

        btnGrid.querySelectorAll('.bakist-btn[data-mid]').forEach(btn => {
            const tab = state.tabs.find(t => t.id == btn.dataset.mid);
            if (!tab) return;

            // heart
            const heartSpan = btn.querySelector('.bakist-btn-heart');
            if (heartSpan) heartSpan.style.display = (tab.id === heartTabId) ? '' : 'none';

            // strikethrough — skip bee tabs
            if (isBeeTab(tab)) return;
            const debt = calcDebt(tab);
            const shouldStrike = payAmt > 0 && payAmt >= debt;
            const nameSpan = btn.querySelector('.bakist-btn-name');
            btn.style.opacity = '';
            if (nameSpan) {
                nameSpan.style.textDecoration         = shouldStrike ? 'line-through' : '';
                nameSpan.style.textDecorationColor    = shouldStrike ? '#000' : '';
                nameSpan.style.textDecorationThickness = shouldStrike ? '2px' : '';
            }
        });
    }

    // ── detect KiotViet modal/popup đang mở (Kendo UI + Bootstrap modal) ──────
    function isKiotvietModalOpen() {
        // .k-overlay = Kendo UI backdrop khi có dialog/window
        if (document.querySelector('.k-overlay')) return true;
        // .k-window-wrapper visible = Kendo window popup
        const kwin = document.querySelector('.k-window-wrapper');
        if (kwin && kwin.offsetParent !== null) return true;
        // Bootstrap modal đang mở
        if (document.querySelector('.modal.in, .modal.show')) return true;
        return false;
    }

    let _lastBtnPos = '';
    function updateButtonPosition() {
        const btnIn   = document.getElementById('printTransaction') || document.querySelector('.btn-secondary');
        const btnSave = document.getElementById('saveTransaction');
        if (btnSave && btnIn && shouldShowButtons() && !state.isOpen && !btnWrapForceHidden && !qrLauncher.classList.contains('open') && !isKiotvietModalOpen()) {
            const rectIn    = btnIn.getBoundingClientRect();
            const rectSave  = btnSave.getBoundingClientRect();
            const w = rectSave.right - rectIn.left;
            const l = rectIn.left;
            const b = window.innerHeight - rectIn.top + 12;
            const posKey = w + '|' + l + '|' + b;
            if (posKey !== _lastBtnPos) {
                _lastBtnPos = posKey;
                // move without toggling visibility — no flash
                btnWrap.style.width  = w + 'px';
                btnWrap.style.left   = l + 'px';
                btnWrap.style.bottom = b + 'px';
                btnWrap.style.top    = '';
                if (!btnWrap.classList.contains('visible')) {
                    btnWrap.classList.add('visible');
                }
            } else if (!btnWrap.classList.contains('visible')) {
                btnWrap.classList.add('visible');
            }
        } else {
            if (_lastBtnPos !== '') {
                _lastBtnPos = '';
                btnWrap.classList.remove('visible');
                btnWrap.style.left = '-9999px';
            }
        }
    }

let lastInjectedTabId = null;
let lastShouldInject = false;
let lastPaymentKey = '';
setInterval(() => {
    updateButtonPosition();
    updateStrikethrough();

    // re-render grid whenever the bank account selection changes
    const currentPaymentKey = getPaymentMethodText();
    if (currentPaymentKey !== lastPaymentKey) {
        lastPaymentKey = currentPaymentKey;
        refreshButtonContent();
    }

    const noteField = document.querySelector('textarea[ng-model="$root.activeCart.Description"]');

    const cartQtyEl = document.querySelector('span[ng-show="$root.session.Setting.UseTotalQuantity"]');
    const cartQty   = cartQtyEl ? (parseInt(cartQtyEl.textContent.trim()) || 0) : 0;
    const payingEl  = document.getElementById('payingAmtInvoice');
    const payingAmt = payingEl ? (parseFloat(payingEl.value.replace(/[^0-9]/g, '')) || 0) : 0;

    // inject only when the right payment method is active AND cart has qty+amount
    const shouldInject = shouldShowButtons() && (cartQty * payingAmt !== 0);

    // clear the note whenever the condition flips from true → false
    if (!shouldInject && lastShouldInject) {
        if (noteField) {
            const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
            nativeSetter.call(noteField, '');
            noteField.dispatchEvent(new Event('input', { bubbles: true }));
        }
        lastInjectedTabId = null;
    }

    lastShouldInject = shouldInject;

    if (shouldInject && state.selectedMiniTabId !== lastInjectedTabId) {
        const selectedTab = state.tabs.find(t => t.id === state.selectedMiniTabId);
        if (noteField && selectedTab) {
            const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
            nativeSetter.call(noteField, 'ck → ' + (selectedTab.name || '').toLowerCase() + '. ');
            noteField.dispatchEvent(new Event('input', { bubbles: true }));
        }
        lastInjectedTabId = state.selectedMiniTabId;
    }
}, 300);
    // ─── 6. MAIN OVERLAY RENDER ─────────────────────────────────────────────────
    function renderMain(focusId = null) {
        mainOverlay.style.display = state.isOpen ? 'flex' : 'none';
        if (!state.isOpen) return;

        const activeTab = state.tabs.find(t => t.id === state.activeTabId);
        const isUnlocked = activeTab && activeTab.isNameLocked && activeTab.isDebtLocked;
        let remainValue = 0, remainText = "TỔNG CÒN NỢ", remainColor = "#cf1322";
        if (activeTab) {
            remainValue = calcDebt(activeTab);
            if (remainValue === 0)      { remainText = "HẾT NỢ";       remainColor = "#00a65a"; }
            else if (remainValue > 0)   { remainText = "OV CÒN NỢ";    remainColor = "#cf1322"; }
            else                        { remainText = "NCC NỢ NGƯỢC"; remainColor = "#1890ff"; }
        }

        mainOverlay.innerHTML = `
<div class="bakist-head">
    <div class="bakist-tabs">
        ${state.tabs.map(t => `
            <div class="bakist-t ${t.id === state.activeTabId ? 'active' : ''} ${t.isPinned ? 'is-pnd' : ''}" data-id="${t.id}" data-drop-id="${t.id}">
                ${t.isPinned ? '📌 ' : ''}${(t.name || '...').toLowerCase()} <span style="font-family:var(--mono);margin-left:5px;font-size:14px;font-weight:700;color:#cc2200;">${formatK(calcDebt(t))}</span>
            </div>`).join('')}
        <div class="bakist-t" id="add-v6-btn">＋ NCC</div>
    </div>
    <div id="bakist-title-btn" style="flex-shrink:0;cursor:pointer;display:flex;align-items:center;gap:6px;padding:0 14px;height:100%;border-left:1px solid var(--border);user-select:none;" title="Click để sync contacts">
        <div class="dot"></div>
        <span style="font-size:23px;font-weight:800;color:var(--text);letter-spacing:0.02em;white-space:nowrap;">đối soát = <span style="color:var(--accent);font-family:var(--mono);">${formatK(state.tabs.reduce((sum, t) => sum + (t.payments||[]).reduce((a, b) => a + (parseFloat(b.amount)||0), 0), 0))}</span></span>
    </div>
</div>
            <div class="bakist-main-split">
                ${activeTab ? `
                    <div class="split-left">
                        <div class="sl-row input-card ${activeTab.isNameLocked ? 'locked' : ''}">
                            ${activeTab.isNameLocked
                              ? `<span style="flex:1;padding:0 12px;font-size:14px;font-weight:600;color:var(--text-sub);font-family:var(--mono);">${activeTab.name}</span>`
                              : `<input type="text" autocomplete="off" id="v6-name" placeholder="tên ncc" value="${activeTab.name || ''}">`}
                            <span class="ic-lock" id="l-name">${activeTab.isNameLocked ? '🔒' : '🔓'}</span>
                        </div>
                        <div class="sl-row input-card ${activeTab.isDebtLocked ? 'locked' : ''}">
                            ${activeTab.isDebtLocked
                              ? `<span style="padding:0 12px;font-size:14px;font-weight:600;color:var(--text);font-family:var(--mono);flex:1;">${formatK(activeTab.initialDebt)} (nợ gốc)</span>`
                              : `<input type="text" autocomplete="off" id="v6-debt" placeholder="số tiền đang nợ" style="flex:1;" value="${(activeTab.initialDebt||0) !== 0 ? Math.round((activeTab.initialDebt||0)/1000) : ''}">`}
                            <span class="ic-lock" id="l-debt">${activeTab.isDebtLocked ? '🔒' : '🔓'}</span>
                        </div>
                        <div class="sl-row input-card">
                            <input type="text" autocomplete="off" id="v6-code" placeholder="Za code to banking" style="flex:1;font-family:var(--mono);font-size:13px;" value="${activeTab.code||''}">
                            <span style="padding:0 10px;font-size:16px;flex-shrink:0;color:${activeTab.linkedContact ? 'var(--accent)' : 'var(--text-dim)'};">${activeTab.linkedContact ? '✓' : '☠'}</span>
                        </div>
                        <div class="sl-sep"></div>
                        <div class="${isUnlocked ? '' : 'bakist-locked-ui'}">
                            <div class="sl-row input-card ${activeTab.isCarryOverLocked && (activeTab.carryOver||0) !== 0 ? 'locked' : ''}">
                                ${activeTab.isCarryOverLocked && (activeTab.carryOver||0) !== 0
                                  ? `<span style="padding:0 12px;font-size:14px;font-weight:600;color:var(--text);font-family:var(--mono);flex:1;">${formatK(activeTab.carryOver)} (dư kỳ trước)</span>`
                                  : `<input type="text" autocomplete="off" id="v6-carryover" placeholder="tồn đọng cũ (nếu có)" style="flex:1;" value="${(activeTab.carryOver||0) !== 0 ? Math.abs(Math.round((activeTab.carryOver||0)/1000)) : ''}">`}
                                <span class="ic-lock" id="l-carryover">${activeTab.isCarryOverLocked && (activeTab.carryOver||0) !== 0 ? '🔒' : '🔓'}</span>
                            </div>
                            <div class="sl-sep"></div>
                            <div class="sl-row input-card ${activeTab.isExtra1Locked && (activeTab.extraDebt1||0) > 0 ? 'locked' : ''}">
                                ${activeTab.isExtra1Locked
                                  ? `<span style="padding:0 12px;font-size:14px;font-weight:600;color:var(--text);font-family:var(--mono);flex:1;">${formatK(activeTab.extraDebt1)} (thêm 1)</span>`
                                  : `<input type="text" autocomplete="off" id="v6-extra1" placeholder="nhập thêm lần 1" style="flex:1;" value="${(activeTab.extraDebt1||0) !== 0 ? Math.round((activeTab.extraDebt1||0)/1000) : ''}">`}
                                <span class="ic-lock" id="l-extra1">${activeTab.isExtra1Locked && (activeTab.extraDebt1||0) > 0 ? '🔒' : '🔓'}</span>
                            </div>
                            <div class="sl-row input-card ${activeTab.isExtra2Locked && (activeTab.extraDebt2||0) > 0 ? 'locked' : ''}">
                                ${activeTab.isExtra2Locked
                                  ? `<span style="padding:0 12px;font-size:14px;font-weight:600;color:var(--text);font-family:var(--mono);flex:1;">${formatK(activeTab.extraDebt2)} (thêm 2)</span>`
                                  : `<input type="text" autocomplete="off" id="v6-extra2" placeholder="nhập thêm lần 2" style="flex:1;" value="${(activeTab.extraDebt2||0) !== 0 ? Math.round((activeTab.extraDebt2||0)/1000) : ''}">`}
                                <span class="ic-lock" id="l-extra2">${activeTab.isExtra2Locked && (activeTab.extraDebt2||0) > 0 ? '🔒' : '🔓'}</span>
                            </div>
                            <div class="sl-row input-card ${activeTab.isExtra3Locked && (activeTab.extraDebt3||0) > 0 ? 'locked' : ''}">
                                ${activeTab.isExtra3Locked
                                  ? `<span style="padding:0 12px;font-size:14px;font-weight:600;color:var(--text);font-family:var(--mono);flex:1;">${formatK(activeTab.extraDebt3)} (thêm 3)</span>`
                                  : `<input type="text" autocomplete="off" id="v6-extra3" placeholder="nhập thêm lần 3" style="flex:1;" value="${(activeTab.extraDebt3||0) !== 0 ? Math.round((activeTab.extraDebt3||0)/1000) : ''}">`}
                                <span class="ic-lock" id="l-extra3">${activeTab.isExtra3Locked && (activeTab.extraDebt3||0) > 0 ? '🔒' : '🔓'}</span>
                            </div>
                            <div class="sl-row input-card ${activeTab.isExtra4Locked && (activeTab.extraDebt4||0) > 0 ? 'locked' : ''}">
                                ${activeTab.isExtra4Locked
                                  ? `<span style="padding:0 12px;font-size:14px;font-weight:600;color:var(--text);font-family:var(--mono);flex:1;">${formatK(activeTab.extraDebt4)} (thêm 4)</span>`
                                  : `<input type="text" autocomplete="off" id="v6-extra4" placeholder="nhập thêm lần 4" style="flex:1;" value="${(activeTab.extraDebt4||0) !== 0 ? Math.round((activeTab.extraDebt4||0)/1000) : ''}">`}
                                <span class="ic-lock" id="l-extra4">${activeTab.isExtra4Locked && (activeTab.extraDebt4||0) > 0 ? '🔒' : '🔓'}</span>
                            </div>
                            <div class="sl-row input-card ${activeTab.isExtra5Locked && (activeTab.extraDebt5||0) > 0 ? 'locked' : ''}">
                                ${activeTab.isExtra5Locked
                                  ? `<span style="padding:0 12px;font-size:14px;font-weight:600;color:var(--text);font-family:var(--mono);flex:1;">${formatK(activeTab.extraDebt5)} (thêm 5)</span>`
                                  : `<input type="text" autocomplete="off" id="v6-extra5" placeholder="nhập thêm lần 5" style="flex:1;" value="${(activeTab.extraDebt5||0) !== 0 ? Math.round((activeTab.extraDebt5||0)/1000) : ''}">`}
                                <span class="ic-lock" id="l-extra5">${activeTab.isExtra5Locked && (activeTab.extraDebt5||0) > 0 ? '🔒' : '🔓'}</span>
                            </div>
                            <div class="sl-row input-card ${activeTab.isExtra6Locked && (activeTab.extraDebt6||0) > 0 ? 'locked' : ''}">
                                ${activeTab.isExtra6Locked
                                  ? `<span style="padding:0 12px;font-size:14px;font-weight:600;color:var(--text);font-family:var(--mono);flex:1;">${formatK(activeTab.extraDebt6)} (thêm 6)</span>`
                                  : `<input type="text" autocomplete="off" id="v6-extra6" placeholder="nhập thêm lần 6" style="flex:1;" value="${(activeTab.extraDebt6||0) !== 0 ? Math.round((activeTab.extraDebt6||0)/1000) : ''}">`}
                                <span class="ic-lock" id="l-extra6">${activeTab.isExtra6Locked && (activeTab.extraDebt6||0) > 0 ? '🔒' : '🔓'}</span>
                            </div>
                            <div class="remain-box ${remainValue === 0 ? 'zero' : remainValue < 0 ? 'neg' : ''}" style="margin-top:12px;" ${remainValue < 0 && !activeTab.debtTransferredTo ? `draggable="true" id="remain-drag-src"` : ''} ${remainValue > 0 ? `draggable="true" id="remain-drag-ov"` : ''}>
                                <span class="remain-title" style="color:${remainColor};">${remainText}</span>
                                <span class="remain-val" style="color:${remainColor};">${formatK(remainValue)}</span>
                                ${activeTab.debtTransferredTo ? `<span class="remain-val" style="color:var(--text-sub);font-size:25px;margin-top:6px;">đã chuyển cho ${activeTab.debtTransferredTo}</span>` : ''}
                            </div>
                        </div>
                    </div>
                    <div class="split-right ${isUnlocked ? '' : 'bakist-locked-ui'}">
                        <input type="text" autocomplete="off" id="v6-top-input" class="v6-pay-top ${(() => { const pmts = activeTab.payments || []; return (pmts.length > 0 && pmts.every(p => p.isMatched)) ? 'all-matched' : ''; })()}" placeholder="${(() => { const pmts = activeTab.payments || []; return (pmts.length > 0 && pmts.every(p => p.isMatched)) ? 'tổng ' + pmts.length + ' giao dịch đã ổn, có thể bấm nút Tổng Kết' : 'nhập tay ...'; })()}">
                        <div id="v6-list-container">
                            ${(activeTab.payments || []).slice().reverse().map((p, i) => `
                                <div class="pay-card ${p.isMatched ? 'is-matched' : ''}" data-pid="${p.pid}" draggable="true">
                                    <span class="del-p" data-pid="${p.pid}">✕</span>
                                    <span class="pay-num">#${activeTab.payments.length - i}</span>
                                    <span class="pay-amt">${formatK(p.amount)}</span>
                                    <div style="display:flex;flex-direction:column;align-items:center;gap:4px;padding:0 4px 22px 4px;width:100%;box-sizing:border-box;">
                                        ${getSysNote(p) ? `<span class="sys-note">${getSysNote(p).replace(/</g,'&lt;')}</span>` : ''}
                                        ${p.note && !p.sysTs ? `<span class="sys-note" style="font-style:italic;">${p.note.replace(/</g,'&lt;')}</span>` : ''}
                                        <input type="text" autocomplete="off" class="row-note" data-pid="${p.pid}" value="${(p.userNote||'').replace(/"/g,'&quot;')}" placeholder="+ ghi chú…">
                                    </div>
                                    <div class="btn-match ${p.isMatched ? 'matched' : ''}" data-pid="${p.pid}">
                                        ${p.isMatched ? '🖼 ✓' : '? ?'}
                                    </div>
                                    <span class="card-drag-hint">☰</span>
                                </div>`).join('')}
                        </div>
                    </div>
                ` : `
                <div class="bakist-welcome">
                    <div class="bakist-welcome-btn" id="w-new">
                        <span class="bakist-welcome-icon">＋</span>
                        <span class="bakist-welcome-label">Thêm NCC</span>
                    </div>
                    <div class="bakist-welcome-btn" id="w-import">
                        <span class="bakist-welcome-icon">↑</span>
                        <span class="bakist-welcome-label">Import JSON</span>
                    </div>
                    <div class="bakist-welcome-btn" id="w-export">
                        <span class="bakist-welcome-icon">↓</span>
                        <span class="bakist-welcome-label">Export JSON</span>
                    </div>
                </div>`}
            </div>
            ${activeTab ? `
                <div class="bakist-foots ${isUnlocked ? '' : 'bakist-locked-ui'}">
                    <button class="bakist-b b-close"   id="v6-close" title="Lưu &amp; đóng">✕</button>
                    <button class="bakist-b b-export" id="v6-export" title="Export JSON">e↓</button>
                    <button class="bakist-b b-import" id="v6-import" title="Import JSON">i↑</button>
                    <button class="bakist-b b-sync"   id="v6-sync"   title="Sync danh bạ">↻</button>
                    <button class="bakist-b b-paste"   id="v6-paste">⏬ DÁN TIỀN TRÊN HĐ</button>
                    <button class="bakist-b b-summary" id="v6-summary">📋 Tổng Kết (văn bản)</button>
                    <button class="bakist-b b-img"     id="v6-img">🖼 Tổng Kết (ảnh)</button>
                    <button class="bakist-b b-pin"     id="v6-pin">${activeTab.isPinned ? '📍 BỎ GHIM' : '📌 GHIM TAB'}</button>
                    <button class="bakist-b b-del"     id="v6-del">${getDelButtonText()}</button>
                </div>` : ''}
        `;

        setupMainEvents(activeTab, isUnlocked);
        if (focusId) {
            setTimeout(() => {
                const el = document.getElementById(focusId);
                if (el) { el.focus(); el.select(); }
            }, 0);
        }
        requestAnimationFrame(fitText);
        requestAnimationFrame(scaleGrid);
    }

    function fitText() {
        mainOverlay.querySelectorAll('.remain-val').forEach(el => {
            el.style.fontSize = '52px';
            while (el.scrollWidth > el.parentElement.clientWidth - 28 && parseFloat(el.style.fontSize) > 14) {
                el.style.fontSize = (parseFloat(el.style.fontSize) - 1) + 'px';
            }
        });
    }

    function scaleGrid() {
        const container = document.getElementById('v6-list-container');
        if (!container) return;
        const count = container.children.length;
        if (count === 0) return;
        const W = container.clientWidth;
        const H = container.clientHeight;
        const gap = 8;
        let bestCols = 1, bestScore = Infinity;
        for (let cols = 1; cols <= Math.min(count, 7); cols++) {
            const rows = Math.ceil(count / cols);
            const cardW = (W - gap * (cols - 1)) / cols;
            const cardH = (H - gap * (rows - 1)) / rows;
            const ratio = cardW / cardH;
            const score = Math.abs(ratio - 1.2) + (cardH < 80 ? (80 - cardH) * 0.05 : 0);
            if (score < bestScore) { bestScore = score; bestCols = cols; }
        }
        const cols = bestCols;
        const rows = Math.ceil(count / cols);
        const cardH = (H - gap * (rows - 1)) / rows;
        const amtSize  = Math.max(13, Math.min(30, cardH * 0.28));
        const metaSize = Math.max(8,  Math.min(11, cardH * 0.10));
        const padV     = Math.max(5,  Math.min(12, cardH * 0.08));
        const gapV     = Math.max(3,  Math.min(8,  cardH * 0.06));
        const btnPad   = Math.max(2,  Math.min(5,  cardH * 0.04));
        container.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
        container.style.gridTemplateRows    = `repeat(${rows}, 1fr)`;
        container.style.alignContent        = 'stretch';
        container.style.setProperty('--card-amt',     amtSize  + 'px');
container.style.setProperty('--card-meta',    metaSize + 'px');
container.style.setProperty('--card-num',     Math.min(54, metaSize * 6) + 'px');        container.style.setProperty('--card-pad',     padV     + 'px ' + Math.max(6, padV * 0.8) + 'px');
        container.style.setProperty('--card-gap',     gapV     + 'px');
        container.style.setProperty('--card-btn-pad', btnPad   + 'px');
    }

    function getDelButtonText() {
return isConfirmReady ? "⚠️ BẤM cái nữa LÀ XÓA THẬT" : (delCountdown < 6 ? `CHỜ (${delCountdown})` : "❌ XOÁ BẢNG");
    }

    function setupMainEvents(activeTab, isUnlocked) {
        const dragSrc = document.getElementById('remain-drag-src');
        if (dragSrc && activeTab) {
            dragSrc.ondragstart = e => {
                dragSrc.classList.add('dragging');
                e.dataTransfer.setData('text/plain', JSON.stringify({ type: 'neg', fromId: activeTab.id, fromName: activeTab.name, amount: Math.abs(calcDebt(activeTab)) }));
                e.dataTransfer.effectAllowed = 'copy';
            };
            dragSrc.ondragend = () => dragSrc.classList.remove('dragging');
        }
        const dragOv = document.getElementById('remain-drag-ov');
        if (dragOv && activeTab) {
            dragOv.ondragstart = e => {
                dragOv.classList.add('dragging');
                e.dataTransfer.setData('text/plain', JSON.stringify({ type: 'ov', amount: calcDebt(activeTab) }));
                e.dataTransfer.effectAllowed = 'copy';
            };
            dragOv.ondragend = () => dragOv.classList.remove('dragging');
        }
        const topInput = document.getElementById('v6-top-input');
        if (topInput) {
            topInput.ondragover = e => { e.preventDefault(); topInput.classList.add('drop-over'); };
            topInput.ondragleave = () => topInput.classList.remove('drop-over');
            topInput.ondrop = e => {
                e.preventDefault(); topInput.classList.remove('drop-over');
                try {
                    const data = JSON.parse(e.dataTransfer.getData('text/plain'));
                    if (data.type !== 'ov') return;
                    const val = data.amount;
                    if (val > 0) { activeTab.payments.push({ pid: Date.now(), amount: val, ...payNote('chuyển bằng tk shop:'), isMatched: false }); topInput.value = ''; saveAndRenderAll(); }
                } catch(err) {}
            };
        }
        mainOverlay.querySelectorAll('.bakist-t[data-drop-id]').forEach(tab => {
            tab.ondragover = e => { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; tab.classList.add('drop-target'); };
            tab.ondragleave = () => tab.classList.remove('drop-target');
            tab.ondrop = e => {
                e.preventDefault(); tab.classList.remove('drop-target');
                try {
                    const data = JSON.parse(e.dataTransfer.getData('text/plain'));
                    if (data.type !== 'neg') return;
                    const { fromId, fromName, amount } = data;
                    const toId = parseInt(tab.dataset.dropId);
                    if (toId === fromId) return;
                    const toTab   = state.tabs.find(t => t.id === toId);
                    const fromTab = state.tabs.find(t => t.id === fromId);
                    if (!toTab || !fromTab) return;
                    const shortName = (fromName || 'NCC').split(' ')[0];
                    toTab.payments.push({ pid: Date.now(), amount, ...payNote('chuyển nợ từ ' + shortName), isMatched: false });
                    fromTab.debtTransferredTo = (toTab.name || 'NCC').split(' ')[0];
                    saveAndRenderAll();
                } catch(err) {}
            };
        });

const titleBtn = document.getElementById('bakist-title-btn');
if (titleBtn) {
    titleBtn.onclick = () => {
        const span = titleBtn.querySelector('span');
        const orig = span.innerHTML;
        span.innerHTML = 'syncing…';
        titleBtn.style.pointerEvents = 'none';
        syncContacts(ok => {
            span.innerHTML = ok ? '✓ synced' : '✕ failed';
            titleBtn.style.color = ok ? 'var(--accent)' : 'var(--danger)';
            setTimeout(() => {
                span.innerHTML = orig;
                titleBtn.style.color = '';
                titleBtn.style.pointerEvents = '';
            }, 1500);
        });
    };
    titleBtn.onmouseenter = () => titleBtn.style.background = 'var(--surface2)';
    titleBtn.onmouseleave = () => titleBtn.style.background = '';
}

        const exportBtn = document.getElementById('v6-export');
        if (exportBtn) exportBtn.onclick = () => {
            const data = GM_getValue("hdebt_book_v1", {});
            const json = JSON.stringify(data, null, 2);
            const ts   = new Date().toISOString().slice(0,16).replace('T','_').replace(':','-');
            const blob = new Blob([json], { type: 'application/json' });
            const url  = URL.createObjectURL(blob);
            const a    = document.createElement('a');
            a.href = url; a.download = `hdebt_book_log_${ts}.json`;
            a.click(); URL.revokeObjectURL(url);
        };

        const importBtn = document.getElementById('v6-import');
        if (importBtn) importBtn.onclick = () => {
            document.getElementById('bakist-import-textarea').value = '';
            document.getElementById('bakist-import-file').value = '';
            importModal.classList.add('open');
            // fetch GitHub backup list
            const ghList = document.getElementById('bakist-gh-list');
            if (ghList) {
                if (!ghEnabled()) {
                    ghList.innerHTML = '<span class="bakist-gh-status err">// github not configured — fill GH_TOKEN in script</span>';
                } else {
                    ghList.innerHTML = '<span class="bakist-gh-status">// fetching from github...</span>';
                    ghFetchList((ok, files) => {
                        if (!ok || files.length === 0) {
                            ghList.innerHTML = '<span class="bakist-gh-status err">// ' + (ok ? 'no backups found' : 'fetch failed — check token / network') + '</span>';
                            return;
                        }
                        ghList.innerHTML = '';
                        files.forEach(f => {
                            const row = document.createElement('div');
                            row.className = 'bakist-gh-file';
                            const namePretty = f.name.replace('hdebt_book_log_','').replace('.json','').replace(/-/g,' ');
                            const sizeKb = (f.size / 1024).toFixed(1) + ' kb';
                            row.innerHTML = `<span class="gf-name">${namePretty}</span><span class="gf-size">${sizeKb}</span>`;
                            row.onclick = () => {
                                ghList.querySelectorAll('.bakist-gh-file').forEach(r => r.classList.remove('selected'));
                                row.classList.add('selected');
                                row.innerHTML = `<span class="gf-name">${namePretty}</span><span class="gf-size">loading...</span>`;
                                ghLoadFile(f.name, (ok2, json) => {
                                    row.innerHTML = `<span class="gf-name">${namePretty}</span><span class="gf-size">${ok2 ? '✓ loaded' : '✗ failed'}</span>`;
                                    if (ok2 && json) {
                                        document.getElementById('bakist-import-textarea').value = JSON.stringify(json, null, 2);
                                    }
                                });
                            };
                            ghList.appendChild(row);
                        });
                    });
                }
            }
        };

        const syncBtn = document.getElementById('v6-sync');
        if (syncBtn) syncBtn.onclick = function() {
            const btn = this;
            btn.style.pointerEvents = 'none';
            const done = (txt, ok) => {
                btn.textContent = txt;
                btn.style.color = ok === true ? '#00ff80' : ok === false ? '#ff6060' : '';
                btn.style.fontSize = '10px';
            };
            const reset = () => {
                btn.textContent = '↻'; btn.style.pointerEvents = '';
                btn.style.color = ''; btn.style.fontSize = '';
            };
            done('0/3', null);
            // step 1: sync bakist contacts
            syncContacts(ok1 => {
                done('1/3' + (ok1 ? ' ✓' : ' ✗'), ok1 ? null : false);
                // step 2: sync assets (images)
                syncAllAssets((okAssets, total) => {
                    const ok2 = okAssets === total;
                    done('2/3' + (ok2 ? ' ✓' : ' ✗'), ok2 ? null : false);
                    // step 3: export backup to GitHub
                    ghExportBackup(ok3 => {
                        if (ok1 && ok2 && ok3)        done('synced ✓', true);
                        else if (!ok1 && !ok2 && !ok3) done('failed ✗', false);
                        else                           done('partial ~', null);
                        setTimeout(reset, 2200);
                    });
                });
            });
        };
        document.getElementById('bakist-import-cancel').onclick = () => importModal.classList.remove('open');
        document.getElementById('bakist-import-close-btn').onclick = () => importModal.classList.remove('open');
        document.getElementById('bakist-import-file').onchange = function() {
            const file = this.files[0]; if (!file) return;
            const reader = new FileReader();
            reader.onload = e => { document.getElementById('bakist-import-textarea').value = e.target.result; };
            reader.readAsText(file);
        };
        document.getElementById('bakist-import-confirm').onclick = () => {
            const raw = document.getElementById('bakist-import-textarea').value.trim();
            try {
                const parsed = JSON.parse(raw);
                if (!Array.isArray(parsed.tabs)) throw new Error('Thiếu trường tabs');
                state.tabs              = parsed.tabs;
                state.activeTabId       = parsed.activeTabId || (parsed.tabs[0] ? parsed.tabs[0].id : null);
                state.selectedMiniTabId = parsed.selectedMiniTabId || state.activeTabId;
                importModal.classList.remove('open');
                saveAndRenderAll();
            } catch(err) {
                document.getElementById('bakist-import-textarea').style.borderColor = '#f85149';
                document.getElementById('bakist-import-textarea').placeholder = '❌ JSON không hợp lệ: ' + err.message;
            }
        };

        document.getElementById('add-v6-btn').onclick = () => {
            const id = Date.now();
            state.tabs.push({ id, name: "", initialDebt: 0, carryOver: 0, isCarryOverLocked: false, extraDebt1: 0, extraDebt2: 0, extraDebt3: 0, extraDebt4: 0, extraDebt5: 0, extraDebt6: 0, payments: [], isPinned: false, isNameLocked: false, isDebtLocked: false, isExtra1Locked: false, isExtra2Locked: false, isExtra3Locked: false, isExtra4Locked: false, isExtra5Locked: false, isExtra6Locked: false });
            state.activeTabId = id;
            if (!state.selectedMiniTabId) state.selectedMiniTabId = id;
            resetDeleteState();
            saveAndRenderAll('v6-name');
        };

        // ── Welcome-screen shortcut buttons (shown when hdebt book is empty) ──
        const addNewNcc = () => document.getElementById('add-v6-btn').click();
        const openImportModal = () => document.getElementById('v6-import') && document.getElementById('v6-import').click();
        const doExport = () => document.getElementById('v6-export') && document.getElementById('v6-export').click();
        const wNew = document.getElementById('w-new');
        const wImp = document.getElementById('w-import');
        const wExp = document.getElementById('w-export');
        if (wNew) wNew.onclick = addNewNcc;
        if (wImp) wImp.onclick = openImportModal;
        if (wExp) wExp.onclick = doExport;

        if (!activeTab) return;

        mainOverlay.querySelectorAll('.bakist-t[data-id]').forEach(t => t.onclick = () => {
            resetDeleteState();
            state.activeTabId = parseInt(t.dataset.id);
            renderMain();
        });

        // ── helper: commit a field value and save ────────────────────────────
        const makeCommit = (id, field, lock) => () => {
            const el = document.getElementById(id);
            if (!el) return;
            if (id === 'v6-name') {
                const val = el.value.trim();
                if (!val) return;                          // don't lock empty name
                activeTab[field] = val.toLowerCase();
                activeTab[lock]  = true;
            } else {
                const val = parseK(el.value);
                const isExtraField = id.startsWith('v6-extra');
                if (id === 'v6-debt' && val === 0) {
                    el.classList.add('bakist-shake');
                    setTimeout(() => el.classList.remove('bakist-shake'), 400);
                    return;
                }
                if (isExtraField && val === 0) {
                    activeTab[field] = 0; activeTab[lock] = false;
                } else {
                    activeTab[field] = val; activeTab[lock] = true;
                }
            }
            saveAndRenderAll(id === 'v6-debt' ? 'v6-top-input' : null);
        };

        const bindInput = (id, field, lock) => {
            const el = document.getElementById(id);
            if (el) {
                if (el.value) { el.focus(); el.select(); }
                const commit = makeCommit(id, field, lock);
                el.onkeydown = e => {
                    if (e.key === 'Enter' || e.key === 'Tab') {
                        e.preventDefault();
                        commit();
                    }
                };
                el.onblur = commit;
            }
            const lockEl = document.getElementById('l-' + id.split('-')[1]);
            if (lockEl) lockEl.onclick = () => { activeTab[lock] = !activeTab[lock]; saveAndRenderAll(); };
        };

        bindInput('v6-name', 'name', 'isNameLocked');

        // ── code input: lookup & auto-link ───────────────────────────────────
        const codeEl = document.getElementById('v6-code');
        if (codeEl) {
            const commitCode = () => {
                const val = codeEl.value.trim();
                activeTab.code = val;
                if (val === '') { delete activeTab.linkedContact; }
                else {
                    const found = lookupByCode(val);
                    if (found) activeTab.linkedContact = found;
                    else delete activeTab.linkedContact;
                }
                saveAndRenderAll();
            };
            codeEl.onkeydown = e => { if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); commitCode(); } };
            codeEl.onblur = commitCode;
        }
        bindInput('v6-debt', 'initialDebt', 'isDebtLocked');

        if (isUnlocked) {
            const coEl = document.getElementById('v6-carryover');
            if (coEl) {
                const commitCo = () => {
                    const raw = parseFloat(coEl.value.replace(/[^0-9.-]/g, '')) || 0;
                    if (raw === 0) { activeTab.carryOver = 0; activeTab.isCarryOverLocked = false; }
                    else { activeTab.carryOver = -Math.abs(raw * 1000); activeTab.isCarryOverLocked = true; }
                    saveAndRenderAll('v6-top-input');
                };
                coEl.onkeydown = e => { if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); commitCo(); } };
                coEl.onblur = commitCo;
            }
            const coLock = document.getElementById('l-carryover');
            if (coLock) coLock.onclick = () => { activeTab.isCarryOverLocked = !activeTab.isCarryOverLocked; saveAndRenderAll(); };

            bindInput('v6-extra1', 'extraDebt1', 'isExtra1Locked');
            bindInput('v6-extra2', 'extraDebt2', 'isExtra2Locked');
            bindInput('v6-extra3', 'extraDebt3', 'isExtra3Locked');
            bindInput('v6-extra4', 'extraDebt4', 'isExtra4Locked');
            bindInput('v6-extra5', 'extraDebt5', 'isExtra5Locked');
            bindInput('v6-extra6', 'extraDebt6', 'isExtra6Locked');

            document.getElementById('v6-top-input').oninput = e => { e.target.value = e.target.value.replace(/[^0-9]/g, ''); };
            document.getElementById('v6-top-input').onkeydown = e => {
                if (e.key === 'Enter') {
                    const val = parseK(e.target.value);
                    if (val > 0) { activeTab.payments.push({ pid: Date.now(), amount: val, ...payNote('nhập tay'), isMatched: false }); saveAndRenderAll('v6-top-input'); }
                    e.target.value = "";
                }
            };

            document.getElementById('v6-paste').onclick = function() {
                const btn = this;
                const inputEl = document.getElementById('payingAmtInvoice') || document.querySelector('input[ng-model*="payingAmt"]');
                const valRaw  = inputEl ? parseFloat(inputEl.value.replace(/[^0-9]/g, '')) : 0;
                if (!inputEl || (valRaw % 1000 !== 0) || valRaw <= 0) { btn.classList.add('bakist-shake'); setTimeout(() => btn.classList.remove('bakist-shake'), 400); return; }
                activeTab.payments.push({ pid: Date.now(), amount: valRaw, ...payNote('tự dán'), isMatched: false });
                saveAndRenderAll();
            };

            document.getElementById('v6-summary').onclick = function() {
                const btn = this;
                const MINUS = '\u2212';
                const totalPaid = (activeTab.payments || []).reduce((a, b) => a + b.amount, 0);
                const listPaymentsStr = activeTab.payments && activeTab.payments.length > 0 ? activeTab.payments.map(n => formatK(n.amount)).join(' + ') : "0k";
                let debtParts = [];
                if ((activeTab.initialDebt || 0) !== 0) debtParts.push(formatK(activeTab.initialDebt));
                if ((activeTab.carryOver   || 0) !== 0) debtParts.push(MINUS + ' ' + formatK(Math.abs(activeTab.carryOver)));
                if ((activeTab.extraDebt1  || 0) !== 0) debtParts.push(formatK(activeTab.extraDebt1));
                if ((activeTab.extraDebt2  || 0) !== 0) debtParts.push(formatK(activeTab.extraDebt2));
                if ((activeTab.extraDebt3  || 0) !== 0) debtParts.push(formatK(activeTab.extraDebt3));
                if ((activeTab.extraDebt4  || 0) !== 0) debtParts.push(formatK(activeTab.extraDebt4));
                if ((activeTab.extraDebt5  || 0) !== 0) debtParts.push(formatK(activeTab.extraDebt5));
                if ((activeTab.extraDebt6  || 0) !== 0) debtParts.push(formatK(activeTab.extraDebt6));
                const debtMathStr = debtParts.length > 0 ? debtParts.reduce((acc, part, i) => { if (i === 0) return part; if (part.startsWith(MINUS)) return acc + ' ' + part; return acc + ' + ' + part; }, '') : "0k";
                const totalDebtValue = (activeTab.initialDebt||0) + (activeTab.carryOver||0) + (activeTab.extraDebt1||0) + (activeTab.extraDebt2||0) + (activeTab.extraDebt3||0) + (activeTab.extraDebt4||0) + (activeTab.extraDebt5||0) + (activeTab.extraDebt6||0);
                const diff    = totalPaid - totalDebtValue;
                const noteStr = (diff === 0) ? "hết nợ" : (diff > 0 ? "ong vàng ck dư" : `ong vàng còn nợ ${formatK(Math.abs(diff))}`);
                const diffStr = diff > 0 ? '+ ' + formatK(diff) : formatK(diff);
                const summaryText = `# tổng ${activeTab.payments.length} khoản đã chuyển = ${formatK(totalPaid)} = ${listPaymentsStr}\n# tổng nợ = ${debtMathStr}${debtParts.length > 1 ? ' = ' + formatK(totalDebtValue) : ''}\n# \u2211 đã chuyển ${MINUS} \u2211 nợ = ${diffStr} (${noteStr})`;
                navigator.clipboard.writeText(summaryText).then(() => {
                    btn.innerText = "✅ Đã copy xong!"; btn.classList.add('copied');
                    if (copySuccessTimer) clearTimeout(copySuccessTimer);
                    copySuccessTimer = setTimeout(() => { btn.innerText = "📋 Tổng Kết (văn bản)"; btn.classList.remove('copied'); }, 2000);
                });
            };

            document.getElementById('v6-img').onclick = function() {
                const btn = this;
                const MINUS = '\u2212';
                const payments = activeTab.payments || [];
                const totalPaid = payments.reduce((a, b) => a + b.amount, 0);
                let debtLines = [];
                if ((activeTab.initialDebt||0) !== 0) { const v = activeTab.initialDebt; debtLines.push({ text: (v > 0 ? '+ ' : '') + formatK(v), color: v < 0 ? '#cc2200' : '#1a1a1a' }); }
                if ((activeTab.carryOver||0) !== 0) { const cv = activeTab.carryOver; debtLines.push({ text: formatK(cv) + ' (tồn đọng trước)', color: '#cc2200' }); }
                ['extraDebt1','extraDebt2','extraDebt3','extraDebt4','extraDebt5','extraDebt6'].forEach(f => {
                    const v = activeTab[f] || 0;
                    if (v !== 0) debtLines.push({ text: (v > 0 ? '+ ' : '') + formatK(v), color: v < 0 ? '#cc2200' : '#1a1a1a' });
                });
                const totalDebt = (activeTab.initialDebt||0) + (activeTab.carryOver||0) + (activeTab.extraDebt1||0) + (activeTab.extraDebt2||0) + (activeTab.extraDebt3||0) + (activeTab.extraDebt4||0) + (activeTab.extraDebt5||0) + (activeTab.extraDebt6||0);
                const diff = totalPaid - totalDebt;
                const dpr  = window.devicePixelRatio || 2;
                const FONT = '"SF Mono", "Fira Code", Consolas, monospace';
                const FS = 30, LH = 54, PAD_T = 32, PAD_L = 24, BAR = 6, PAD_R = 80;
                const hasDebt = debtLines.length > 0;
                const nLines  = 1 + payments.length + (hasDebt ? 1 + 1 + debtLines.length : 0) + 1 + 1 + 1; // +1 trailing empty
                // ── measure required width on a scratch canvas ───────────────
                const mCtx = document.createElement('canvas').getContext('2d');
                mCtx.font = `${FS}px ${FONT}`;
                const chotLaiText = 'chốt lại,  ( tổng chuyển ' + formatK(totalPaid) + ' )  trừ  ( tổng nợ ' + formatK(totalDebt) + ' )  còn :';
                const resultTextPre = diff === 0 ? '0  (hết nợ)' : diff > 0 ? `+ ${formatK(diff)}  (ong vàng ck dư ${formatK(diff)})` : `${formatK(diff)}  (ong vàng còn nợ ${formatK(Math.abs(diff))})`;
                // measure pay lines + brace + total appended
                const payMaxW  = payments.reduce((mx, p) => Math.max(mx, mCtx.measureText('+ ' + formatK(p.amount)).width), 0);
                const debtMaxW = debtLines.reduce((mx, l) => Math.max(mx, mCtx.measureText(l.text || l).width), 0);
                const bracePayW  = BAR + PAD_L + payMaxW  + 24 + FS + mCtx.measureText(' ' + formatK(totalPaid)).width;
                const braceDebtW = BAR + PAD_L + debtMaxW + 24 + FS + mCtx.measureText(' ' + formatK(totalDebt)).width;
                const allTexts = [
                    'đã chuyển ' + payments.length + ' khoản như sau:',
                    chotLaiText,
                    resultTextPre,
                ];
                const plainMaxW = allTexts.reduce((mx, t) => Math.max(mx, BAR + PAD_L + mCtx.measureText(t).width), 0);
                const W = Math.ceil(Math.max(plainMaxW, bracePayW, braceDebtW) + PAD_R);
                // ─────────────────────────────────────────────────────────────
                const H = PAD_T + nLines * LH + PAD_T;
                const canvas = document.createElement('canvas');
                canvas.width  = W * dpr; canvas.height = H * dpr;
                const ctx = canvas.getContext('2d');
                ctx.scale(dpr, dpr);
                ctx.fillStyle = '#f0ede8'; ctx.fillRect(0, 0, W, H);
                ctx.fillStyle = '#007a44'; ctx.fillRect(0, 0, BAR, H);
                const textX = BAR + PAD_L;
                let y = PAD_T;
                const writeLine = (text, color) => { ctx.fillStyle = color; ctx.font = `${FS}px ${FONT}`; ctx.fillText(text, textX, y + FS); y += LH; };
                const drawBraceSection = (lines, getColor, totalVal, totalColor) => {
                    ctx.font = `${FS}px ${FONT}`;
                    const maxW   = lines.reduce((mx, l) => Math.max(mx, ctx.measureText(l.text || l).width), 0);
                    const bX     = textX + maxW + 24;
                    const midIdx = Math.floor((lines.length - 1) / 2);
                    lines.forEach((l, i) => {
                        const text  = l.text  !== undefined ? l.text  : l;
                        const color = l.color !== undefined ? l.color : '#111';
                        writeLine(text, color);
                        const lineY = y - LH;
                        ctx.font = `${FS}px ${FONT}`; ctx.fillStyle = '#aaa49e';
                        const bc = lines.length === 1 ? '}' : i === 0 ? '┐' : i === lines.length-1 ? '┘' : i === midIdx ? '┤' : '│';
                        ctx.fillText(bc, bX, lineY + FS);
                        if (i === midIdx || lines.length === 1) { ctx.fillStyle = totalColor; ctx.fillText(' ' + formatK(totalVal), bX + FS, lineY + FS); }
                    });
                    return bX;
                };
                writeLine(`đã chuyển ${payments.length} khoản như sau:`, '#444');
                const payLines = payments.map(p => ({ text: `+ ${formatK(p.amount)}`, color: p.isMatched ? '#999' : '#111' }));
                const bX1 = drawBraceSection(payLines, null, totalPaid, '#007a44');
                let bX2 = bX1;
                if (hasDebt) {
                    y += LH;
                    writeLine('tổng nợ:', '#444');
                    // debt total right side always red
                    const debtTotalColor = '#b31a00';
                    bX2 = drawBraceSection(debtLines, null, totalDebt, debtTotalColor);
                }
                const maxBX  = Math.max(bX1, bX2);
                const hrLen  = Math.floor((maxBX - textX + 60) / 16);
                writeLine('─'.repeat(hrLen), '#c8c2ba');
                // ── chốt lại line: mixed green / red segments ────────────────
                {
                    ctx.font = `${FS}px ${FONT}`;
                    const GREEN = '#007a44', RED = '#b31a00', GRAY = '#666';
                    const seg = [
                        { text: 'chốt lại,  ( tổng chuyển ', color: GRAY },
                        { text: formatK(totalPaid),            color: GREEN },
                        { text: ' )  trừ  ( tổng nợ ',         color: GRAY },
                        { text: formatK(totalDebt),            color: RED },
                        { text: ' )  còn :',                   color: GRAY },
                    ];
                    let cx = textX;
                    seg.forEach(s => {
                        ctx.fillStyle = s.color;
                        ctx.fillText(s.text, cx, y + FS);
                        cx += ctx.measureText(s.text).width;
                    });
                    y += LH;
                }
                // ── final result line ────────────────────────────────────────
                if (diff === 0) {
                    ctx.font = `bold ${FS}px ${FONT}`;
                    ctx.fillStyle = '#111';
                    ctx.fillText(resultTextPre, textX, y + FS);
                    y += LH;
                } else {
                    writeLine(resultTextPre, diff > 0 ? '#007a44' : '#b31a00');
                }
                y += LH; // trailing empty line
                canvas.toBlob(blob => {
                    navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]).then(() => {
                        btn.innerText = "✅ Đã copy xong!"; btn.classList.add('copied');
                        if (copySuccessTimer) clearTimeout(copySuccessTimer);
                        copySuccessTimer = setTimeout(() => { btn.innerText = "🖼 Tổng Kết (ảnh)"; btn.classList.remove('copied'); }, 2000);
                    }).catch(() => { btn.innerText = "❌ Lỗi clipboard"; setTimeout(() => { btn.innerText = "🖼 Tổng Kết (ảnh)"; }, 2000); });
                }, 'image/png');
            };

document.getElementById('v6-del').onclick = () => {
    const payments = activeTab.payments || [];
    const canDelete = payments.length === 0 || payments.every(p => p.isMatched);
    if (!canDelete) {
        const btn = document.getElementById('v6-del');
        btn.classList.add('bakist-shake');
        setTimeout(() => btn.classList.remove('bakist-shake'), 400);
        return;
    }
    if (delCountdown === 6 && !isConfirmReady) {
                    deleteTimer = setInterval(() => {
                        delCountdown--;
                        if (delCountdown > 0) renderMain();
else {
    clearInterval(deleteTimer);
    isConfirmReady = true;
    renderMain();
    deleteTimer = setTimeout(() => {
        resetDeleteState();
        renderMain();
    }, 5000);
}                    }, 1000);
                    renderMain();
                } else if (isConfirmReady) {
                    state.tabs = state.tabs.filter(x => x.id !== state.activeTabId);
                    state.activeTabId = state.tabs.length > 0 ? state.tabs[0].id : null;
                    if (state.selectedMiniTabId === activeTab.id) state.selectedMiniTabId = state.activeTabId;
                    resetDeleteState();
                    saveAndRenderAll();
                }
            };

            mainOverlay.querySelectorAll('.btn-match').forEach(b => b.onclick = e => {
                const target = activeTab.payments.find(p => p.pid == e.target.dataset.pid);
                if (!target) return;
                target.isMatched = !target.isMatched;
                saveAndRenderAll();
            });
            mainOverlay.querySelectorAll('.row-note').forEach(n => {
                // auto-resize width as user types
                const resize = (el) => { el.style.width = '52px'; el.style.width = Math.min(el.scrollWidth + 8, el.parentElement.clientWidth) + 'px'; };
                n.addEventListener('input', e => resize(e.target));
                resize(n);
                n.onchange = e => {
                    const target = activeTab.payments.find(p => p.pid == e.target.dataset.pid);
                    if (target) { target.userNote = e.target.value; saveAndRenderAll(); }
                };
            });
            mainOverlay.querySelectorAll('.del-p').forEach(d => {
                d.dataset.delStep = '0';
                d.onclick = e => {
                    const btn = e.currentTarget;
                    const step = parseInt(btn.dataset.delStep || '0');
                    if (step === 0) { btn.dataset.delStep = '1'; btn.classList.add('alt-corner'); }
                    else if (step === 1) { btn.dataset.delStep = '2'; btn.classList.remove('alt-corner'); }
                    else {
                        const pid = btn.dataset.pid;
                        const removed = activeTab.payments.find(p => p.pid == pid);
                        if (removed && removed.sysLabel && removed.sysLabel.startsWith('chuyển nợ từ ')) {
                            const shortName = removed.sysLabel.replace('chuyển nợ từ ', '').trim();
                            const srcTab = state.tabs.find(t => (t.name || '').split(' ')[0] === shortName && t.debtTransferredTo);
                            if (srcTab) delete srcTab.debtTransferredTo;
                        } else if (removed && removed.note && removed.note.startsWith('chuyển nợ từ ')) {
                            // legacy compat
                            const shortName = removed.note.replace('chuyển nợ từ ', '').trim();
                            const srcTab = state.tabs.find(t => (t.name || '').split(' ')[0] === shortName && t.debtTransferredTo);
                            if (srcTab) delete srcTab.debtTransferredTo;
                        }
                        activeTab.payments = activeTab.payments.filter(p => p.pid != pid);
                        saveAndRenderAll();
                    }
                };
            });

            let dragSrcPid = null;
            mainOverlay.querySelectorAll('.pay-card[data-pid]').forEach(card => {
                card.addEventListener('dragstart', e => {
                    dragSrcPid = card.dataset.pid;
                    e.dataTransfer.setData('text/plain', JSON.stringify({ type: 'reorder', pid: dragSrcPid }));
                    e.dataTransfer.effectAllowed = 'move';
                    setTimeout(() => card.classList.add('dragging-src'), 0);
                });
                card.addEventListener('dragend', () => {
                    card.classList.remove('dragging-src');
                    mainOverlay.querySelectorAll('.pay-card').forEach(c => c.classList.remove('drag-over'));
                    dragSrcPid = null;
                });
                card.addEventListener('dragover', e => {
                    e.preventDefault();
                    if (card.dataset.pid === dragSrcPid) return;
                    mainOverlay.querySelectorAll('.pay-card').forEach(c => c.classList.remove('drag-over'));
                    card.classList.add('drag-over');
                });
                card.addEventListener('dragleave', () => card.classList.remove('drag-over'));
                card.addEventListener('drop', e => {
                    e.preventDefault(); card.classList.remove('drag-over');
                    try {
                        const data = JSON.parse(e.dataTransfer.getData('text/plain'));
                        if (data.type !== 'reorder') return;
                        const fromPid = parseInt(data.pid);
                        const toPid   = parseInt(card.dataset.pid);
                        if (fromPid === toPid) return;
                        const payments = activeTab.payments;
                        const fromIdx = payments.findIndex(p => p.pid == fromPid);
                        const toIdx   = payments.findIndex(p => p.pid == toPid);
                        if (fromIdx === -1 || toIdx === -1) return;
                        const [moved] = payments.splice(fromIdx, 1);
                        payments.splice(toIdx, 0, moved);
                        saveAndRenderAll();
                    } catch(err) {}
                });
            });

            document.getElementById('v6-pin').onclick = () => {
                const cur = activeTab.isPinned;
                state.tabs.forEach(t => t.isPinned = false);
                activeTab.isPinned = !cur;
                saveAndRenderAll();
            };

            document.getElementById('v6-close').onclick = () => {
                saveAndRenderAll();
                if (ghEnabled()) ghExportBackup(() => {});
                state.isOpen = false;
                mainOverlay.style.display = 'none';
                setTimeout(() => {
                    const searchInput = document.getElementById('productSearchInput');
                    if (searchInput) searchInput.focus();
                }, 50);
            };
        }
    }

    function resetDeleteState() {
        if (deleteTimer) clearInterval(deleteTimer);
        delCountdown = 6; isConfirmReady = false;
    }

    // ── blur any focused left-panel input when browser tab loses visibility ──
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') {
            const active = document.activeElement;
            if (active && active.closest && active.closest('#bakist-debt-main .split-left')) {
                active.blur();
            }
        }
    });

    // ─── 7. AUTO-CAPTURE ────────────────────────────────────────────────────────
    function resetToPinnedTab() {
        const pinned = state.tabs.find(t => t.isPinned);
        const target = pinned ? pinned.id : (state.tabs[0] ? state.tabs[0].id : null);
        if (target && target !== state.selectedMiniTabId) {
            state.selectedMiniTabId = target;
            GM_setValue("hdebt_book_v1", { tabs: state.tabs, activeTabId: state.activeTabId, selectedMiniTabId: state.selectedMiniTabId });
            refreshButtonContent();
        }
    }

    let captureLockedUntil = 0;

    function capturePayment() {
        if (!state.selectedMiniTabId) return;
        if (Date.now() < captureLockedUntil) return;
        if (!isTrungGianSelected() && !isBeesNgaoNgoSelected()) return;
        const amtInput = document.getElementById('payingAmtInvoice')
                      || document.querySelector('input[ng-model*="payingAmt"]')
                      || document.querySelector('.payment-component input');
        if (!amtInput) return;
        const amount = parseFloat(amtInput.value.replace(/[^0-9]/g, '')) || 0;
        if (amount <= 0) return;
        captureLockedUntil = Date.now() + 4000;
        const tab = state.tabs.find(t => t.id === state.selectedMiniTabId);
        if (tab) {
            if (!tab.payments) tab.payments = [];
            tab.payments.push({ pid: Date.now(), amount, ...payNote('tự khớp hoá đơn'), isMatched: false });
            saveAndRenderAll();
            const activeBtn = btnGrid.querySelector(`[data-mid="${state.selectedMiniTabId}"]`);
            if (activeBtn) { activeBtn.classList.add('flash-capture'); setTimeout(() => activeBtn.classList.remove('flash-capture'), 600); }
            setTimeout(resetToPinnedTab, 800);
        }
    }

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && e.target.closest('#payingAmtInvoice, input[ng-model*="payingAmt"]')) capturePayment();
        if (e.key === 'F9') setTimeout(capturePayment, 50);
    });
    document.addEventListener('mousedown', function(e) {
        if (!e.isTrusted) return;
        if (e.target.closest('#saveTransaction, .btn-payment, button[ng-click*="saveTransaction"]')) capturePayment();
    }, true);

    // ─── 8. PHÍM TẮT MỞ/ĐÓNG ───────────────────────────────────────────────────
    let lastK = 0;
    window.addEventListener('keydown', e => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
            const now = Date.now();
if (now - lastK < 500) {
    state.isOpen = !state.isOpen;
    if (state.isOpen) {
        const pinned = state.tabs.find(t => t.isPinned);
        if (pinned) state.activeTabId = pinned.id;
    }
    if (!state.isOpen) {
        GM_setValue("hdebt_book_v1", { tabs: state.tabs, activeTabId: state.activeTabId, selectedMiniTabId: state.selectedMiniTabId });
        if (ghEnabled()) ghExportBackup(() => {});
        mainOverlay.style.display = 'none';
        setTimeout(() => {
            const searchInput = document.getElementById('productSearchInput');
            if (searchInput) searchInput.focus();
        }, 50);
    } else {
        renderMain();
    }
}
            lastK = now;
            e.preventDefault();
        }
    });

    // ── Ctrl+Home / Option+Q → QR launcher  |  ESC (capture) → close ────────
    document.addEventListener('keydown', e => {
        // ESC: capture phase so the page cannot swallow it before us
        if (e.key === 'Escape') {
            if (qrLauncher.classList.contains('open')) {
                closeQRLauncher();
                e.preventDefault();
                e.stopImmediatePropagation();
                return;
            }
            if (qrFloat.offsetWidth > 0 || qrFloat.offsetHeight > 0) {
                qrFloat.style.display = 'none';
                btnGrid.querySelectorAll('.bakist-btn[data-mid]').forEach(b => b.style.visibility = '');
                if (qrConnector.getContext) { qrConnector.getContext('2d').clearRect(0,0,qrConnector.width,qrConnector.height); } qrConnector.style.display = 'none';
                qrDot.style.display = 'none';
                e.preventDefault();
                e.stopImmediatePropagation();
                return;
            }
            if (importModal.classList.contains('open')) {
                importModal.classList.remove('open');
                e.preventDefault();
                e.stopImmediatePropagation();
                return;
            }
            if (state.isOpen) {
                saveAndRenderAll();
                if (ghEnabled()) ghExportBackup(() => {});
                state.isOpen = false;
                mainOverlay.style.display = 'none';
                GM_setValue("hdebt_book_v1", { tabs: state.tabs, activeTabId: state.activeTabId, selectedMiniTabId: state.selectedMiniTabId });
                setTimeout(() => { const s = document.getElementById('productSearchInput'); if (s) s.focus(); }, 50);
                e.preventDefault();
                e.stopImmediatePropagation();
                return;
            }
        }
        // End key — toggle floating buttons (capture so KiotViet never sees it)
        if (e.key === 'End' && !e.ctrlKey && !e.metaKey && !e.altKey && !e.shiftKey) {
            btnWrapForceHidden = !btnWrapForceHidden;
            if (btnWrapForceHidden) btnWrap.classList.remove('visible');
            e.preventDefault();
            e.stopImmediatePropagation();
            return;
        }
        // Ctrl+Home (Win/Linux) hoặc Option+Q (Mac) — toggles the QR launcher
        if ((e.key === 'Home' && (e.ctrlKey || e.metaKey) && !e.altKey)
            || (e.key === 'œ' && !e.ctrlKey && !e.metaKey && !e.shiftKey)) {
            if (qrLauncher.classList.contains('open')) {
                closeQRLauncher();
            } else {
                openQRLauncher();
            }
            e.preventDefault();
            e.stopImmediatePropagation();
        }
    }, true); // capture = true — fires before any bubble-phase page handler

    // ─── 9. KHỞI ĐỘNG ───────────────────────────────────────────────────────────
    saveAndRenderAll();

    // ── auto GitHub backup on load ───────────────────────────────────────────
    if (ghEnabled()) {
        const lastExport = GM_getValue(GH_LAST_EXPORT_KEY, 0);
        const hoursSince = (Date.now() - lastExport) / 3600000;
        if (GH_INTERVAL_HOURS > 0 && hoursSince >= GH_INTERVAL_HOURS) {
            setTimeout(() => ghExportBackup(() => {}), 8000); // delay 8s so page is ready
        }
        if (GH_INTERVAL_HOURS > 0) {
            setInterval(() => ghExportBackup(() => {}), GH_INTERVAL_HOURS * 3600000);
        }
    }
})();