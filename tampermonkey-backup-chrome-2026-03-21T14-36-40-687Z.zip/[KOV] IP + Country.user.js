// ==UserScript==
// @name         [KOV] IP + Country
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  Show IP | Country on KiotViet with VPN detection
// @match        https://cov.kiotviet.vn/sale/*
// @match        https://cov.kiotviet.vn/man/*
// @grant        GM_xmlhttpRequest
// @connect      cloudflare.com
// @connect      ipwho.is
// @run-at       document-idle
// ==/UserScript==

(function () {
'use strict';

if (window.__kvIPCountryNice) return;
window.__kvIPCountryNice = true;

function parseTrace(text){
    const obj = {};
    text.split("\n").forEach(l=>{
        const p=l.split("=");
        if(p.length===2) obj[p[0]]=p[1];
    });

    return {
        ip: obj.ip || null,
        loc: obj.loc || "--"
    };
}

function getCountry(ip,fallback,cb){

    GM_xmlhttpRequest({
        method:"GET",
        url:`https://ipwho.is/${ip}`,
        timeout:4000,

        onload:r=>{
            try{

                const d=JSON.parse(r.responseText);

                const country = d.success ? d.country : fallback;

                const vpn =
                    d.security &&
                    (d.security.vpn || d.security.proxy || d.security.tor);

                cb(country,vpn);

            }catch{
                cb(fallback,false);
            }
        },

        onerror:()=>cb(fallback,false)

    });
}

function createWidget(ip,country,isVPN){

    const wrap=document.createElement("div");

    wrap.style.display="flex";
    wrap.style.alignItems="center";
    wrap.style.fontWeight="600";
    wrap.style.whiteSpace="nowrap";
    wrap.style.gap="6px";

    const ipEl=document.createElement("span");
    ipEl.textContent=ip;
    ipEl.style.cursor="pointer";

    // COLOR
    ipEl.style.color = isVPN ? "#ff9800" : "#ffffff";

    ipEl.title=isVPN
        ? "VPN detected — click to copy IP"
        : "Click to copy IP";

    ipEl.onclick=()=>{
        navigator.clipboard.writeText(ip);
        ipEl.title="Copied!";
        setTimeout(()=>{
            ipEl.title="Click to copy IP";
        },1500);
    };

    const sep=document.createElement("span");
    sep.textContent="|";
    sep.style.opacity="0.6";

    const countryEl=document.createElement("span");
    countryEl.textContent=country;
    countryEl.style.cursor="pointer";
    countryEl.style.color="#9fd3ff";
    countryEl.title="Open IP details";

    countryEl.onclick=()=>{
        window.open(`https://ipwho.is/${ip}?pretty`);
    };

    wrap.appendChild(ipEl);
    wrap.appendChild(sep);
    wrap.appendChild(countryEl);

    return wrap;
}

function insert(ip,country,isVPN){

    const widget=createWidget(ip,country,isVPN);

    const pos=document.querySelector("menu-component.header-right ul.icon-list.header-nav");

    if(pos){
        const li=document.createElement("li");
        li.className="icon-item";
        li.appendChild(widget);
        pos.insertBefore(li,pos.firstChild);
        return;
    }

    const man=document.querySelector("section.container.kv-navbar-container");

    if(man){
        widget.style.marginRight="20px";
        man.insertBefore(widget,man.firstChild);
    }
}

function waitInsert(ip,country,isVPN){

    const t=setInterval(()=>{

        const pos=document.querySelector("menu-component.header-right ul.icon-list.header-nav");
        const man=document.querySelector("section.container.kv-navbar-container");

        if(pos || man){
            clearInterval(t);
            insert(ip,country,isVPN);
        }

    },300);
}

function fetchIP(retry=0){

    GM_xmlhttpRequest({
        method:"GET",
        url:"https://www.cloudflare.com/cdn-cgi/trace",

        onload:r=>{

            const data=parseTrace(r.responseText);

            if(!data.ip){

                if(retry<5){
                    setTimeout(()=>fetchIP(retry+1),1500);
                }else{
                    waitInsert("offline","--",false);
                }

                return;
            }

            getCountry(data.ip,data.loc,(country,isVPN)=>{
                waitInsert(data.ip,country,isVPN);
            });

        },

        onerror:()=>{

            if(retry<5){
                setTimeout(()=>fetchIP(retry+1),1500);
            }else{
                waitInsert("offline","--",false);
            }

        }
    });
}

fetchIP();

})();