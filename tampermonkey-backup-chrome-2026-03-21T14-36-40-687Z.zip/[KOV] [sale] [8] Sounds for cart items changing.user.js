// ==UserScript==
// @name         [KOV] [sale] [8] Sounds for cart items changing
// @namespace    http://tampermonkey.net/
// @version      9.8
// @description  Cashier chime per cart change + welcome chime + robust resume + survives tab switching + soft switch ding + 3-state speaker icon
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// ==/UserScript==

(function () {
  "use strict";
function getCurrentPriceBook() {
  const span = document.querySelector(
    "pricebook-component .k-dropdown-wrap .k-input span"
  );
  if (!span) return "";
  return span.textContent.trim().toLowerCase();
}
  // ---------- Shared audio context ----------
  let audioCtx = null;
  let playPending = false;
  let lastWelcomeAt = 0;
  const WELCOME_THROTTLE_MS = 1200;

  function ensureCtx() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();

      // Keep alive
      setInterval(() => {
        if (audioCtx.state === "suspended") audioCtx.resume().catch(() => {});
      }, 500);

      document.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "visible" && audioCtx.state === "suspended") {
          audioCtx.resume().catch(() => {});
        }
      });

      audioCtx.onstatechange = updateSpeakerIcon;
    }
    return audioCtx;
  }

  function tryResume() {
    const ctx = ensureCtx();
    if (ctx.state === "suspended") ctx.resume().catch(() => {});
  }

  function onFirstGesture() {
    document.removeEventListener("pointerdown", onFirstGesture);
    document.removeEventListener("keydown", onFirstGesture);
    document.removeEventListener("touchstart", onFirstGesture);
    tryResume();
  }
  document.addEventListener("pointerdown", onFirstGesture, { once: true });
  document.addEventListener("keydown", onFirstGesture, { once: true });
  document.addEventListener("touchstart", onFirstGesture, { once: true });

  // ---------- Sound generators ----------
  function _playItemChimeImmediate() {
    try {
      const ctx = ensureCtx();
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc2.type = "sine";
      osc.frequency.value = 820;
      osc2.frequency.value = 1640;
      osc2.detune.value = 8;
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.35, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.4);
      osc.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc2.start();
      osc.stop(now + 0.4);
      osc2.stop(now + 0.4);
    } catch {}
  }
function playCashChime() {
  try {
    const ctx = ensureCtx();
    if (ctx.state === "suspended") {
      playPending = true;
      tryResume();
      return;
    }

    const now = ctx.currentTime;

    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    osc1.type = "square";
    osc2.type = "triangle";

    osc1.frequency.value = 540;
    osc2.frequency.value = 1080;

    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.35, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start();
    osc2.start();

    osc1.stop(now + 0.35);
    osc2.stop(now + 0.35);

  } catch {}
}
  function playItemChime() {
    const ctx = ensureCtx();
    if (ctx.state === "suspended") {
      playPending = true;
      tryResume();
      return;
    }
    _playItemChimeImmediate();
  }

  function playFraction(frac) {
    try {
      const ctx = ensureCtx();
      if (ctx.state === "suspended") {
        playPending = true;
        tryResume();
        return;
      }
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      gain.gain.value = 0.8;
      osc.type = "sine";
      if (frac === 0.25) osc.frequency.value = 660;
      if (frac === 0.5) osc.frequency.value = 720;
      if (frac === 0.75) osc.frequency.value = 780;
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.18);
      osc.stop(ctx.currentTime + 0.18);
    } catch {}
  }

  function playWelcomeChime() {
    try {
      const nowTs = Date.now();
      if (nowTs - lastWelcomeAt < WELCOME_THROTTLE_MS) return;
      lastWelcomeAt = nowTs;

      const ctx = ensureCtx();
      if (ctx.state === "suspended") {
        playPending = true;
        tryResume();
        return;
      }

      const gain = ctx.createGain();
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      osc1.type = "triangle";
      osc2.type = "triangle";
      osc1.frequency.setValueAtTime(660, ctx.currentTime);
      osc2.frequency.setValueAtTime(880, ctx.currentTime + 0.13);
      gain.gain.setValueAtTime(0.42, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.75);
      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);
      osc1.start();
      osc2.start(ctx.currentTime + 0.13);
      osc1.stop(ctx.currentTime + 0.75);
      osc2.stop(ctx.currentTime + 0.75);
    } catch {}
  }

  function playSwitchDing() {
    try {
      const ctx = ensureCtx();
      if (ctx.state === "suspended") {
        playPending = true;
        tryResume();
        return;
      }
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = 1200;
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.28, now + 0.005);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(now + 0.12);
    } catch {}
  }

  // ---------- Speaker button ----------
  let iconEl = null;

  function updateSpeakerIcon() {
    if (!iconEl) return;
    const ctx = audioCtx;
    if (!ctx) {
      iconEl.className = "fal fa-volume-mute";
      iconEl.style.color = "red";
      return;
    }
    if (ctx.state === "running") {
      iconEl.className = "fal fa-volume-up";
      iconEl.style.color = "rgb(46, 204, 113)";
    } else if (ctx.state === "suspended") {
      iconEl.className = "fal fa-volume-slash";
      iconEl.style.color = "orange";
    } else {
      iconEl.className = "fal fa-volume-mute";
      iconEl.style.color = "red";
    }
  }

  function createSpeakerButton() {
    const target = document.querySelector("a.sale-mode");
    if (!target) return setTimeout(createSpeakerButton, 500);

    const speaker = document.createElement("a");
    speaker.className = "btn-icon-lg sale-mode enable";
    speaker.title = "Thử bật lại âm thanh (click để test)";
    speaker.style.cursor = "pointer";

    iconEl = document.createElement("i");
    iconEl.className = "fal fa-volume-mute";
    iconEl.style.color = "red";
    speaker.appendChild(iconEl);
    target.replaceWith(speaker);

    speaker.addEventListener("click", () => {
      tryResume();
      playItemChime();
      setTimeout(updateSpeakerIcon, 100);
    });

    document.addEventListener("click", updateSpeakerIcon, { once: true });
    document.addEventListener("keydown", updateSpeakerIcon, { once: true });
    updateSpeakerIcon();
  }
  createSpeakerButton();

  // ---------- Robust observer ----------
  function attachChimeToCart(el) {
    if (el._chimeObserverAttached) return;
    el._chimeObserverAttached = true;

    let lastValue = parseFloat(el.textContent.trim()) || 0;
    new MutationObserver(() => {
      const text = el.textContent.trim();
      const val = parseFloat(text);
      if (isNaN(val)) return;
      if (val === lastValue) return;



const pricebook = getCurrentPriceBook();

if (pricebook.includes("tien mat") || pricebook.includes("tiền mặt")) {
  playCashChime();
} else {
  playItemChime();
}
      const integer = Math.floor(val);
      const frac = +(val - integer).toFixed(2);
      if (frac) setTimeout(() => playFraction(frac), 150);
      lastValue = val;
    }).observe(el, { childList: true, subtree: true, characterData: true });
  }

  function observeAllTabs() {
    const stableParent =
      document.querySelector("div.wrapper.home-page") ||
      document.querySelector("body");
    if (!stableParent) return setTimeout(observeAllTabs, 1000);

    stableParent
      .querySelectorAll("span.fbpos-total-quantity, span.text-bg-default")
      .forEach(attachChimeToCart);

    new MutationObserver((mutations) => {
      for (const m of mutations) {
        for (const node of m.addedNodes) {
          if (!(node instanceof HTMLElement)) continue;
          if (
            node.matches &&
            (node.matches("span.fbpos-total-quantity") ||
              node.matches("span.text-bg-default"))
          ) {
            attachChimeToCart(node);
          }
          node
            .querySelectorAll?.("span.fbpos-total-quantity, span.text-bg-default")
            .forEach(attachChimeToCart);
        }
      }
    }).observe(stableParent, { childList: true, subtree: true });
  }
  observeAllTabs();

  // ---------- Play welcome when ready ----------
  (function playWelcomeWhenReady() {
    try {
      const ctx = ensureCtx();
      if (ctx.state === "running") {
        playWelcomeChime();
      } else {
        const handler = () => {
          if (audioCtx && audioCtx.state === "running") {
            playWelcomeChime();
            audioCtx.removeEventListener("statechange", handler);
          }
        };
        audioCtx.addEventListener("statechange", handler);
      }
    } catch {}
  })();

  // ---------- Tab switch ding ----------
  document.addEventListener(
    "click",
    (ev) => {
      const el = ev.target instanceof Element ? ev.target : null;
      if (!el) return;

      const changeBtn = el.closest?.(".btn-change-type");
      if (changeBtn) {
        playSwitchDing();
        setTimeout(() => playWelcomeChime(), 80);
        return;
      }
      const navLink = el.closest?.("a.nav-link, button.btn-change-type, li.nav-item");
      if (navLink) {
        playSwitchDing();
        setTimeout(() => playWelcomeChime(), 80);
      }
    },
    { capture: true }
  );

  (function watchActiveTabChange() {
    const stableParent =
      document.querySelector("div.wrapper.home-page") || document.querySelector("body");
    if (!stableParent) return setTimeout(watchActiveTabChange, 1000);

    let lastSnapshot = "";
    const takeSnapshot = () => {
      const nodes = Array.from(
        stableParent.querySelectorAll("kv-scroll-tab-pane, li.nav-item, a.nav-link")
      ).map((n) => (n.textContent || n.className || "").slice(0, 80));
      return nodes.join("|");
    };
    lastSnapshot = takeSnapshot();

    new MutationObserver(() => {
      const snap = takeSnapshot();
      if (snap !== lastSnapshot) {
        lastSnapshot = snap;
        playSwitchDing();
        setTimeout(() => playWelcomeChime(), 80);
      }
    }).observe(stableParent, { childList: true, subtree: true });
  })();
})();
