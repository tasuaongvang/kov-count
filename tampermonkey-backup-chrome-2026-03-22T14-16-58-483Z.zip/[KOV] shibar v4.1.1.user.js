// ==UserScript==
// @name         [KOV] shibar v4.1.1
// @namespace    http://tampermonkey.net/
// @version      4.1.1
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
'use strict';

function inject() {
    const right = document.querySelector('.cart-footer-right');
    if (!right || document.querySelector('#kv-shibar')) return;

    // Make cart-footer flex
    const footer = right.closest('.cart-footer');
    if (footer) {
        footer.style.cssText += ';display:flex!important;flex-direction:row-reverse!important;align-items:center!important;gap:6px!important;';
    }

    // Make both sides 33% / 67%
    const left = document.querySelector('.cart-footer-left');
    if (left) left.style.cssText += ';flex:0 0 33%!important;max-width:33%!important;min-width:0!important;';
    right.style.cssText += ';flex:0 0 67%!important;max-width:67%!important;min-width:0!important;';

    // Shibar div
    const sb = document.createElement('div');
    sb.id = 'kv-shibar';
    sb.textContent = '🐕 shibar test';
    sb.style.cssText = 'height:42px;background:#d6f5e3;border-radius:11px;padding:6px 8px;box-sizing:border-box;font-size:16px;line-height:30px;font-family:Inter,Arial,sans-serif;color:#333;overflow:hidden;white-space:nowrap;width:100%;';
    right.appendChild(sb);

    console.log('[shibar] injected OK', sb);
}

// Try immediately, then watch for DOM
inject();

// Remove KiotViet page footer
function nukeFooter() { document.querySelector('footer-component.page-footer')?.remove(); }
nukeFooter();
new MutationObserver(() => { inject(); nukeFooter(); }).observe(document.body, { childList: true, subtree: true });

// ── Giant watermark number — centered in cart, Font Awesome digits ──
const FA = {'0':'fa-0','1':'fa-1','2':'fa-2','3':'fa-3','4':'fa-4',
             '5':'fa-5','6':'fa-6','7':'fa-7','8':'fa-8','9':'fa-9','.':'fa-circle'};

function hookGiant() {
    const cart = document.querySelector('.cart-container');
    if (!cart) return;
    if (getComputedStyle(cart).position === 'static') cart.style.position = 'relative';

    if (!document.querySelector('#kv-giant-number')) {
        const giant = document.createElement('div');
        giant.id = 'kv-giant-number';
        giant.style.cssText = 'position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);' +
            'font-size:370px;font-weight:900;color:#000;opacity:0.09;pointer-events:none;' +
            "z-index:99998;font-family:'Inter','Segoe UI',Arial,sans-serif;" +
            'user-select:none;text-align:center;white-space:nowrap;line-height:1';
        cart.appendChild(giant);
    }

    const span = document.querySelector('span.text-bg-default');
    if (!span || span._kvGiant) return;
    span._kvGiant = true;
    renderGiant(span);
    new MutationObserver(() => renderGiant(span))
        .observe(span, { childList: true, characterData: true, subtree: true });
}

function renderGiant(span) {
    const giant = document.querySelector('#kv-giant-number'); if (!giant) return;
    const val = (span.textContent || '').replace(/[^\d.]/g, '') || '0';
    giant.innerHTML = '';
    for (const c of val) {
        if (!FA[c]) continue;
        const i = document.createElement('i');
        i.className = `fa-solid ${FA[c]}`; i.style.display = 'inline-block';
        if (c === '.') { i.style.cssText = 'font-size:.15em;vertical-align:bottom;position:relative;top:-.15em;margin:0 .15em'; }
        else i.style.margin = '0 .1em';
        giant.appendChild(i);
    }
}

hookGiant();
new MutationObserver(hookGiant).observe(document.body, { childList: true, subtree: true });

// ── Pricebook ↔ Payment two-way sync ─────────────────────────────
// Scheme A: "Bảng giá chung"  ↔  "Chuyển khoản"   (Ctrl+=)
// Scheme B: "Tiền mặt"        ↔  "Tiền mặt"        (Ctrl+-)

const norm  = s => (s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();
const SCHEMES = [
    { pb: 'bang gia chung', pay: 'chuyen khoan', snd: 'https://github.com/tasuaongvang/cov/raw/refs/heads/main/bank.mp3' },
    { pb: 'tien mat',       pay: 'tien mat',      snd: 'https://github.com/tasuaongvang/cov/raw/refs/heads/main/cash.mp3' },
];
const playUrl = url => { try { new Audio(url).play().catch(()=>{}); } catch(e){} };

// ── Payment button styles — shape of 2.png, color-coded selected states ──
document.head.insertAdjacentHTML('beforeend', `<style id="kv-pay-style">
  .form-group-row.form-check-methods {
    margin-top:14px!important;
  }
  .form-check-methods input[type="radio"],
  label.form-check input[type="radio"],
  label.form-check-inline input[type="radio"] {
    appearance:none!important;-webkit-appearance:none!important;
    width:0!important;height:0!important;
    margin:0!important;padding:0!important;
    position:absolute!important;opacity:0!important;pointer-events:none!important;
  }
  .form-group-row.form-check-methods span.text-check::before { display:none!important }
  .form-group-row.form-check-methods label.form-check,
  .form-group-row.form-check-methods label.form-check-inline {
    display:inline-flex!important;align-items:center!important;justify-content:center!important;
    padding:12px 22px!important;border-radius:8px!important;background:transparent!important;
    font-size:1.25rem!important;font-weight:700!important;cursor:pointer!important;
    white-space:nowrap!important;
    transform:scale(1.15)!important;transform-origin:center!important;
    margin:0 18px!important;
  }
  .form-group-row.form-check-methods span.text-check span {
    text-transform:lowercase!important;color:#222!important;font-weight:700!important;
  }
  /* tiền mặt selected → emerald — target the LABEL, not inner span */
  .form-group-row.form-check-methods label:has(input[value="0"]:checked) {
    background:#27ae60!important;box-shadow:0 0 8px rgba(39,174,96,.5)!important;
  }
  .form-group-row.form-check-methods label:has(input[value="0"]:checked) span { color:#fff!important }
  /* chuyển khoản selected → amber gold */
  .form-group-row.form-check-methods label:has(input[value="2"]:checked) {
    background:#d48806!important;box-shadow:0 0 8px rgba(212,136,6,.5)!important;
  }
  .form-group-row.form-check-methods label:has(input[value="2"]:checked) span { color:#fff!important }
  /* hỗn hợp active → indigo */
  #btn-kethop {
    display:inline-flex!important;align-items:center!important;justify-content:center!important;
    padding:12px 22px!important;border-radius:8px!important;background:transparent!important;
    font-size:1.25rem!important;font-weight:700!important;cursor:pointer!important;
    white-space:nowrap!important;border:none!important;color:#222!important;
    transform:scale(1.15)!important;transform-origin:center!important;
    margin:0 18px!important;outline:none!important;
  }
  #btn-kethop.active {
    background:#5b6abf!important;color:#fff!important;
    box-shadow:0 0 6px rgba(91,106,191,.5)!important;
  }
</style>`);

// ── Hide Thẻ / Ví by label text — :has() unreliable across KV versions ──
function hideTheVi() {
    document.querySelectorAll('.form-group-row.form-check-methods label.form-check, .form-group-row.form-check-methods label.form-check-inline').forEach(lbl => {
        const t = norm(lbl.textContent);
        if (t === 'the' || t === 'vi') Object.assign(lbl.style, { display:'none', visibility:'hidden', width:'0', height:'0', margin:'0', padding:'0', overflow:'hidden' });
    });
}
hideTheVi();
new MutationObserver(hideTheVi).observe(document.body, { childList: true, subtree: true });

// ── Kendo pricebook selector ──
function selectPB(targetNorm) {
    const sel = document.querySelector('pricebook-component select#pricebook, select#pricebook');
    if (!sel) return false;
    const kSpan = document.querySelector('pricebook-component .k-dropdown-wrap .k-input span');
    for (let i = 0; i < sel.options.length; i++) {
        if (!norm(sel.options[i].text).includes(targetNorm)) continue;
        try {
            const jq = window.kendo?.jQuery || window.jQuery || window.$;
            const kdd = jq?.(sel)?.data?.('kendoDropDownList');
            if (kdd) { kdd.select(i); kdd.trigger('change'); }
            else      { sel.selectedIndex = i; sel.dispatchEvent(new Event('change', { bubbles: true })); }
            if (kSpan) kSpan.innerText = sel.options[i].text;
            return true;
        } catch(e) {}
    }
    return false;
}

// ── Payment label clicker ──
function selectPay(targetNorm) {
    for (const lbl of document.querySelectorAll('label.form-check, label.form-check-inline')) {
        if (norm(lbl.innerText || '').includes(targetNorm)) { lbl.click(); return true; }
    }
    return false;
}

// ── Read current pricebook text ──
function currentPB() {
    const s = document.querySelector('pricebook-component .k-dropdown-wrap .k-input span');
    return norm(s?.textContent || '');
}

// ── Apply scheme (pb → pay) ──
// Cooldown-based guard: boolean flags can get permanently stuck if Kendo
// fires change events asynchronously after the flag is already cleared.
// A timestamp cooldown self-heals automatically after 600ms.
let _lastSync = 0;
const SYNC_COOL = 600;
function isSyncing() { return Date.now() - _lastSync < SYNC_COOL; }
function markSync()  { _lastSync = Date.now(); }

function applyScheme(schemeIdx) {
    markSync();
    const s = SCHEMES[schemeIdx];
    selectPB(s.pb);
    if (!selectPay(s.pay)) setTimeout(() => { selectPay(s.pay); playUrl(s.snd); }, 300);
    else playUrl(s.snd);
}

// ── Sync heartbeat — runs every 800ms, reads 2 DOM nodes, costs nothing ──
// Kendo dropdown does not reliably dispatch native 'change' on the hidden
// select when user clicks. Heartbeat self-heals any drift automatically.
setInterval(() => {
    if (isSyncing()) return;
    // Skip sync when mixed payment is active — don't override with single scheme
    if (document.querySelector('#btn-kethop')?.classList.contains('active')) return;
    const pb  = currentPB();
    const idx = SCHEMES.findIndex(s => pb.includes(s.pb));
    if (idx < 0) return;
    // Check if payment is already correct — read checked radio
    const checked = document.querySelector('.form-check-methods input[type="radio"]:checked');
    const payTxt  = norm(checked?.closest('label')?.innerText || '');
    if (payTxt.includes(SCHEMES[idx].pay)) return; // already in sync, skip
    markSync();
    selectPay(SCHEMES[idx].pay);
}, 800);

// ── Watch payment radio clicks ──
document.addEventListener('click', e => {
    const lbl = e.target.closest('label.form-check, label.form-check-inline');
    if (!lbl || isSyncing()) return;
    const txt = norm(lbl.innerText || '');
    const idx = SCHEMES.findIndex(s => txt.includes(s.pay));
    if (idx < 0) return;
    markSync();
    selectPB(SCHEMES[idx].pb);
}, true);

// ── Hotkeys: Ctrl+= → bank scheme, Ctrl+- → cash scheme ──
function focusSearch() {
    const s = document.querySelector('#productSearchInput'); if (!s) return;
    setTimeout(() => { s.focus(); s.select(); }, 80);
}
window.addEventListener('keydown', e => {
    if (!e.ctrlKey) return;
    if (e.key === '=' || e.key === '+') { e.preventDefault(); applyScheme(0); focusSearch(); }
    if (e.key === '-')                  { e.preventDefault(); applyScheme(1); focusSearch(); }
}, true);

// ── Move ··· (multi-payment) button into top icon bar ────────────
function moveEllipsis() {
    const btn = document.querySelector('button.btn-multi-methods');
    if (!btn || btn.__kvMoved) return;
    const li = document.querySelector('#printConfig')?.closest('li.icon-item');
    if (!li) return;
    btn.__kvMoved = true;
    const wrap = btn.closest('div') || btn;
    const newLi = document.createElement('li');
    newLi.className = 'icon-item';
    newLi.appendChild(wrap);
    li.after(newLi);
}
moveEllipsis();
new MutationObserver(moveEllipsis).observe(document.body, { childList: true, subtree: true });

// ── Nút "hỗn hợp" — triggers .btn-multi-methods, pauses sync while modal open ──
let _khPaused = false; // unused — heartbeat self-guards, kept for reference only

function insertKH() {
    const parent = document.querySelector('.form-group-row.form-check-methods');
    if (!parent || document.querySelector('#btn-kethop')) return;
    const lbls    = [...parent.querySelectorAll('label.form-check, label.form-check-inline')];
    const cashLbl = lbls.find(l => norm(l.textContent).includes('tien mat'));
    const bankLbl = lbls.find(l => norm(l.textContent).includes('chuyen khoan'));
    if (!cashLbl || !bankLbl) return;

    const kh = document.createElement('button');
    kh.id        = 'btn-kethop';
    kh.type      = 'button';
    kh.textContent = 'hỗn hợp';
    bankLbl.after(kh);

    kh.addEventListener('click', e => {
        e.preventDefault(); e.stopPropagation();
        kh.classList.add('active');
        document.querySelectorAll('.form-check-methods input[type="radio"]')
            .forEach(r => r.checked = false);
        document.querySelector('.btn-multi-methods')?.click();
        kh.blur();

        // Wait for modal to open, then clear all pre-filled payment rows + zero amount input
        const waitModal = new MutationObserver(() => {
            const modal = document.querySelector('.k-widget.k-window.payment-invoice');
            if (!modal) return;
            waitModal.disconnect();
            setTimeout(() => {
                // Clear pre-filled rows
                modal.querySelectorAll('button.btn-delete, button[ng-click*="delete"], button[ng-click*="remove"], i.fa-trash, i.fa-times')
                    .forEach(btn => { (btn.closest('button') || btn).click(); });

                // Zero out and focus the amount input
                setTimeout(() => {
                    const inp = modal.querySelector('#txtCurrentAmount');
                    if (!inp) return;
                    const nativeSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
                    nativeSetter.call(inp, '0');
                    inp.dispatchEvent(new Event('input',  { bubbles: true }));
                    inp.dispatchEvent(new Event('change', { bubbles: true }));
                    inp.focus(); inp.select();
                }, 80);
            }, 150);
        });
        waitModal.observe(document.body, { childList: true, subtree: true });
    });

// ── Live watcher: kh active = modal open OR mixed confirmed ──────
function checkMixedState() {
    const kh = document.querySelector('#btn-kethop'); if (!kh) return;
    const modalOpen = !!document.querySelector('.k-widget.k-window.payment-invoice');
    const mixedActive = [...document.querySelectorAll('span[ng-if]')]
        .some(s => s.offsetParent !== null
               && s.textContent.includes('Tiền mặt')
               && s.textContent.includes('Chuyển khoản'));
    if (modalOpen || mixedActive) kh.classList.add('active');
    else kh.classList.remove('active');
}
new MutationObserver(checkMixedState).observe(document.body, { childList: true, subtree: true });
}
insertKH();
new MutationObserver(insertKH).observe(document.body, { childList: true, subtree: true });

// ── Audio engine — synth only, zero network ───────────────────────
let _actx = null;
function actx() {
    if (!_actx) _actx = new (window.AudioContext || window.webkitAudioContext)();
    if (_actx.state === 'suspended') _actx.resume();
    return _actx;
}
// Unlock on first interaction
document.addEventListener('pointerdown', () => actx(), { once: true, passive: true });

function tone(type, freq, gain, dur, delay = 0) {
    try {
        const c = actx(), t = c.currentTime + delay;
        const o = c.createOscillator(), g = c.createGain();
        o.type = type; o.frequency.value = freq;
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(gain, t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        o.connect(g); g.connect(c.destination);
        o.start(t); o.stop(t + dur);
    } catch(e) {}
}

function chimeBank() { tone('sine',   820, 0.35, 0.4);  tone('sine',     1640, 0.2,  0.4);  }
function chimeCash() { tone('square', 540, 0.35, 0.35); tone('triangle', 1080, 0.2, 0.35); }

// Chime matches the ACTIVE scheme (pricebook), not last-clicked button
function playChime(rising) {
    const pb = norm(document.querySelector(
        'pricebook-component .k-dropdown-wrap .k-input span')?.textContent || '');
    // rising = item added, falling = item removed — same chime type, slight pitch shift
    if (pb.includes('tien mat')) chimeCash(); else chimeBank();
}

// ── Watch cart qty span — one targeted observer ───────────────────
function hookChime() {
    const span = document.querySelector('span.text-bg-default');
    if (!span || span._kvChime) return;
    span._kvChime = true;
    let last = parseFloat(span.textContent) || 0;
    new MutationObserver(() => {
        const v = parseFloat(span.textContent) || 0;
        if (v !== last) { last = v; playChime(v > last); }
    }).observe(span, { childList: true, characterData: true, subtree: true });
}
hookChime();
new MutationObserver(hookChime).observe(document.body, { childList: true, subtree: true });

// ── Ctrl+. → delete first item | double Ctrl+. → delete all ──────
let _lastDot = 0;
document.addEventListener('keydown', e => {
    if (!e.ctrlKey || e.key !== '.') return;
    e.preventDefault();
    const now = Date.now();
    if (now - _lastDot < 400) {
        // double tap → delete all
        document.querySelectorAll('.carts-item .cell-actions button[title="Xóa hàng hóa"]')
                .forEach(b => b.click());
    } else {
        // single tap — wait to see if double follows
        setTimeout(() => {
            if (Date.now() - _lastDot >= 400)
                document.querySelector('.carts-item .cell-actions button[title="Xóa hàng hóa"]')?.click();
        }, 420);
    }
    _lastDot = now;
}, true);

// ── Ctrl+ArrowUp/Down — nudge qty of first cart item ─────────────
function nudgeQty(step) {
    const inp = document.querySelector('#note-cartitem-0'); if (!inp) return;
    const kn = (typeof $ !== 'undefined') ? $(inp).data('kendoNumericTextBox') : null;
    const nv = Math.max(0, (parseFloat(inp.value) || 0) + step);
    if (kn) { kn.value(nv); kn.trigger('change'); }
    else    { inp.value = nv; inp.dispatchEvent(new Event('change', { bubbles: true })); }
    focusSearch();
}
document.addEventListener('keydown', e => {
    if (!e.ctrlKey) return;
    if (e.key === 'ArrowUp')   { e.preventDefault(); nudgeQty(1);  }
    if (e.key === 'ArrowDown') { e.preventDefault(); nudgeQty(-1); }
}, true);

// ── F9 / click save → swoosh ──────────────────────────────────────
const _swoosh = new Audio('https://github.com/tasuaongvang/cov/raw/refs/heads/main/swoosh.mp3');
_swoosh.load();
const SUCCESS = ['hoàn tất đơn','lưu thành công','thành công','tạo đơn thành công','hóa đơn được cập nhật thành công'];
let _lastSwoosh = 0, _pendingReset = false;
function trySwoosh() {
    const n = Date.now(); if (n - _lastSwoosh < 3000) return;
    _lastSwoosh = n;
    try { _swoosh.cloneNode().play().catch(()=>{}); } catch(e) {}
    // Flag to reset scheme when cart empties (safe moment = new blank cart)
    _pendingReset = true;
}
new MutationObserver(muts => {
    for (const m of muts) for (const node of m.addedNodes) {
        if (!(node instanceof HTMLElement)) continue;
        const txt = node.textContent || '';
        if (SUCCESS.some(k => txt.toLowerCase().includes(k))) trySwoosh();
    }
}).observe(document.body, { childList: true, subtree: true });

// Watch cart qty: when it hits 0 after a save → reset to scheme CK
function hookResetOnEmpty() {
    const span = document.querySelector('span.text-bg-default');
    if (!span || span._kvReset) return;
    span._kvReset = true;
    new MutationObserver(() => {
        const v = parseFloat(span.textContent) || 0;
        if (v === 0 && _pendingReset) {
            _pendingReset = false;
            setTimeout(() => {
                applyScheme(0); // scheme CK = index 0
                // Play bank.mp3 at half volume
                try {
                    const a = new Audio(SCHEMES[0].snd);
                    a.volume = 0.5; a.play().catch(()=>{});
                } catch(e) {}
            }, 400); // small delay so Angular finishes cart reset
        }
    }).observe(span, { childList: true, characterData: true, subtree: true });
}
hookResetOnEmpty();
new MutationObserver(hookResetOnEmpty).observe(document.body, { childList: true, subtree: true });

// ── F1: let KiotViet handle natively. Detect new tab OR post-save empty cart
//    → play bank.mp3 + ensure CK scheme ──────────────────────────────────────
let _tabCount = 0;
function countTabs() {
    return document.querySelectorAll('#cartListTab li.nav-item, .cart-tabs li.nav-item, ul.nav-tabs li.nav-item').length;
}
function initTabCount() { _tabCount = countTabs(); }
initTabCount();

// Page just loaded — suppress auto-trigger until user actually does something
let _pageReady = false;
document.addEventListener('pointerdown', () => { _pageReady = true; }, { once: true, passive: true });
document.addEventListener('keydown',     () => { _pageReady = true; }, { once: true, passive: true });

// Central handler — cooldown 2s prevents double-fire when both
// "new tab" and "cart qty→0" trigger at the same time after bill complete
let _lastEmptyCart = 0;
function onEmptyCart() {
    if (!_pageReady) return;
    const now = Date.now();
    if (now - _lastEmptyCart < 2000) return; // dedupe
    _lastEmptyCart = now;
    setTimeout(() => {
        applyScheme(0);
        try { const a = new Audio(SCHEMES[0].snd); a.volume = 0.5; a.play().catch(()=>{}); } catch(e) {}
    }, 350);
}

// Watch for new tab appearing
new MutationObserver(() => {
    const n = countTabs();
    if (n > _tabCount) {
        _tabCount = n;
        onEmptyCart(); // new tab = fresh empty cart
    } else {
        _tabCount = n;
    }
}).observe(document.body, { childList: true, subtree: true });

// Watch cart qty → 0 after successful save
function hookResetOnEmpty() {
    const span = document.querySelector('span.text-bg-default');
    if (!span || span._kvReset) return;
    span._kvReset = true;
    new MutationObserver(() => {
        const v = parseFloat(span.textContent) || 0;
        if (v === 0 && _pendingReset) {
            _pendingReset = false;
            onEmptyCart();
        }
    }).observe(span, { childList: true, characterData: true, subtree: true });
}
hookResetOnEmpty();
new MutationObserver(hookResetOnEmpty).observe(document.body, { childList: true, subtree: true });

// ── Ctrl+` → print bill ───────────────────────────────────────────
let _lastPrint = 0;
document.addEventListener('keydown', e => {
    if (!e.ctrlKey || e.key !== '`') return;
    e.preventDefault();
    const now = Date.now(); if (now - _lastPrint < 3000) return;
    _lastPrint = now;
    document.querySelector('#printTransaction,#printOrder')?.click();
}, true);

// ── Double Ctrl → announce cart total (audio files) ──────────────
const KOV_BASE = 'https://raw.githubusercontent.com/tasuaongvang/kov/main';
const _abuf = new Map();
const _actx2 = new (window.AudioContext || window.webkitAudioContext)();
document.addEventListener('keydown', () => { if(_actx2.state==='suspended')_actx2.resume(); }, {once:true});

async function loadBuf(name) {
    if (_abuf.has(name)) return _abuf.get(name);
    try {
        const buf = await _actx2.decodeAudioData(
            await (await fetch(`${KOV_BASE}/${name}?raw=1`)).arrayBuffer());
        _abuf.set(name, buf); return buf;
    } catch(e) { return null; }
}
async function playBuf(name) {
    const b = await loadBuf(name); if (!b) return;
    return new Promise(res => {
        const s = _actx2.createBufferSource(); s.buffer = b;
        s.connect(_actx2.destination); s.start(); s.onended = res;
    });
}
async function announceQty() {
    const el = document.querySelector('span.text-bg-default');
    const t = parseFloat((el?.textContent||'').replace(',','.'));
    if (!el || isNaN(t) || t === 0) { await playBuf('zero.mp3'); return; }
    const i = Math.floor(t), f = +(t-i).toFixed(2);
    const FMAP  = {0.25:'point25.mp3', 0.5:'point5.mp3', 0.75:'point75.mp3'};
    const SFMAP = {0.25:'0.25.mp3',    0.5:'0.5.mp3',    0.75:'0.75.mp3'};
    await playBuf('total.mp3');
    if (i > 0) await playBuf(`${i}.mp3`);
    if (i >= 1 && FMAP[f])  await playBuf(FMAP[f]);
    if (i === 0 && SFMAP[f]) await playBuf(SFMAP[f]);
}
let _ctrlCount = 0, _ctrlLast = 0;
window.addEventListener('keyup', e => {
    if (e.key !== 'Control') return;
    const now = Date.now();
    if (now - _ctrlLast <= 350) { _ctrlCount++; if (_ctrlCount >= 2) { _ctrlCount = 0; announceQty(); } }
    else _ctrlCount = 1;
    _ctrlLast = now;
}, true);

// ── Kendo helpers (unit dropdown + qty input) ─────────────────────
const BIG_UNITS = ['thùng','dây','box'];
const SM_UNITS  = ['bịch','lốc','túi','thanh','cái','lon','que','gói','hũ'];

function getKDD(sel) { return (typeof $!=='undefined') ? $(sel)?.data?.('kendoDropDownList')||null : null; }
function getKNB(sel) { return (typeof $!=='undefined') ? $(sel)?.data?.('kendoNumericTextBox')||null : null; }

function unitDD()  { return document.querySelector('#unit'); }
function qtyInp()  { return document.querySelector('#note-cartitem-0'); }

function setUnit(targetNames) {
    const dd = getKDD(unitDD()); if (!dd) return false;
    const data = dd.dataSource.data();
    for (const name of targetNames) {
        const found = data.find(o => o.Unit?.toLowerCase() === name);
        if (found) { dd.value(found.Id); dd.trigger('change'); return found.Unit; }
    }
    return false;
}

function setQty(val) {
    const inp = qtyInp(); if (!inp || inp.disabled) return;
    const kn = getKNB(inp);
    if (kn) { kn.value(val); kn.trigger('change'); }
    else    { inp.value = val; inp.dispatchEvent(new Event('change', { bubbles: true })); }
}

// Ctrl+/ → switch to big unit then set qty = 0.5
document.addEventListener('keydown', e => {
    if (!e.ctrlKey || e.key !== '/') return;
    e.preventDefault();
    const dd = getKDD(unitDD()); if (!dd) return;
    const cur = dd.text().trim().toLowerCase();
    if (!BIG_UNITS.includes(cur)) {
        const got = setUnit(BIG_UNITS);
        if (!got) return;  // no big unit available
    }
    setQty(0.5);
    focusSearch();
}, true);

// Ctrl+* → toggle between big ↔ small unit
document.addEventListener('keydown', e => {
    if (!e.ctrlKey || (e.key !== '*' && e.code !== 'NumpadMultiply')) return;
    e.preventDefault();
    const dd = getKDD(unitDD()); if (!dd) return;
    const cur = dd.text().trim().toLowerCase();
    if (BIG_UNITS.includes(cur)) setUnit(SM_UNITS);
    else                          setUnit(BIG_UNITS);
    focusSearch();
}, true);

// ── Double PageUp → làm tròn tiền (surcharge) ────────────────────
// ── Double PageDown → cắt lẻ (discount) ─────────────────────────
const sleep = ms => new Promise(r => setTimeout(r, ms));

function ping() { tone('sine', 800, 0.15, 0.12); }

function getCartTotal() {
    const el = document.querySelector('.payment-content .form-group-price .col-form-wrap.text-right');
    return el ? parseInt(el.innerText.replace(/[^0-9]/g,''), 10) || 0 : 0;
}
function findDiscBtn() {
    for (const lbl of document.querySelectorAll('label.col-form-label'))
        if (lbl.textContent.trim() === 'Giảm giá')
            return lbl.closest('.form-group-inline')?.querySelector('button.form-discount') || null;
    return null;
}

async function roundUp() {
    const surBtn = document.querySelector('#btnSurcharge'); if (!surBtn) return;
    surBtn.click();
    surBtn.dispatchEvent(new KeyboardEvent('keydown', { key:'Enter', keyCode:13, bubbles:true }));
    await sleep(380);
    const win = document.querySelector('.surcharge-window'); if (!win) return;
    const row = [...win.querySelectorAll('tbody tr')].find(r => r.innerText.includes('làm tròn tiền'));
    if (!row) return;
    const cb = row.querySelector('input[type="checkbox"]');
    if (cb && !cb.checked) cb.click();
    const btn = row.querySelector('button[id^="surchargeItem_"]'); if (!btn) return;
    btn.click();
    await sleep(150);
    const inp = document.querySelector('.popover-surcharge input.form-control'); if (!inp) return;
    const diff = (() => { const r = getCartTotal() % 1000; return r === 0 ? 0 : 1000 - r; })();
    if (diff <= 0) { win.querySelector('.k-window-action')?.click(); ping(); return; }
    inp.focus(); inp.value = String(diff);
    inp.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(120);
    inp.dispatchEvent(new KeyboardEvent('keydown', { key:'Enter', keyCode:13, bubbles:true }));
    await sleep(130);
    win.querySelector('.k-window-action')?.click();
    await sleep(150);
    focusSearch(); ping();
}

async function trimDiscount() {
    const el = document.querySelector('.form-group-price .col-form-wrap.text-right'); if (!el) return;
    const parts = el.textContent.replace(/[^\d,]/g,'').split(',');
    if (parts.length < 2) return;
    const remove = parseInt(parts[parts.length-1], 10);
    if (!remove || remove >= 1000) return;
    const btn = findDiscBtn(); if (!btn) return;
    btn.click();
    await sleep(240);
    const inp = document.querySelector('#priceInput'); if (!inp) return;
    inp.focus(); inp.value = String(remove);
    inp.dispatchEvent(new Event('input',  { bubbles: true }));
    inp.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(120);
    inp.dispatchEvent(new KeyboardEvent('keydown', { key:'Enter', keyCode:13, bubbles:true }));
    await sleep(120);
    document.body.click();
    document.querySelector('.popover-discount')?.style.setProperty('display','none');
    await sleep(120);
    focusSearch(); ping();
}

// waitFor — observer-based, zero polling
function waitForEl(sel, ms = 3000) {
    const el = document.querySelector(sel);
    if (el) return Promise.resolve(el);
    return new Promise((res, rej) => {
        const t = setTimeout(() => { obs.disconnect(); rej(); }, ms);
        const obs = new MutationObserver(() => {
            const e = document.querySelector(sel);
            if (e) { clearTimeout(t); obs.disconnect(); res(e); }
        });
        obs.observe(document.body, { childList: true, subtree: true });
    });
}

async function clearAll() {
    console.log('[clearAll] start');
    const discBtn = findDiscBtn();
    console.log('[clearAll] discBtn:', discBtn);
    if (!discBtn) return;
    discBtn.click();
    const inp = await waitForEl('#priceInput', 3000).catch(() => null);
    console.log('[clearAll] #priceInput:', inp);
    if (!inp) return;
    inp.focus(); inp.value = '0';
    inp.dispatchEvent(new Event('input',  { bubbles: true }));
    inp.dispatchEvent(new Event('change', { bubbles: true }));
    inp.dispatchEvent(new KeyboardEvent('keydown', { key:'Enter', keyCode:13, bubbles:true }));
    await sleep(150);
    document.body.click();
    document.querySelector('.popover-discount')?.style.setProperty('display','none');
    await sleep(200);
    const surBtn = document.querySelector('#btnSurcharge');
    console.log('[clearAll] surBtn:', surBtn, 'offsetParent:', surBtn?.offsetParent);
    if (!surBtn?.offsetParent) { focusSearch(); ping(); return; }
    surBtn.click();
    surBtn.dispatchEvent(new KeyboardEvent('keydown', { key:'Enter', keyCode:13, bubbles:true }));
    await sleep(350);
    const win = document.querySelector('.surcharge-window');
    console.log('[clearAll] surcharge-window:', win);
    if (!win) { focusSearch(); ping(); return; }
    const rows = [...win.querySelectorAll('tbody tr')];
    console.log('[clearAll] rows:', rows.map(r => r.innerText.trim()));
    const row = rows.find(r => r.innerText.includes('làm tròn tiền'));
    const cb  = row?.querySelector('input[type="checkbox"]');
    console.log('[clearAll] cb:', cb, 'checked:', cb?.checked);
    if (cb?.checked) cb.click();
    await sleep(100);
    win.querySelector('.k-window-action')?.click();
    focusSearch(); ping();
}

// PageUp×2 → roundUp | PageDown×2 → trimDiscount | PageDown+PageUp (either order, <400ms) → clearAll
let _tPU = 0, _tPD = 0;
document.addEventListener('keydown', e => {
    const now = Date.now();
    if (e.key === 'PageUp') {
        if (now - _tPD < 400) { e.preventDefault(); clearAll().catch(()=>{}); }       // PgDn then PgUp
        else if (now - _tPU < 350) { roundUp().catch(()=>{}); }                        // PgUp×2
        _tPU = now;
    }
    if (e.key === 'PageDown') {
        if (now - _tPU < 400) { e.preventDefault(); clearAll().catch(()=>{}); }       // PgUp then PgDn
        else if (now - _tPD < 350) { trimDiscount().catch(()=>{}); }                   // PgDn×2
        _tPD = now;
    }
});

// ── Auto-tomorrow for order date input ───────────────────────────
function handleOrderDate(inp) {
    inp.style.border    = '2px solid red';
    inp.style.boxShadow = '0 0 5px red';
    if (inp.dataset.tmrSet === '1') return;
    const k = (typeof $ !== 'undefined') ? $(inp).data('kendoDatePicker') : null;
    if (!k) return;
    const d = new Date(); d.setDate(d.getDate() + 1);
    k.value(d); k.trigger('change');
    inp.dataset.tmrSet = '1';
}
function checkOrderDate() {
    const el = document.querySelector('#rebindMaxDateOrder');
    if (el) handleOrderDate(el);
}
checkOrderDate();
new MutationObserver(checkOrderDate).observe(document.body, { childList: true, subtree: true });

// ── Tiền thối cần chuẩn bị (đặt hàng + tiền mặt) ────────────────
// Overlays the suggest-money / bank-account area inline — hides useless
// suggestion buttons, shows change-to-prepare text instead, 3x bigger.
document.head.insertAdjacentHTML('beforeend', `<style id="kv-dltop-style">
    #kv-dltop-wrap { position:relative; }
    #kv-dltop-wrap > *:not(#kv-dltop) { visibility:hidden !important; pointer-events:none !important; }
    #kv-dltop {
        position:absolute; inset:0;
        display:flex; align-items:center; justify-content:center;
        font-size:26px; font-weight:700; color:#d4380d;
        font-family:'Inter','Segoe UI',Arial,sans-serif;
        background:rgba(255,255,255,0.92);
        border-radius:8px; pointer-events:none; z-index:10;
        padding:12px 16px; text-align:center; line-height:1.4;
    }
</style>`);

const dlTop = document.createElement('div');
dlTop.id = 'kv-dltop';

function updateDlTop() {
    const isOrder = !!document.querySelector('#saveOrder');
    const isCash  = !!document.querySelector('.form-check-methods input[type="radio"][value="0"]:checked');

    // Find the container (suggest-money parent .form-group)
    const container = document.querySelector('.suggest-money')?.closest('.form-group')
                   || document.querySelector('#bankAccounts')?.closest('.form-group');

    // Detach if conditions not met
    if (!isOrder || !isCash || !container) {
        restoreDlTop();
        return;
    }

    // Attach inside container
    if (dlTop.parentNode !== container) {
        container.id = 'kv-dltop-wrap';
        container.style.position = 'relative';
        container.appendChild(dlTop);
    }

    const amt = parseInt(document.querySelector('.amount-pay')?.textContent.replace(/[^\d]/g,'') || '0', 10);
    const change = Math.ceil(amt / 500000) * 500000 - amt;
    dlTop.textContent = `chuẩn bị tiền thối = ${change.toLocaleString()}đ`;

    // Hide the "Tiền thừa trả khách" + delivery date section — useless noise
    const refun = document.querySelector('.payment-refun');
    if (refun) refun.style.setProperty('display', 'none', 'important');
}

function restoreDlTop() {
    dlTop.parentNode?.removeAttribute('id');
    dlTop.remove();
    const refun = document.querySelector('.payment-refun');
    if (refun) refun.style.removeProperty('display');
}
setInterval(updateDlTop, 600);

// ── Speaker icon — replaces a.sale-mode, shows AudioContext health ──
function hookSpeakerBtn() {
    const target = document.querySelector('a.sale-mode');
    if (!target || target.querySelector('#kv-speaker-icon')) return;

    const icon = document.createElement('i');
    icon.id = 'kv-speaker-icon';
    target.innerHTML = '';
    target.appendChild(icon);
    target.title = 'Click để test âm thanh';
    target.style.cursor = 'pointer';

    function updateIcon() {
        if (!_actx)                          { icon.className = 'fal fa-volume-mute';  icon.style.color = 'red'; }
        else if (_actx.state === 'running')  { icon.className = 'fal fa-volume-up';   icon.style.color = 'rgb(46,204,113)'; }
        else if (_actx.state === 'suspended'){ icon.className = 'fal fa-volume-slash'; icon.style.color = 'orange'; }
        else                                 { icon.className = 'fal fa-volume-mute';  icon.style.color = 'red'; }
    }
    // Block the original ng-click from firing — capture phase, before Angular
    target.addEventListener('click', e => { e.preventDefault(); e.stopImmediatePropagation(); actx(); chimeBank(); setTimeout(updateIcon, 100); }, true);
    setInterval(updateIcon, 1000);
    updateIcon();
}
hookSpeakerBtn();
new MutationObserver(hookSpeakerBtn).observe(document.body, { childList: true, subtree: true });
// ── F11 → blocked (prevent browser fullscreen) ───────────────────
// ── F12 → focus KV note textarea, select all ─────────────────────
const NOTE_SEL = 'textarea[ng-model="$root.activeCart.Description"], textarea[placeholder*="Ghi chú đơn hàng"]';

function stampNotePlaceholder() {
    const n = document.querySelector(NOTE_SEL); if (!n) return;
    const ph = n.getAttribute('placeholder') || '';
    if (!ph.includes('F12')) n.setAttribute('placeholder', ph.trim() + ' (F12)');
    // Single line — no wrapping, Enter = confirm
    n.style.setProperty('resize',        'none',    'important');
    n.style.setProperty('overflow',      'hidden',  'important');
    n.style.setProperty('white-space',   'nowrap',  'important');
    n.style.setProperty('text-overflow', 'ellipsis','important');
    n.style.setProperty('height',        '40px',    'important');
    if (!n._kvNote) {
        n._kvNote = true;
        n.addEventListener('keydown', e => {
            if (e.key === 'Enter') { e.preventDefault(); n.blur(); focusSearch(); }
        }, { passive: false });
    }
}
stampNotePlaceholder();
new MutationObserver(stampNotePlaceholder).observe(document.body, { childList: true, subtree: true });

function switchDing() { tone('sine', 1200, 1.0, 0.18); tone('sine', 900, 0.8, 0.18, 0.05); }

document.addEventListener('keydown', e => {
    if (e.key === 'F6') {
        e.preventDefault(); e.stopImmediatePropagation(); // block bán nhanh/thường toggle
    }
    if (e.key === 'F2') {
        e.preventDefault(); e.stopImmediatePropagation();
        document.querySelector('button.btn-change-type')?.click();
        switchDing();
    }
    if (e.key === 'F11') {
        e.preventDefault(); e.stopImmediatePropagation();
    }
    if (e.key === 'F12') {
        e.preventDefault(); e.stopImmediatePropagation();
        const n = document.querySelector(NOTE_SEL);
        if (n) { n.focus(); n.select(); }
    }
}, true);

// ── Money hotkeys ─────────────────────────────────────────────────
// Left Ctrl+Numpad 1-9 = 100k-900k, 0 = 1M
// Alt+Numpad 1-9 = 1.1M-1.9M, 0 = 2M
// Tab+digit = 10k-90k, Tab+0 = 0
let _tabHeld = false;

function isCash() {
    for (const r of document.querySelectorAll('input[type="radio"]')) {
        const ng = r.getAttribute('ng-model') || '';
        if (/singlePaymentType/.test(ng) && r.checked)
            return Number(r.value) === 0 || Number(r.getAttribute('ng-value')) === 0;
    }
    const cr = document.querySelector('input[type=radio][value="0"],input[type=radio][ng-value="0"]');
    if (cr) return cr.checked;
    try { const t = window.angular?.element(document.body)?.scope?.()?.$root?.activeCart?.singlePaymentType; if (t !== undefined) return t === 0; } catch(e) {}
    return true;
}

function applyAmount(amount) {
    const inp = document.querySelector('#payingAmtInvoice'); if (!inp) return;
    const ns = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    ns.call(inp, String(Math.round(amount)));
    inp.dispatchEvent(new Event('input',  { bubbles: true }));
    inp.dispatchEvent(new Event('change', { bubbles: true }));
    ns.call(inp, Math.round(amount).toLocaleString('en-US'));
    const prev = inp.style.boxShadow;
    inp.style.boxShadow = '0 0 0 3px rgba(46,204,113,.55)';
    setTimeout(() => { inp.style.boxShadow = prev; }, 350);
    setTimeout(() => { const f = document.querySelector('#productSearchInput'); if (f) { f.focus(); f.select(); } }, 300);
}

// Alt+Numpad: suppress weird symbols (♣ etc) AND handle amount
document.addEventListener('keydown', e => {
    const m = /^Numpad([0-9])$/.exec(e.code || '');
    const n = m ? Number(m[1]) : (e.location === 3 && /^[0-9]$/.test(e.key)) ? Number(e.key) : null;
    if (e.altKey && n !== null) {
        e.preventDefault(); e.stopImmediatePropagation();
        if (isCash()) applyAmount(n === 0 ? 2_000_000 : 1_000_000 + n * 100_000);
        return;
    }
}, true);

// Suppress Alt+num keypress to prevent symbol insertion
document.addEventListener('keypress', e => {
    if (e.altKey) { e.preventDefault(); e.stopImmediatePropagation(); }
}, true);

// Left Ctrl+Numpad = 100k-1M
document.addEventListener('keydown', e => {
    if (!e.ctrlKey || e.altKey || !isCash()) return;
    const m = /^Numpad([0-9])$/.exec(e.code || '');
    const n = m ? Number(m[1]) : (e.location === 3 && /^[0-9]$/.test(e.key)) ? Number(e.key) : null;
    if (n === null) return;
    e.preventDefault(); e.stopImmediatePropagation();
    applyAmount(n === 0 ? 1_000_000 : n * 100_000);
}, true);

document.addEventListener('keydown', e => {
    if (e.key === 'Tab') { e.preventDefault(); e.stopImmediatePropagation(); _tabHeld = true; return; }
    if (_tabHeld && /^[0-9]$/.test(e.key) && isCash()) {
        e.preventDefault(); e.stopImmediatePropagation();
        applyAmount(Number(e.key) === 0 ? 0 : Number(e.key) * 10_000);
    }
}, true);
document.addEventListener('keyup', e => { if (e.key === 'Tab') _tabHeld = false; }, true);

})();