// ==UserScript==
// @name         [KOV] [sale] [10] — PageUp/Down/End to round
// @namespace    http://tampermonkey.net/
// @version      6.3
// @description  Double PageUp → round Tổng tiền hàng, Double PageDown → remove decimal discount, Double End → clear discount + uncheck làm tròn tiền, auto-close popovers, restore F3 focus, soothing ping
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// ==/UserScript==

(function () {
    let lastPgUp = 0;
    let lastPgDown = 0;
    let lastEnd = 0;
    let ignoreNextRound = false;

    // ================= SOOTHING PING =================
    function playSoothingPing() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);

            osc.type = 'sine';
            osc.frequency.value = 800; // gentle pitch
            gain.gain.setValueAtTime(0.15, ctx.currentTime); // soft volume

            osc.start();
            osc.stop(ctx.currentTime + 0.12); // 120ms duration

            setTimeout(() => ctx.close(), 200);
        } catch (err) {
            console.warn('AudioContext not available', err);
        }
    }

    // ================= FOCUS RESTORE =================
    function restoreSearchFocusSmart() {
        const search = document.querySelector('#productSearchInput');
        if (!search) return;
        let tries = 0;
        const reclaim = setInterval(() => {
            if (document.activeElement !== search) {
                document.dispatchEvent(new KeyboardEvent("keydown", { key: "F3", code: "F3", keyCode: 114, bubbles: true }));
            }
            if (++tries > 8) clearInterval(reclaim);
        }, 120);
    }

    // ================= PAGEUP LOGIC =================
    function getCartTotal() {
        const el = document.querySelector(".payment-content .form-group-price .col-form-wrap.text-right");
        if (!el) return null;
        const txt = el.innerText.replace(/[^0-9]/g, "");
        return parseInt(txt, 10) || 0;
    }

    // corrected rounding diff (always correct to nearest thousand)
    function calcRoundDiff(total) {
        const step = 1000;
        const remainder = total % step;
        return remainder === 0 ? 0 : step - remainder;
    }

    function processLamTronTien() {
        let tries = 0;
        const timer = setInterval(() => {
            if (++tries > 40) return clearInterval(timer);

            const win = document.querySelector(".surcharge-window");
            if (!win) return;

            const row = [...win.querySelectorAll("tbody tr")].find(r => r.innerText.includes("làm tròn tiền"));
            if (!row) return;

            const cb = row.querySelector("input[type='checkbox']");
            if (cb && !cb.checked) cb.click();

            const btn = row.querySelector("button[id^='surchargeItem_']");
            if (!btn) return;
            btn.click();

            setTimeout(() => {
                const input = document.querySelector(".popover-surcharge input.form-control");
                if (!input) return;

                const total = getCartTotal();
                const diff = calcRoundDiff(total);
                if (diff <= 0) {
                    const closeBtn = win.querySelector(".k-window-action");
                    if (closeBtn) closeBtn.click();
                    restoreSearchFocusSmart();
                    playSoothingPing();
                    return;
                }

                input.focus();
                input.value = diff.toString();
                input.dispatchEvent(new Event("input", { bubbles: true }));

                setTimeout(() => {
                    input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: true }));
                }, 120);

                setTimeout(() => {
                    const closeBtn = win.querySelector(".k-window-action");
                    if (closeBtn) closeBtn.click();
                }, 250);

                setTimeout(() => {
                    restoreSearchFocusSmart();
                    playSoothingPing();
                }, 400);
            }, 150);

            clearInterval(timer);
        }, 100);
    }

    // ================= PAGEDOWN LOGIC =================
    function findDiscountButtonByLabel() {
        const labels = Array.from(document.querySelectorAll('label.col-form-label'));
        for (const lbl of labels) {
            if (lbl.textContent.trim() === "Giảm giá") {
                const block = lbl.closest('.form-group-inline');
                if (!block) continue;
                const btn = block.querySelector('button.form-discount');
                if (btn) return btn;
            }
        }
        return null;
    }

    // FIXED: properly detect last 3 digits (not middle group)
    function applyRoundDiscount() {
        const totalEl = document.querySelector('.form-group-price .col-form-wrap.text-right');
        if (!totalEl) return;

        let text = totalEl.textContent.replace(/[^\d,]/g, "");
        if (!text) return;

        const parts = text.split(",");
        if (parts.length < 2) return; // no comma group, skip

        const lastGroup = parts[parts.length - 1];
        const remove = parseInt(lastGroup, 10);
        if (!remove || remove >= 1000) return;

        const discountValue = remove.toString();
        const btn = findDiscountButtonByLabel();
        if (!btn) return;
        btn.click();

        setTimeout(() => {
            const input = document.querySelector('#priceInput');
            if (!input) return;

            input.focus();
            input.value = discountValue;
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));

            setTimeout(() => {
                input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: true }));

                setTimeout(() => {
                    document.body.click();
                    const pop = document.querySelector('.popover-discount');
                    if (pop) pop.style.display = 'none';

                    setTimeout(() => {
                        restoreSearchFocusSmart();
                        playSoothingPing();
                    }, 120);
                }, 120);
            }, 120);
        }, 240);
    }

    // ================= DOUBLE END LOGIC =================
    function findDiscountButton() {
        const labels = Array.from(document.querySelectorAll('label.col-form-label'));
        for (const lbl of labels) {
            if (lbl.textContent.trim() === "Giảm giá") {
                const block = lbl.closest('.form-group-inline');
                if (!block) continue;
                const btn = block.querySelector('button.form-discount');
                if (btn) return btn;
            }
        }
        return null;
    }

    function openThuKhacWidget(callback) {
        const tryOpen = () => {
            const btn = document.querySelector('#btnSurcharge');
            if (btn && btn.offsetParent !== null) {
                btn.click();
                btn.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: true }));
                if (callback) callback();
            } else {
                setTimeout(tryOpen, 100);
            }
        };
        tryOpen();
    }

    function uncheckLamTronTien(callback) {
        setTimeout(() => {
            const win = document.querySelector('.surcharge-window');
            if (!win) { if (callback) callback(); return; }

            const row = [...win.querySelectorAll('tbody tr')].find(r => r.innerText.includes("làm tròn tiền"));
            if (!row) { if (callback) callback(); return; }

            const cb = row.querySelector('input[type="checkbox"]');
            if (cb && cb.checked) cb.click();

            const closeBtn = win.querySelector('.k-window-action');
            if (closeBtn) closeBtn.click();

            if (callback) callback();
        }, 300);
    }

    // ================= EVENT LISTENER =================
    document.addEventListener("keydown", function (e) {
        const now = Date.now();

        // PAGEUP = round up
        if (e.key === "PageUp") {
            if (!ignoreNextRound && now - lastPgUp < 350) {
                const btn = document.querySelector('#btnSurcharge');
                if (btn) {
                    btn.click();
                    setTimeout(() => {
                        btn.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: true }));
                    }, 80);
                    setTimeout(() => { processLamTronTien(); restoreSearchFocusSmart(); playSoothingPing(); }, 300);
                }
            }
            lastPgUp = now;
        }

        // PAGEDOWN = round discount decimals
        if (e.key === "PageDown") {
            if (!ignoreNextRound && now - lastPgDown < 350) {
                applyRoundDiscount();
                playSoothingPing();
            }
            lastPgDown = now;
        }

        // DOUBLE END = clear discount + uncheck Làm tròn tiền
        if (e.key === "End") {
            if (now - lastEnd < 350) {
                const discountBtn = findDiscountButton();
                if (discountBtn) {
                    discountBtn.click();

                    const waitInput = setInterval(() => {
                        const input = document.querySelector('#priceInput');
                        if (input) {
                            clearInterval(waitInput);
                            input.focus();
                            input.value = '0';
                            input.dispatchEvent(new Event('input', { bubbles: true }));
                            input.dispatchEvent(new Event('change', { bubbles: true }));
                            input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: true }));

                            openThuKhacWidget(() => {
                                uncheckLamTronTien(() => {
                                    restoreSearchFocusSmart();
                                    playSoothingPing();
                                });
                            });
                        }
                    }, 100);
                }
            }
            lastEnd = now;
        }

    });
})();
