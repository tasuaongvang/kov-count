// ==UserScript==
// @name         [KOV] hỗ trợ nhập kho
// @namespace    http://tampermonkey.net/
// @version      3.2
// @description  All-in-one KiotViet enhancer — optimized
// @match        https://cov.kiotviet.vn/man/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function () {
    'use strict';

    // ===========================================================
    // ============= AUDIO =======================================
    // ===========================================================

    let sharedCtx = null;
    function getCtx() {
        try {
            if (!sharedCtx || sharedCtx.state === 'closed') {
                sharedCtx = new (window.AudioContext || window.webkitAudioContext)();
            }
            if (sharedCtx.state === 'suspended') sharedCtx.resume().catch(() => {});
            return sharedCtx;
        } catch (e) { return null; }
    }

    function playSoothingPing() {
        const ctx = getCtx(); if (!ctx) return;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const comp = ctx.createDynamicsCompressor();
        osc.connect(gain); gain.connect(comp); comp.connect(ctx.destination);
        osc.type = 'sine'; osc.frequency.value = 800;
        gain.gain.setValueAtTime(0.8, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18);
        osc.start(); osc.stop(ctx.currentTime + 0.18);
    }

    function playSofterChime() {
        const ctx = getCtx(); if (!ctx) return;
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();
        const filter = ctx.createBiquadFilter();
        const comp = ctx.createDynamicsCompressor();
        osc1.type = 'sine'; osc2.type = 'sine';
        osc1.frequency.setValueAtTime(720, ctx.currentTime);
        osc2.frequency.setValueAtTime(1080, ctx.currentTime);
        osc2.detune.setValueAtTime(10, ctx.currentTime);
        filter.type = 'lowpass'; filter.frequency.value = 3200; filter.Q.value = 0.8;
        gain.gain.setValueAtTime(0, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.8, ctx.currentTime + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);
        osc1.connect(filter); osc2.connect(filter);
        filter.connect(gain); gain.connect(comp); comp.connect(ctx.destination);
        osc1.start(); osc2.start();
        osc1.stop(ctx.currentTime + 1.25); osc2.stop(ctx.currentTime + 1.25);
    }

    const alertAudio = new Audio("https://github.com/tasuaongvang/cov/raw/refs/heads/main/chua_co_ma_nay_be_oi.mp3");
    alertAudio.volume = 1.0;
    function playAlertSound() {
        alertAudio.currentTime = 0;
        alertAudio.play().catch(() => {});
    }


    // ===========================================================
    // ============= STATE =======================================
    // ===========================================================

    let currentMode = "VND";
    let lastHash = "";
    let isPOPage = false;
    let lastQty = null;
    let qtyObserver = null;
    let globalDebounce = null;
    let pricebookButton = null;
    let lastPgUp = 0, lastPgDown = 0, lastEnd = 0;


    // ===========================================================
    // ============= ROUTE WATCHER ===============================
    // ===========================================================

    function onRouteChange() {
        const hash = location.hash;
        if (hash === lastHash) return;
        lastHash = hash;
        isPOPage = hash.includes("/PurchaseOrder/new");
        isPOPage ? setupPOPage() : teardownPOPage();
    }

    function setupPOPage() {
        createToolbarIcons();
        applyDiscountMode();
        blinkFocusInput();
        lastQty = null;
        watchQtySpan();
    }

    function teardownPOPage() {
        document.getElementById("kv-discount-mode-icons")?.remove();
        stopQtyObserver();
        lastQty = null;
    }

    window.addEventListener("hashchange", onRouteChange);
    setInterval(onRouteChange, 800); // fallback — exits in ~1µs if hash unchanged


    // ===========================================================
    // ============= QTY WATCHER =================================
    // Observer on the specific span only — no polling
    // ===========================================================

    function watchQtySpan() {
        if (qtyObserver) return;
        const span = document.querySelector('span[ng-show="settings.UseTotalQuantity"]');
        if (!span) return;
        // Seed current value so 0→1 (first scan) also fires chime
        lastQty = parseFloat(span.textContent.trim()) || 0;
        qtyObserver = new MutationObserver(() => {
            const val = parseFloat(span.textContent.trim());
            if (!isNaN(val) && val !== lastQty) {
                playSofterChime();
                lastQty = val;
            }
        });
        qtyObserver.observe(span, { childList: true, subtree: true, characterData: true });
    }

    function stopQtyObserver() {
        qtyObserver?.disconnect();
        qtyObserver = null;
    }


    // ===========================================================
    // ============= SINGLE GLOBAL OBSERVER ======================
    // ===========================================================

    const globalObserver = new MutationObserver(mutations => {
        // Toast check — immediate, lightweight string scan on added nodes only
        for (const m of mutations) {
            for (const node of m.addedNodes) {
                if (node instanceof HTMLElement &&
                    node.innerText?.includes("Không tìm thấy sản phẩm có mã:")) {
                    playAlertSound();
                }
            }
        }
        // DOM settle work — debounced to avoid thrashing on Angular rerenders
        clearTimeout(globalDebounce);
        globalDebounce = setTimeout(onDomSettle, 300);
    });
    globalObserver.observe(document.body, { childList: true, subtree: true });

    function onDomSettle() {
        setupInputSelect();
        pricebookButton = document.querySelector('a.kv-btn.kv-btn-link[ng-click="addPricebook();"]');
        if (isPOPage) {
            createToolbarIcons();
            applyDiscountMode();
            if (!qtyObserver) watchQtySpan(); // retry if span wasn't in DOM yet
        }
    }


    // ===========================================================
    // ============= INPUT SETUP =================================
    // ===========================================================

    function setupInputSelect() {
        const input = document.getElementById('productSearchInput');
        if (!input || input._kvSetup) return;
        input._kvSetup = true;
        input.addEventListener('keydown', e => {
            if (e.key === 'Enter') setTimeout(() => input.select(), 0);
        });
    }
    setupInputSelect();

    function blinkFocusInput() {
        const input = document.querySelector('#productSearchInput');
        if (!input) return;
        input.readOnly = true;
        input.focus(); input.select();
        setTimeout(() => { input.readOnly = false; input.focus(); input.select(); }, 50);
    }


    // ===========================================================
    // ============= TOOLBAR ICONS ===============================
    // ===========================================================

    const BOX_CSS = "display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border:1.5px solid #ddd;border-radius:4px;cursor:pointer;font-size:13px;font-weight:bold;background:#fff;transition:color .15s,border-color .15s;user-select:none;";

    function createToolbarIcons() {
        if (document.getElementById("kv-discount-mode-icons")) return;
        const anchor = document.querySelector("label.input-fast");
        if (!anchor) return;

        const wrapper = document.createElement("span");
        wrapper.id = "kv-discount-mode-icons";
        wrapper.style.cssText = "display:inline-flex;align-items:center;margin-left:4px;vertical-align:middle;";

        const vndBox = document.createElement("span");
        vndBox.id = "kv-icon-vnd";
        vndBox.title = "Giảm theo VND (Ctrl+$ / Ctrl+4)";
        vndBox.style.cssText = BOX_CSS;
        vndBox.innerHTML = `<i class="fas fa-dollar-sign"></i>`;
        vndBox.onclick = () => { currentMode = "VND"; applyDiscountMode(); };

        const connector = document.createElement("span");
        connector.style.cssText = "display:inline-block;width:10px;height:1.5px;background:#ccc;margin:0 1px;flex-shrink:0;";

        const pctBox = document.createElement("span");
        pctBox.id = "kv-icon-pct";
        pctBox.title = "Giảm theo % (Ctrl+% / Ctrl+5)";
        pctBox.style.cssText = BOX_CSS;
        pctBox.innerHTML = `<i class="fas fa-percent"></i>`;
        pctBox.onclick = () => { currentMode = "%"; applyDiscountMode(); };

        wrapper.append(vndBox, connector, pctBox);
        anchor.parentNode.insertBefore(wrapper, anchor.nextSibling);
        updateIconStyles();
    }

    function updateIconStyles() {
        const vndBox = document.getElementById("kv-icon-vnd");
        const pctBox = document.getElementById("kv-icon-pct");
        if (!vndBox || !pctBox) return;
        // Set discrete properties — never use += on cssText (causes unbounded growth)
        const [on, off] = currentMode === "VND" ? [vndBox, pctBox] : [pctBox, vndBox];
        on.style.color = "#1890ff"; on.style.borderColor = "#1890ff"; on.style.opacity = "1";
        off.style.color = "#aaa";   off.style.borderColor = "#ddd";   off.style.opacity = "0.5";
    }


    // ===========================================================
    // ============= DISCOUNT MODE ===============================
    // ===========================================================

    function applyDiscountMode() {
        const labels = document.querySelectorAll("label.form-label");
        let label = null;
        for (const l of labels) {
            if (l.textContent.trim().startsWith("Giảm giá")) { label = l; break; }
        }
        if (!label) return;
        const toggle = label.parentElement.parentElement.querySelector("kv-toggle");
        if (!toggle) return;
        const btns = toggle.querySelectorAll("a.btn-toggle");
        if (btns.length < 2) return;
        const [vndBtn, pctBtn] = btns;
        if (currentMode === "VND" && !vndBtn.classList.contains("active")) vndBtn.click();
        if (currentMode === "%" && !pctBtn.classList.contains("active")) pctBtn.click();
        updateIconStyles();
    }


    // ===========================================================
    // ============= HELPERS =====================================
    // ===========================================================

    function restoreSearchFocusSmart() {
        const search = document.querySelector('#productSearchInput');
        if (!search) return;
        let tries = 0;
        const t = setInterval(() => {
            if (document.activeElement !== search) {
                document.dispatchEvent(new KeyboardEvent("keydown", { key: "F3", code: "F3", keyCode: 114, bubbles: true }));
            }
            if (++tries > 8) clearInterval(t);
        }, 120);
    }

    function getCartTotal() {
        const el = document.querySelector('span.kv-form-output.kv-form-output-static.payOrder');
        return parseInt(el?.innerText.replace(/[^0-9]/g, "") || "0", 10) || 0;
    }

    function calcRoundDiff(total) {
        return Math.max(Math.ceil(total / 1000) * 1000 - total, 0);
    }

    // Shared inner polling logic for both processLamTronTien and clearDiscount
    function fillExpensesInput(win, value, onDone) {
        let tries = 0;
        const t = setInterval(() => {
            if (++tries > 40) return clearInterval(t);
            const input = document.querySelector("input[ng-model='formData.ExValueRaw']");
            if (!input) return;
            clearInterval(t);
            input.focus();
            input.value = String(value);
            input.dispatchEvent(new Event("input", { bubbles: true }));
            input.dispatchEvent(new Event("change", { bubbles: true }));
            input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: true }));
            setTimeout(() => {
                document.body.click();
                win.querySelector(".k-window-action")?.click();
                restoreSearchFocusSmart();
                playSoothingPing();
                onDone?.();
            }, 180);
        }, 80);
    }


    // ===========================================================
    // ============= PAGEUP = ROUND UP ===========================
    // ===========================================================

    function processLamTronTien() {
        let tries = 0;
        const t = setInterval(() => {
            if (++tries > 80) return clearInterval(t);
            const win = document.querySelector(".k-window-expensesOtherInput");
            if (!win) return;
            const row = [...win.querySelectorAll("tbody tr")].find(r => r.innerText.includes("làm tròn tiền"));
            if (!row) return;
            const cb = row.querySelector("input[type='checkbox']");
            if (cb && !cb.checked) cb.click();
            const inputBtn = row.querySelector("a.form-control.iptPay");
            if (!inputBtn) return;
            inputBtn.click();
            clearInterval(t);
            fillExpensesInput(win, calcRoundDiff(getCartTotal()));
        }, 100);
    }


    // ===========================================================
    // ============= PAGEDOWN = ROUND DISCOUNT ===================
    // ===========================================================

    function applyRoundDiscount() {
        document.querySelector('#idDiscountOnOrder')?.click();
        let tries = 0;
        const t = setInterval(() => {
            if (++tries > 60) return clearInterval(t); // max ~3s
            const input = document.querySelector('#idDiscountValue');
            const totalEl = document.querySelector('span.kv-form-output.kv-form-output-static.payOrder');
            if (!input || !totalEl) return;
            clearInterval(t);
            input.focus();
            const match = totalEl.textContent.trim().match(/,(\d{3})$/);
            input.value = match ? match[1] : '111';
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
            input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
            setTimeout(() => document.body.click(), 150);
        }, 50);
    }


    // ===========================================================
    // ============= END x2 = CLEAR ALL ==========================
    // ===========================================================

    function clearDiscountAndUncheckLamTron() {
        document.querySelector('#idDiscountOnOrder')?.click();
        setTimeout(() => {
            const input = document.querySelector('#iptDiscount, #idDiscountValue');
            if (input) {
                input.focus();
                input.value = '0';
                input.dispatchEvent(new Event('input', { bubbles: true }));
                input.dispatchEvent(new Event('change', { bubbles: true }));
                input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: true }));
            }
            setTimeout(() => {
                document.querySelector('a.iptPay.ng-binding')?.click();
                let tries = 0;
                const t = setInterval(() => {
                    if (++tries > 80) return clearInterval(t);
                    const win = document.querySelector(".k-window-expensesOtherInput");
                    if (!win) return;
                    const row = [...win.querySelectorAll("tbody tr")].find(r => r.innerText.includes("làm tròn tiền"));
                    if (!row) return;
                    const cb = row.querySelector("input[type='checkbox']");
                    const inputBtn = row.querySelector("a.form-control.iptPay");
                    if (!inputBtn) return;
                    inputBtn.click();
                    clearInterval(t);
                    fillExpensesInput(win, 0, () => { if (cb?.checked) cb.click(); });
                }, 100);
            }, 200);
        }, 200);
    }


    // ===========================================================
    // ============= KEYDOWN HANDLER =============================
    // ===========================================================

    document.addEventListener("keydown", e => {
        const now = Date.now();

        if (e.ctrlKey && (e.key === "$" || e.key === "4")) {
            e.preventDefault(); currentMode = "VND"; applyDiscountMode(); playSoothingPing(); return;
        }
        if (e.ctrlKey && (e.key === "%" || e.key === "5")) {
            e.preventDefault(); currentMode = "%"; applyDiscountMode(); playSoothingPing(); return;
        }
        if (e.key === "PageUp") {
            if (now - lastPgUp < 350) {
                document.querySelector('a.iptPay.ng-binding')?.click();
                setTimeout(processLamTronTien, 300);
            }
            lastPgUp = now; return;
        }
        if (e.key === "PageDown") {
            if (now - lastPgDown < 350) {
                currentMode = "VND"; applyDiscountMode(); applyRoundDiscount(); playSoothingPing();
            }
            lastPgDown = now; return;
        }
        if (e.key === "End") {
            if (now - lastEnd < 350) clearDiscountAndUncheckLamTron();
            lastEnd = now; return;
        }
        if (e.key === "Insert" && pricebookButton) {
            pricebookButton.dispatchEvent(new MouseEvent('click', { view: window, bubbles: true, cancelable: true }));
        }
    });


    // ===========================================================
    // ============= INIT ========================================
    // ===========================================================

    onRouteChange();

})();