// ==UserScript==
// @name         [KOV] [sale] ALL-IN-ONE v2
// @namespace    http://tampermonkey.net/
// @version      2.0
// @description  All 12 KOV scripts – rewritten: 1 root observer, shared state, shared audio, 2 intervals total
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
'use strict';

/* ════════════════════════════════════════════════════════
   UTILITIES
════════════════════════════════════════════════════════ */
const qs  = (s, r = document) => r.querySelector(s);
const qsa = (s, r = document) => r.querySelectorAll(s);
const sleep    = ms => new Promise(r => setTimeout(r, ms));
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const normalize  = s => (s || '').toString().trim().toLowerCase();
const normPlain  = s => normalize(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '');
const nativeSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;

/* ════════════════════════════════════════════════════════
   ROOT OBSERVER  —  replaces ~14 separate body observers
   Every DOM mutation fans out through ONE observer.
════════════════════════════════════════════════════════ */
const _domCbs = new Set();
new MutationObserver(muts => _domCbs.forEach(fn => { try { fn(muts); } catch(e) {} }))
    .observe(document.body, { childList: true, subtree: true });

/** Register a DOM-mutation handler. Returns unsubscribe fn. */
function onDOMChange(fn) { _domCbs.add(fn); return () => _domCbs.delete(fn); }

/** Promise that resolves when `sel` first appears in DOM. Zero polling. */
function waitFor(sel, timeout = 20000) {
    const el = qs(sel);
    if (el) return Promise.resolve(el);
    return new Promise((res, rej) => {
        const t   = setTimeout(() => { off(); rej(new Error('waitFor timeout: ' + sel)); }, timeout);
        const off = onDOMChange(() => { const e = qs(sel); if (e) { clearTimeout(t); off(); res(e); } });
    });
}

/* ════════════════════════════════════════════════════════
   SHARED STATE  —  single source of truth, updated once
   per debounced (120ms) DOM burst, read by every section.
════════════════════════════════════════════════════════ */
const state = {
    cartQty: 0, payType: null, payValue: null,
    pricebook: '', bankOk: true, isPBMismatch: false, isDisabled: false,
};
const _sCbs = new Set();
function onStateChange(fn) { _sCbs.add(fn); return () => _sCbs.delete(fn); }
function _notifyState()    { _sCbs.forEach(fn => { try { fn(); } catch(e) {} }); }

function _readPayType() {
    const box = qs('.single-payment-box');
    if (box?.offsetParent !== null) {
        const lbl  = box.querySelector('span');
        const meths = box.querySelector('span[ng-if]');
        if (lbl?.textContent.includes('Thanh toán kết hợp') && meths?.textContent.trim())
            return { type: 'mixed', value: null };
    }
    const chk = qs('.form-check-methods input.form-check-input:checked');
    if (!chk) return { type: null, value: null };
    const txt = normalize(chk.closest('label')?.querySelector('.text-check span')?.textContent || '');
    if (txt === 'tiền mặt')     return { type: 'cash', value: chk.value };
    if (txt === 'chuyển khoản') return { type: 'bank', value: chk.value };
    return { type: txt || null, value: chk.value };
}
function _readPricebook() {
    const k = qs('pricebook-component .k-dropdown-wrap .k-input span');
    if (k?.textContent?.trim()) return k.textContent.trim();
    const sel = qs('pricebook-component select#pricebook, select#pricebook');
    if (sel?.options?.length && sel.selectedIndex >= 0) return sel.options[sel.selectedIndex].text?.trim() || '';
    return '';
}
function _readBankOk() {
    const wrap = qs('#bankAccountDropdown')?.closest('span.k-widget');
    if (!wrap) return true;
    const txt = normalize(wrap.querySelector('span.k-input')?.textContent || '');
    return txt !== '' && !txt.includes('tài khoản nhận');
}

const _doUpdateState = debounce(() => {
    const qty    = parseFloat(qs('span.text-bg-default')?.textContent?.replace(/[^\d.\-eE]/g, '') || '0') || 0;
    const { type: payType, value: payValue } = _readPayType();
    const pb     = _readPricebook();
    const bankOk = _readBankOk();
    const payUIOn = qs('.form-check-methods')?.offsetParent !== null;

    // Mismatch: original S5 used numeric radio value ('0'=cash, '2'=bank)
    let isPBMismatch = false;
    if (payUIOn && pb && payValue !== null) {
        const pbn = normalize(pb);
        if (pbn.includes('bảng giá chung') && payValue !== '2') isPBMismatch = true;
        if (pbn.includes('tiền mặt')        && payValue !== '0') isPBMismatch = true;
    }

    state.cartQty      = qty;
    state.payType      = payType;
    state.payValue     = payValue;
    state.pricebook    = pb;
    state.bankOk       = bankOk;
    state.isPBMismatch = isPBMismatch;
    state.isDisabled   = (payType === 'bank' && !bankOk) || isPBMismatch;
    _notifyState();
}, 120);

onDOMChange(_doUpdateState);
_doUpdateState();

/* ════════════════════════════════════════════════════════
   SHARED AUDIO  —  one AudioContext for all synth sounds
════════════════════════════════════════════════════════ */
let _ctx = null;
const _audioCbs = new Set();
function onAudioStateChange(fn) { _audioCbs.add(fn); }

function getCtx() {
    if (!_ctx) {
        _ctx = new (window.AudioContext || window.webkitAudioContext)();
        _ctx.onstatechange = () => _audioCbs.forEach(fn => { try { fn(); } catch(e) {} });
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible' && _ctx?.state === 'suspended')
                _ctx.resume().catch(() => {});
        });
    }
    if (_ctx.state === 'suspended') _ctx.resume().catch(() => {});
    return _ctx;
}

['pointerdown', 'keydown', 'touchstart'].forEach(ev =>
    document.addEventListener(ev, () => getCtx(), { once: true, passive: true })
);

function _tone(type, freq, peak, dur, delay = 0) {
    try {
        const ctx = getCtx(), t = ctx.currentTime + delay;
        const osc = ctx.createOscillator(), g = ctx.createGain();
        osc.type = type; osc.frequency.value = freq;
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(peak, t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        osc.connect(g); g.connect(ctx.destination);
        osc.start(t); osc.stop(t + dur);
    } catch(e) {}
}

const SND = {
    itemChime()  { _tone('sine',    820,  0.35, 0.4);  _tone('sine',     1640, 0.2,  0.4);  },
    cashChime()  { _tone('square',  540,  0.35, 0.35); _tone('triangle', 1080, 0.2,  0.35); },
    fraction(f)  { const h = { 0.25: 660, 0.5: 720, 0.75: 780 }[f]; if (h) _tone('sine', h, 0.8, 0.18); },
    welcome()    { _tone('triangle', 660, 0.42, 0.75); _tone('triangle', 880, 0.42, 0.75, 0.13); },
    switchDing() { _tone('sine',    1200, 0.28, 0.12); },
    beep()       { _tone('square',   520, 0.15, 0.13); },
    ping()       { _tone('sine',     800, 0.15, 0.12); },
    url(u)       { try { new Audio(u).play().catch(() => {}); } catch(e) {} },
};
let _lastWelcome = 0;
SND.welcomeOnce = () => { const n = Date.now(); if (n - _lastWelcome < 1200) return; _lastWelcome = n; SND.welcome(); };


/* ════════════════════════════════════════════════════════
   S1 — MONITOR BOX + SHIBA + GIANT NUMBER + AFTER-SALE
════════════════════════════════════════════════════════ */
(function s1() {
    const BOX_DEF  = 'rgba(232,247,255,0.1)';
    const BOX_REF  = 'rgba(250,219,20,0.7)';
    const BOX_DEBT = 'rgba(255,77,79,0.7)';
    const BOPACITY = 0.95;
    const IMG_URL  = 'https://upload.wikimedia.org/wikipedia/commons/c/ca/1x1.png';

    /* --- Shiba + smiley while page boots --- */
    waitFor('.cart-container').then(cart => {
        qs('#loading-bar-spinner')?.style.setProperty('display', 'none');
        if (getComputedStyle(cart).position === 'static') cart.style.position = 'relative';

        if (!qs('#kv-center-smiley')) {
            const img = Object.assign(document.createElement('img'), { id: 'kv-center-smiley', src: IMG_URL });
            Object.assign(img.style, { position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)', width:'120px', height:'120px', borderRadius:'50%', zIndex:'99998', opacity:'0', transition:'opacity .5s ease-in-out', pointerEvents:'none' });
            cart.appendChild(img);
            requestAnimationFrame(() => img.style.opacity = '1');
        }

        if (!qs('#shiba-loading-text')) {
            const tx = document.createElement('div');
            tx.id = 'shiba-loading-text'; tx.textContent = 'shiba đang đếm ...';
            Object.assign(tx.style, { position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)', fontSize:'28px', fontWeight:'700', color:'#d4380d', fontFamily:`'Inter','Segoe UI',Arial,sans-serif`, zIndex:'99999', pointerEvents:'none', background:'transparent', textAlign:'center', opacity:'0', transition:'opacity .5s ease-in-out' });
            cart.appendChild(tx);
            requestAnimationFrame(() => tx.style.opacity = '1');
            waitFor('.cart-footer').then(() => setTimeout(() => {
                tx.style.opacity = '0';
                setTimeout(() => tx.remove(), 700);
            }, 800));
        }
    });

    /* --- Monitor box --- */
    const box = document.createElement('div');
    box.id = 'sale-info-box';
    Object.assign(box.style, { display:'block', padding:'12px 20px', borderRadius:'6px', fontFamily:`'Inter','Segoe UI',Arial,sans-serif`, fontSize:'22px', fontWeight:'700', textAlign:'center', position:'fixed', zIndex:9999, opacity:'0', transform:'translateY(73px)', transition:'opacity .5s ease, transform .5s ease', pointerEvents:'none', backdropFilter:'blur(1px)' });
    document.body.appendChild(box);

    const topLine = document.createElement('div');
    topLine.id = 'sale-info-topline';
    Object.assign(topLine.style, { fontFamily:`'Inter','Segoe UI',Arial,sans-serif`, fontSize:'22px', fontWeight:'700', textAlign:'left', position:'fixed', zIndex:9999, opacity:'0', transform:'translateY(50px)', transition:'opacity .5s ease, transform .5s ease', pointerEvents:'none', color:'#003a8c' });
    document.body.appendChild(topLine);

    function getLabelValue(keyword) {
        for (const lbl of qsa('label')) {
            if (!lbl.textContent.toLowerCase().includes(keyword)) continue;
            const m = (lbl.closest('div')?.textContent || '').replace(/\s+/g, ' ').match(/-?\d[\d.,]*/);
            return m ? parseFloat(m[0].replace(/[^\d.-]/g, '').replace(',', '.')) || 0 : null;
        }
        return null;
    }

    let lastScale = 1.0, boxCreated = false;

    function updateBox() {
        const { cartQty: qty, payType } = state;
        const debt = getLabelValue('tính vào công nợ') || 0;

        let scale = qty >= 21 ? 1.5 : qty >= 16 ? 1.4 : qty >= 11 ? 1.3 : qty >= 6 ? 1.15 : 1.0;
        if (scale > lastScale) box.animate([
            { transform: 'scale(1)',   boxShadow: '0 0 0 rgba(0,0,0,0)' },
            { transform: 'scale(1.1)', boxShadow: '0 0 20px rgba(255,200,0,.6)' },
            { transform: 'scale(1)',   boxShadow: '0 0 0 rgba(0,0,0,0)' },
        ], { duration: 600, easing: 'ease-out' });
        lastScale = scale;
        box.style.fontSize = `${22 * scale}px`;
        box.style.padding  = `${12 * scale}px ${20 * scale}px`;

        let text = qty === 0
            ? '🛒 đơn <span style="color:red">méo</span> có hàng nha!'
            : `🛍️ có <span style="color:#d4380d;font-weight:800">${qty}</span> món\u200e \u200e \u200e \u200e `;

        let warned = false, payLabel = '';
        if      (payType === 'mixed') payLabel = '💰 + 💳 🢠 ba rọi 🢠 ';
        else if (payType === 'cash')  payLabel = '💰 TM 🢠';
        else if (payType === 'bank') {
            payLabel = '⇪ 💳 CK 🢠';
            const r = getLabelValue('tiền thừa trả khách');
            if (r !== null && r > 0) {
                Object.assign(box.style, { background: BOX_REF, border: '2px solid #d4b106', color: '#000', boxShadow: '0 4px 12px rgba(250,200,0,.4)' });
                text += ` ⚠️ <span style="color:#fff;font-weight:800">dư tiền rồi!</span>`;
                warned = true;
            }
        }
        if (payLabel) text = `<span style="color:#d4380d;font-weight:700">${payLabel}</span> ${text}`;

        if (!warned) {
            if (debt < 0) {
                Object.assign(box.style, { background: BOX_DEBT, border: '2px solid #a8071a', color: '#fff', boxShadow: '0 4px 12px rgba(255,0,0,.3)' });
                text += ` ⚠️ <span style="color:#fff;font-weight:800">thiếu tiền rồi!</span>`;
            } else {
                Object.assign(box.style, { background: BOX_DEF, border: '2px solid #1890ff', color: '#003a8c', boxShadow: '0 4px 10px rgba(0,0,0,.1)' });
            }
        }

        box.style.filter  = qty === 0 ? 'grayscale(100%) brightness(.8)' : 'none';
        box.style.opacity = qty === 0 ? '0.6' : String(BOPACITY);
        box.innerHTML = text.toLowerCase();

        const leftCol = qs('.col-left .cart-container');
        if (!leftCol?.offsetParent) return;
        const rc = leftCol.getBoundingClientRect();
        Object.assign(box.style, { width: 'auto', minWidth: '120px', whiteSpace: 'nowrap', display: 'inline-block', left: rc.left + 'px', bottom: (innerHeight - rc.bottom) + 'px' });

        let topText = '';
        if (qty > 0) {
            if (payType === 'bank') {
                const bs = qs('span[ng-show*="dataItem.Account"][ng-show*="dataItem.BankCode"]');
                if (bs?.offsetParent !== null && bs.textContent.trim()) topText = bs.textContent.trim();
            } else if (payType !== 'mixed') {
                const r = getLabelValue('tiền thừa trả khách');
                if (r !== null) topText = r >= 0 ? `\u200e \u200e thối lại 🢡 ${r.toLocaleString()}đ` : `\u3164\u3164cẩn thận ⚠️ tiền thối đang âm`;
            }
        }
        topLine.textContent = topText;
        topLine.style.left     = rc.left + 'px';
        topLine.style.bottom   = (innerHeight - rc.bottom + box.offsetHeight + 23) + 'px';
        topLine.style.width    = box.offsetWidth + 'px';
        topLine.style.opacity  = topText ? '1' : '0';
        topLine.style.transform = topText ? 'translateY(23px)' : 'translateY(50px)';
    }

    waitFor('.cart-footer').then(() => setTimeout(() => {
        if (boxCreated) return; boxCreated = true;
        updateBox();
        requestAnimationFrame(() => { box.style.opacity = String(BOPACITY); box.style.transform = 'translateY(0)'; });
    }, 1200));

    onStateChange(updateBox);
    window.addEventListener('resize', updateBox);

    /* Sync #saveTransaction button colours to monitor box (via onStateChange, no 60ms interval) */
    onDOMChange(() => {
        const btn = qs('#saveTransaction');
        if (!btn || btn.dataset.kvBound === '1') return;
        btn.dataset.kvBound = '1';
        onStateChange(() => {
            const s = box.style;
            Object.assign(btn.style, { background: s.background, color: s.color, border: s.border, boxShadow: s.boxShadow, filter: s.filter || 'none', opacity: s.opacity || '1' });
        });
    });

    /* Đặt hàng topline — how much change to prepare */
    const dlTop = document.createElement('div');
    Object.assign(dlTop.style, { position:'fixed', zIndex:9999, fontSize:'20px', fontWeight:'600', color:'#d4380d', background:'rgba(255,255,255,.9)', padding:'37px 109px', borderRadius:'4px', opacity:'0', transition:'opacity .5s ease', pointerEvents:'none', bottom:'31%', right:'.8%' });
    document.body.appendChild(dlTop);
    onStateChange(() => {
        if (!qs('#saveOrder') || state.payType !== 'cash') { dlTop.style.opacity = '0'; return; }
        const amt  = parseInt(qs('.amount-pay')?.textContent.replace(/[^\d]/g, '') || '0', 10);
        dlTop.textContent   = `tiền thối cần chuẩn bị = ${(Math.ceil(amt / 500000) * 500000 - amt).toLocaleString()}đ`;
        dlTop.style.opacity = '1';
    });

    /* Giant watermark number — observer on specific span, not whole body */
    waitFor('.cart-container').then(cart => {
        if (qs('#kv-giant-number')) return;
        if (getComputedStyle(cart).position === 'static') cart.style.position = 'relative';
        const giant = document.createElement('div');
        giant.id = 'kv-giant-number';
        Object.assign(giant.style, { position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)', fontSize:'370px', fontWeight:'900', color:'#000', opacity:'0.09', pointerEvents:'none', zIndex:'99998', fontFamily:`'Inter','Segoe UI',Arial,sans-serif`, userSelect:'none', textAlign:'center', whiteSpace:'nowrap', lineHeight:'1' });
        cart.appendChild(giant);
        const FA = { '0':'fa-0','1':'fa-1','2':'fa-2','3':'fa-3','4':'fa-4','5':'fa-5','6':'fa-6','7':'fa-7','8':'fa-8','9':'fa-9','.':'fa-circle' };
        function renderGiant() {
            const val = qs('span.text-bg-default')?.textContent.replace(/[^\d.]/g, '') || '0';
            giant.innerHTML = '';
            for (const c of val) {
                if (!FA[c]) continue;
                const i = document.createElement('i');
                i.className = `fa-solid ${FA[c]}`; i.style.display = 'inline-block';
                if (c === '.') Object.assign(i.style, { fontSize: '.15em', verticalAlign: 'bottom', position: 'relative', top: '-.15em', margin: '0 .15em' });
                else i.style.margin = '0 .1em';
                giant.appendChild(i);
            }
        }
        function hookGiantObs() {
            const span = qs('span.text-bg-default');
            if (span && !span._giantObs) {
                span._giantObs = true;
                new MutationObserver(renderGiant).observe(span, { childList: true, characterData: true, subtree: true });
                renderGiant();
            }
        }
        onDOMChange(hookGiantObs);
        hookGiantObs();
        window.addEventListener('resize', renderGiant);
    });

    /* After-sale swoosh + checkmark */
    (() => {
        const SWOOSH = 'https://github.com/tasuaongvang/cov/raw/refs/heads/main/swoosh.mp3';
        const FLAG   = 'data-kv-done';
        let last     = 0;
        const snd    = new Audio(SWOOSH); snd.load();

        function fire() {
            const now = Date.now(); if (now - last < 3000) return; last = now;
            try { snd.cloneNode().play().catch(() => {}); } catch(e) {}
            const c = qs('.cart-container') || document.body;
            if (getComputedStyle(c).position === 'static') c.style.position = 'relative';
            if (qs('#kv-done-icon')) return;
            const ic = document.createElement('i');
            ic.id = 'kv-done-icon'; ic.className = 'fas fa-check';
            Object.assign(ic.style, { position:'absolute', top:'50%', left:'17%', transform:'translate(-50%,-50%) scale(5.5)', fontSize:'190px', color:'#00c853', opacity:'0', zIndex:'99999', pointerEvents:'none', transition:'opacity .3s ease,transform .3s ease' });
            c.appendChild(ic);
            requestAnimationFrame(() => { ic.style.opacity = '1'; ic.style.transform = 'translate(-50%,-50%) scale(1)'; });
            setTimeout(() => { ic.style.opacity = '0'; ic.style.transform = 'translate(-50%,-50%) scale(.7)'; setTimeout(() => ic.remove(), 500); }, 1200);
        }

        const SUCCESS_KEYS = ['hoàn tất đơn', 'lưu thành công', 'thành công', 'hóa đơn được cập nhật thành công', 'tạo đơn thành công'];
        const isOK = t => SUCCESS_KEYS.some(k => t.toLowerCase().includes(k));
        function hideToast(el) {
            if (!el || el.getAttribute(FLAG) === '1') return;
            el.setAttribute(FLAG, '1');
            el.style.cssText += ';opacity:0;transition:opacity .3s ease';
            setTimeout(() => el.remove(), 300);
        }
        const TSEL = '.toast,.toast-message,.ant-notification,[role="alert"]';
        onDOMChange(muts => {
            for (const m of muts) for (const node of m.addedNodes) {
                if (!(node instanceof HTMLElement)) continue;
                if ((node.matches?.(TSEL) || node.closest?.(TSEL)) && isOK(node.textContent || '')) { hideToast(node); fire(); }
                node.querySelectorAll?.(TSEL).forEach(el => { if (!el.getAttribute(FLAG) && isOK(el.textContent || '')) { hideToast(el); fire(); } });
            }
        });
    })();
})(); // end S1


/* ════════════════════════════════════════════════════════
   S2 — PRICEBOOK SYNC + COMPACT UI + HOTKEYS + KẾT HỢP
════════════════════════════════════════════════════════ */
(function s2() {
    /* Inject compact payment styles once */
    document.head.insertAdjacentHTML('beforeend', `<style id="kov-pay-style">
    .form-group-row.form-check-methods span.text-check::before{display:none!important;content:none!important}
    .form-group-row.form-check-methods input.form-check-input{appearance:none!important;width:0!important;height:0!important;margin:0!important;position:absolute!important}
    .form-group-row.form-check-methods label.form-check,
    .form-group-row.form-check-methods label.form-check-inline{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:10px!important;padding:12px 18px!important;border-radius:8px!important;background:transparent!important;font-size:1.2rem!important;transform:scale(1.15)!important;transform-origin:center!important;font-weight:700!important;cursor:pointer!important;white-space:nowrap!important;margin-right:10px!important}
    .form-group-row.form-check-methods span.text-check span{text-transform:lowercase!important;color:#222!important;font-weight:700!important}
    .form-group-row.form-check-methods input[type="radio"]:checked+.text-check,
    .form-group-row.form-check-methods input[type="radio"]:checked~.text-check{background-color:#27ae60!important;color:#fff!important;padding:10px 16px!important;border-radius:8px!important;box-shadow:0 0 4px rgba(0,0,0,.2)!important}
    .form-group-row.form-check-methods input[type="radio"]:checked+.text-check span,
    .form-group-row.form-check-methods input[type="radio"]:checked~.text-check span{color:#fff!important}
    </style>`);

    /* Hide Thẻ/Ví labels; normalise label text — run debounced via root observer */
    const HIDE_WORDS = new Set(['Thẻ', 'Ví']);
    function cleanPayUI() {
        qsa('label.form-check,label.form-check-inline').forEach(lbl => {
            try {
                const txt   = (lbl.textContent || '').trim();
                const inp   = lbl.querySelector('input[type="radio"],input[type="checkbox"]');
                const extra = (inp?.getAttribute('ng-click') || '') + (inp?.getAttribute('value') || '');
                if (HIDE_WORDS.has(txt) || /Card|Wallet/i.test(extra))
                    Object.assign(lbl.style, { display:'none', visibility:'hidden', position:'absolute', width:'0', height:'0' });
            } catch(e) {}
        });
        qsa('.form-group-row.form-check-methods .text-check span').forEach(s => {
            const t = s.textContent.trim().toLowerCase();
            if (t === 'tiền mặt' || t === 'chuyển khoản') s.textContent = t;
        });
    }
    cleanPayUI();
    onDOMChange(debounce(cleanPayUI, 400));

    /* Pricebook ↔ Payment helpers */
    const PB_TO_PAY = { 'bảng giá chung': 'chuyển khoản', 'tiền mặt': 'tiền mặt' };
    const PAY_TO_PB = { 'tien mat': 'Tiền mặt', 'chuyen khoan': 'Bảng giá chung' };
    let pricebookPaused = false;

    function clickPayLabel(want) {
        want = normalize(want);
        for (const lbl of qsa('label.form-check,label.form-check-inline'))
            if (normalize(lbl.innerText || '').includes(want)) { try { lbl.click(); return true; } catch(e) {} }
        return false;
    }

    async function applyPBToPayment(pb) {
        if (!pb) return;
        const pbn = normalize(pb);
        for (const [key, pay] of Object.entries(PB_TO_PAY))
            if (pbn.includes(normalize(key))) { for (let i = 0; i < 10; i++) { if (clickPayLabel(pay)) return; await sleep(200); } }
    }

    async function selectPB(target) {
        const want = normPlain(target);
        for (let attempt = 0; attempt < 12; attempt++) {
            const sel    = qs('pricebook-component select#pricebook, select#pricebook');
            const kSpan  = qs('pricebook-component .k-dropdown-wrap .k-input span');
            if (sel?.options?.length) {
                try {
                    const jq  = window.kendo?.jQuery || window.jQuery || window.$;
                    const kdd = jq?.(sel)?.data?.('kendoDropDownList');
                    if (kdd) {
                        for (let i = 0; i < sel.options.length; i++) {
                            if (normPlain(sel.options[i].text || '').includes(want)) {
                                kdd.select(i); kdd.trigger('change');
                                if (kSpan) kSpan.innerText = sel.options[i].text;
                                return true;
                            }
                        }
                    }
                } catch(e) {}
                for (let i = 0; i < sel.options.length; i++) {
                    if (normPlain(sel.options[i].text || '').includes(want)) {
                        sel.selectedIndex = i;
                        sel.dispatchEvent(new Event('change', { bubbles: true }));
                        if (kSpan) kSpan.innerText = sel.options[i].text;
                        return true;
                    }
                }
            }
            await sleep(200);
        }
        return false;
    }

    async function waitPayChecked(text, ms = 1500) {
        const want = normalize(text), end = Date.now() + ms;
        while (Date.now() < end) {
            for (const r of qsa('.form-group-row.form-check-methods input[type="radio"]'))
                if (r.checked && normalize(r.closest('label')?.textContent || '').includes(want)) return true;
            await sleep(80);
        }
        return false;
    }

    async function switchPB(targetPB, tone) {
        const payTarget = targetPB === 'Bảng giá chung' ? 'chuyển khoản' : 'tiền mặt';
        await selectPB(targetPB);
        const end1 = Date.now() + 2000;
        while (Date.now() < end1) { if (normPlain(_readPricebook()).includes(normPlain(targetPB))) break; await sleep(100); }
        const end2 = Date.now() + 2000;
        while (Date.now() < end2) { clickPayLabel(payTarget); await sleep(120); if (await waitPayChecked(payTarget, 300)) break; }
        SND.url(tone === 'bank'
            ? 'https://github.com/tasuaongvang/cov/raw/refs/heads/main/bank.mp3'
            : 'https://github.com/tasuaongvang/cov/raw/refs/heads/main/cash.mp3');
    }

    function focusSearch(retries = 5) {
        const s = qs('#productSearchInput'); if (!s) return;
        const go = n => {
            try { document.activeElement?.blur(); s.focus({ preventScroll: true }); s.setSelectionRange(0, s.value.length); } catch(e) {}
            if (n > 0) setTimeout(() => go(n - 1), 80);
        };
        go(retries);
    }

    /* Replace while(true)/sleep(400) poller with state-change handler */
    let _lastPB = '', _pbSyncing = false;
    onStateChange(() => {
        if (pricebookPaused || !state.pricebook || state.pricebook === _lastPB || _pbSyncing) return;
        _lastPB = state.pricebook;
        _pbSyncing = true;
        applyPBToPayment(state.pricebook).finally(() => { _pbSyncing = false; });
    });

    /* Radio click → sync payment to pricebook */
    document.addEventListener('click', e => {
        const r = e.target.closest?.('input[type="radio"].form-check-input, input[type="radio"]');
        if (!r) return;
        setTimeout(async () => {
            const plain = normPlain(r.closest('label')?.querySelector('.text-check span')?.innerText || r.parentElement?.textContent || '');
            for (const [pk, pb] of Object.entries(PAY_TO_PB))
                if (plain.includes(pk)) { await selectPB(pb); return; }
        }, 40);
    }, true);

    /* Ctrl+= / Ctrl+- → switch pricebook */
    let _switching = false;
    window.addEventListener('keydown', async e => {
        if (!e.ctrlKey || !['=', '+', '-'].includes(e.key)) return;
        e.preventDefault(); e.stopPropagation();
        if (_switching) return; _switching = true;
        try {
            if (e.key !== '-') await switchPB('Bảng giá chung', 'bank');
            else                await switchPB('Tiền mặt', 'cash');
        } finally { focusSearch(); _switching = false; }
    }, true);

    /* Kết hợp (mixed payment) button */
    const insertKH = debounce(async () => {
        const parent = qs('.form-group-row.form-check-methods');
        if (!parent || qs('#btn-kethop')) return;
        const lbls    = [...qsa('label.form-check,label.form-check-inline')];
        const cashLbl = lbls.find(l => l.textContent.toLowerCase().includes('tiền mặt'));
        const bankLbl = lbls.find(l => l.textContent.toLowerCase().includes('chuyển khoản'));
        if (!cashLbl || !bankLbl) return;
        const kh = cashLbl.cloneNode(true);
        kh.id = 'btn-kethop';
        kh.querySelector('span').textContent = 'hỗn hợp';
        kh.querySelector('input')?.remove();
        kh.addEventListener('click', e => {
            e.preventDefault(); e.stopPropagation();
            pricebookPaused = true;
            qs('.btn-multi-methods')?.click();
            kh.style.cssText += ';background-color:#27ae60;color:#fff';
            const obs = new MutationObserver((_, o) => {
                if (!qs('.k-widget.k-window.payment-invoice')) {
                    pricebookPaused = false;
                    kh.style.backgroundColor = ''; kh.style.color = '';
                    o.disconnect();
                }
            });
            obs.observe(document.body, { childList: true, subtree: true });
        });
        bankLbl.after(kh);
        if (window.angular) {
            try { angular.element(document.body).injector().get('$compile')(kh)(angular.element(kh).scope()); } catch(e) {}
        }
    }, 300);
    onDOMChange(insertKH);

    /* Auto-fix payment when first item added to empty cart */
    let _lastCC = 0;
    onDOMChange(debounce(() => {
        const n = qsa('#cartListProduct .carts.active.cart-materials').length;
        if (_lastCC === 0 && n > 0) {
            applyPBToPayment(state.pricebook);
            setTimeout(() => qs('#productSearchInput')?.focus(), 50);
        }
        _lastCC = n;
    }, 300));

    /* Move multi-payment ellipsis into top bar */
    onDOMChange(debounce(() => {
        const icon = qs('button.btn-multi-methods i.far.fa-ellipsis-v');
        if (!icon) return;
        const wrap = icon.closest('div');
        if (!wrap || wrap.__moved) return;
        const li = qs('#printConfig')?.closest('li.icon-item');
        if (!li) return;
        const newLi = document.createElement('li');
        newLi.className = 'icon-item'; newLi.appendChild(wrap);
        li.after(newLi); wrap.__moved = true;
    }, 300));

    /* Watch Tổng tiền hàng span: 0 → switch to bank pricebook */
    let _lastTotal = null, _totalSpan = null;
    onDOMChange(debounce(() => {
        const span = qs("span.text-bg-default[ng-show*='UseTotalQuantity']");
        if (!span) return;
        if (span !== _totalSpan) {
            _totalSpan = span; _lastTotal = span.textContent.trim();
            new MutationObserver(() => {
                const cur = span.textContent.trim();
                if (cur !== _lastTotal) { _lastTotal = cur; if (cur === '0') switchPB('Bảng giá chung', 'bank').then(focusSearch); }
            }).observe(span, { childList: true, characterData: true, subtree: true });
        }
    }, 300));
})(); // end S2


/* ════════════════════════════════════════════════════════
   S3 — MONEY HOTKEYS + F2 + DISABLE F6/F11/TAB
════════════════════════════════════════════════════════ */
(function s3() {
    let tabHeld = false, rCtrl = false;
    document.addEventListener('keydown', e => { if (e.code === 'ControlRight') rCtrl = true;  }, true);
    document.addEventListener('keyup',   e => { if (e.code === 'ControlRight') rCtrl = false; }, true);

    function isCash() {
        for (const r of qsa('input[type="radio"]')) {
            const ng = r.getAttribute('ng-model') || '';
            if (/singlePaymentType/.test(ng) && r.checked)
                return Number(r.value) === 0 || Number(r.getAttribute('ng-value')) === 0;
        }
        const cr = qs('input[type=radio][value="0"],input[type=radio][ng-value="0"]');
        if (cr) return cr.checked;
        try { const t = window.angular?.element(document.body)?.scope?.()?.$root?.activeCart?.singlePaymentType; if (t !== undefined) return t === 0; } catch(e) {}
        return true;
    }

    function applyAmount(amount) {
        const inp = qs('#payingAmtInvoice'); if (!inp) return;
        window._gmnHotkeyActive = true;
        clearTimeout(window._gmnHotkeyTimer);
        window._gmnHotkeyTimer = setTimeout(() => { window._gmnHotkeyActive = false; }, 3000);
        nativeSetter.call(inp, String(Math.round(amount)));
        inp.dispatchEvent(new Event('input',  { bubbles: true }));
        inp.dispatchEvent(new Event('change', { bubbles: true }));
        nativeSetter.call(inp, Math.round(amount).toLocaleString('en-US'));
        const prev = inp.style.boxShadow;
        inp.style.boxShadow = '0 0 0 3px rgba(46,204,113,.55)';
        setTimeout(() => { inp.style.boxShadow = prev; }, 350);
        setTimeout(() => { const f = qs('#productSearchInput'); if (f) { f.focus(); f.select(); } }, 300);
    }

    /* Ctrl+Numpad (Left Ctrl = 100k–1M, Right Ctrl = 1.1M–2M) */
    document.addEventListener('keydown', e => {
        if (!e.ctrlKey || !isCash()) return;
        const m = /^Numpad([0-9])$/.exec(e.code || '');
        const n = m ? Number(m[1]) : (e.location === 3 && /^[0-9]$/.test(e.key)) ? Number(e.key) : null;
        if (n === null) return;
        e.preventDefault(); e.stopImmediatePropagation();
        applyAmount(rCtrl ? (n === 0 ? 2_000_000 : 1_000_000 + n * 100_000) : (n === 0 ? 1_000_000 : n * 100_000));
    }, true);

    /* Tab+digit = 10k–90k (Tab+0 = 0) */
    document.addEventListener('keydown', e => {
        if (e.key === 'Tab') { e.preventDefault(); e.stopImmediatePropagation(); tabHeld = true; return; }
        if (tabHeld && /^[0-9]$/.test(e.key) && isCash()) {
            e.preventDefault(); e.stopImmediatePropagation();
            applyAmount(Number(e.key) === 0 ? 0 : Number(e.key) * 10_000);
        }
    }, true);
    document.addEventListener('keyup', e => { if (e.key === 'Tab') tabHeld = false; }, true);

    /* F2 / F6 / F11 */
    document.addEventListener('keydown', e => {
        if      (e.key === 'F2')  { e.preventDefault(); e.stopImmediatePropagation(); qs('button.btn-change-type')?.click(); }
        else if (e.key === 'F6' || e.key === 'F11') { e.preventDefault(); e.stopImmediatePropagation(); }
    }, true);
})(); // end S3


/* ════════════════════════════════════════════════════════
   S4 — CART FOOTER + BANK QR + PAGE FOOTER + F12 + SPINNER
════════════════════════════════════════════════════════ */
(function s4() {
    /* Move cart-footer into .col-right */
    function moveFooter() {
        const footer = qs('.cart-footer'), right = qs('.col-right');
        if (!footer || !right) return;
        if (footer.parentNode !== right) right.appendChild(footer);
        footer.style.setProperty('padding',    '5% 0 2% 0', 'important');
        footer.style.setProperty('margin',     '0',          'important');
        footer.style.setProperty('width',      '100%',       'important');
        footer.style.setProperty('box-sizing', 'border-box', 'important');
        qsa('textarea', footer).forEach(ta => {
            ta.style.setProperty('background-color', '#fff5b8',       'important');
            ta.style.setProperty('border-radius',    '11px',          'important');
            ta.style.setProperty('border',           '0px solid #ccc','important');
            ta.style.setProperty('padding',          '6px 8px',       'important');
            ta.style.setProperty('box-sizing',       'border-box',    'important');
            ta.style.setProperty('width',            '100%',          'important');
            ta.style.setProperty('height',           '120px',         'important');
            ta.style.setProperty('font-size',        '16px',          'important');
            ta.style.setProperty('line-height',      '1.4',           'important');
            ta.style.setProperty('resize',           'none',          'important');
        });
    }
    onDOMChange(debounce(moveFooter, 200));

    /* Remove bank QR image for Chuyển khoản */
    function removeQR() {
        const chk = qs('.form-check-methods input.form-check-input:checked');
        if (!chk) return;
        if (normalize(chk.closest('label')?.querySelector('.text-check span')?.textContent || '') === 'chuyển khoản')
            qsa('.payment-method-left').forEach(d => d.remove());
    }
    onDOMChange(debounce(removeQR, 150));

    /* Remove KiotViet page footer */
    function nukeFooter() { qs('footer-component.page-footer')?.remove(); }
    onDOMChange(nukeFooter);
    setTimeout(nukeFooter, 2000);

    /* F12 → focus note textarea; also style it */
    const NOTE_SEL = 'textarea[ng-model="$root.activeCart.Description"],textarea[placeholder*="Ghi chú đơn hàng"]';
    function applyNote() {
        const n = qs(NOTE_SEL); if (!n) return;
        let ph = n.getAttribute('placeholder') || '';
        if (!ph.includes('(F12)')) n.setAttribute('placeholder', ph.trim() + ' (F12)');
        n.setAttribute('rows', '1');
        Object.assign(n.style, { resize:'none', overflow:'hidden', whiteSpace:'nowrap', textOverflow:'ellipsis', height:'40px' });
        if (!n._f12) {
            n._f12 = true;
            n.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); n.blur(); } }, { passive: false });
        }
    }
    document.addEventListener('keydown', e => {
        if (e.key !== 'F12') return; e.preventDefault();
        const n = qs(NOTE_SEL); if (n) { n.focus(); n.select(); }
    });
    applyNote();
    onDOMChange(debounce(applyNote, 300));

    /* Replace spinner with transparent pixel; remove when cart ready */
    qs('#loading-bar-spinner')?.remove();
    const spin = Object.assign(document.createElement('img'), { src: 'https://upload.wikimedia.org/wikipedia/commons/c/ca/1x1.png' });
    Object.assign(spin.style, { position:'fixed', top:'50%', left:'50%', transform:'translate(-50%,-50%)', width:'50px', height:'50px', zIndex:'9999', pointerEvents:'none' });
    document.body.appendChild(spin);
    waitFor('.cart-footer').then(() => setTimeout(() => spin.remove(), 1000));
})(); // end S4


/* ════════════════════════════════════════════════════════
   S5 — F9 GUARD + BANK DROPDOWN RESET
════════════════════════════════════════════════════════ */
(function s5() {
    const BTN_IDS = ['saveTransaction', 'saveOrder'];
    let beeping   = false;

    document.head.insertAdjacentHTML('beforeend', `<style>
        .kv-shake{animation:kvShk .28s ease-in-out}
        @keyframes kvShk{0%{transform:translateX(0)}25%{transform:translateX(-4px)}50%{transform:translateX(4px)}75%{transform:translateX(-2px)}100%{transform:translateX(0)}}
        #saveTransaction,#saveOrder{transition:opacity .25s ease}
    </style>`);

    function shake() {
        if (beeping) return; beeping = true;
        BTN_IDS.forEach(id => { const b = qs('#' + id); if (!b) return; b.classList.add('kv-shake'); setTimeout(() => b.classList.remove('kv-shake'), 280); });
        SND.beep();
        setTimeout(() => { beeping = false; }, 300);
    }

    /* Update buttons via shared state — replaces 500ms interval + duplicate body observer */
    onStateChange(() => {
        BTN_IDS.forEach(id => {
            const b = qs('#' + id); if (!b) return;
            b.disabled      = state.isDisabled;
            b.style.opacity = state.isDisabled ? '0.5' : '1';
            b.style.cursor  = state.isDisabled ? 'not-allowed' : '';
            b.title = state.isDisabled
                ? (state.isPBMismatch ? 'Sai bảng giá ↔ sai phương thức thanh toán' : 'Chọn tài khoản trước khi thanh toán/đặt hàng')
                : '';
        });
    });

    document.addEventListener('click', e => {
        if (state.isDisabled && BTN_IDS.some(id => e.target.closest('#' + id))) { e.preventDefault(); shake(); }
    });
    window.addEventListener('keydown', e => {
        if (e.key === 'F9' && state.isDisabled) { e.preventDefault(); e.stopPropagation(); shake(); }
    }, true);

    /* Single beep interval while disabled — replaces 2 duplicate setIntervals */
    setInterval(() => { if (state.isDisabled) shake(); }, 1000);

    /* Reset Kendo bank dropdown to first real bank */
    function resetBank() {
        const el = qs('#bankAccountDropdown');
        if (!el || typeof $ === 'undefined') return;
        const kdd = $(el).data('kendoDropDownList'); if (!kdd) return;
        const first = kdd.dataSource.at(1); if (!first) return;
        try {
            kdd.select(1); kdd.value(first.Id);
            if (typeof kdd.trigger === 'function') kdd.trigger('change');
            el.dispatchEvent(new Event('change', { bubbles: true }));
            if (typeof $ === 'function') $(el).trigger('change');
        } catch(e) {}
    }
    onDOMChange(muts => {
        for (const m of muts) for (const node of m.addedNodes)
            if (node.nodeType === 1 && node.querySelector?.('#bankAccountDropdown')) setTimeout(resetBank, 120);
    });
    setTimeout(resetBank, 700);
})(); // end S5


/* ════════════════════════════════════════════════════════
   S6 — SCANNER WARNING + QUICK PRINT + MOUSE DISABLE
════════════════════════════════════════════════════════ */
(function s6() {
    const SCAN_DELAY  = 30;
    const FOCUS_MS    = 1000;
    const PRINT_COOL  = 3000;
    const SND_ERR     = 'https://github.com/tasuaongvang/kov-count/raw/refs/heads/main/missed.mp3';
    const SND_TOAST   = 'https://github.com/tasuaongvang/kov-count/raw/refs/heads/main/mncc.mp3';
    let printing = false, lastPrint = 0;

    function getSearch() { return qs('#productSearchInput') || qs("input[placeholder*='F3'],input[placeholder*='F7']"); }

    function mkBox(id, bg, blur, txt) {
        const d = document.createElement('div');
        d.id = id;
        Object.assign(d.style, { position:'fixed', padding:'0', background:bg, color:'#000', fontSize:'20px', borderRadius:'6px', boxShadow:'0 2px 6px rgba(0,0,0,.2)', zIndex:'99999', opacity:'1', transition:'opacity .5s ease', textAlign:'right', pointerEvents:'none', backdropFilter:`blur(${blur}px)`, WebkitBackdropFilter:`blur(${blur}px)` });
        d.textContent = txt;
        document.body.appendChild(d);
        return d;
    }
    function placeBox(d) {
        const inp = getSearch(); if (!inp) return;
        const r = inp.getBoundingClientRect();
        Object.assign(d.style, { top:`${r.top+scrollY}px`, left:`${r.left+scrollX}px`, width:`${r.width}px`, height:`${r.height}px`, lineHeight:`${r.height}px` });
    }

    const warnBox = mkBox('scanner-warning', 'rgba(255,77,79,.25)',  2, 'mã chưa vào ⚠️\u3164\u3164\u3164\u3164\u3164');
    const succBox = mkBox('scanner-success', 'rgba(82,196,26,.35)',  4, 'vào rồi ✔️\u3164\u3164\u3164\u3164\u3164');
    placeBox(warnBox); placeBox(succBox);

    let warnOn = false, awaitSucc = false, succTimer;

    function showWarn() { placeBox(warnBox); warnBox.style.opacity='1'; warnBox.style.pointerEvents='auto'; warnOn=true; awaitSucc=true; SND.url(SND_ERR); const s=getSearch(); if(s){s.focus();s.select();} }
    function hideWarn() { warnBox.style.opacity='0'; warnBox.style.pointerEvents='none'; warnOn=false; }
    function showSucc() { placeBox(succBox); succBox.style.opacity='1'; succBox.style.pointerEvents='auto'; clearTimeout(succTimer); succTimer=setTimeout(()=>{succBox.style.opacity='0';succBox.style.pointerEvents='none';},1800); }

    document.addEventListener('keydown',   () => { if (warnOn) hideWarn(); });
    document.addEventListener('mousedown', () => { if (warnOn) hideWarn(); });

    /* Custom toast for "không tìm thấy sản phẩm" — via root observer */
    onDOMChange(muts => {
        for (const m of muts) for (const node of m.addedNodes) {
            if (node.nodeType !== 1 || node.id !== 'toast-container') continue;
            const msg = node.querySelector('.toast-message');
            if (!msg?.textContent.includes('Không tìm thấy sản phẩm')) continue;
            qs('#custom-toast')?.remove();
            const toast = mkBox('custom-toast', 'rgba(255,0,0,.4)', 3, 'hông có mã này bé ơi 😂\u3164\u3164\u3164\u3164\u3164');
            placeBox(toast); SND.url(SND_TOAST);
            const inp = getSearch();
            if (inp) {
                const hide = () => { toast.style.opacity='0'; inp.removeEventListener('keydown',hide); inp.removeEventListener('input',hide); };
                inp.addEventListener('keydown',hide); inp.addEventListener('input',hide);
            }
            node.remove();
        }
    });

    /* Main scanner/manual detection */
    let buf = '', bufStart = 0, lastKey = 0;
    document.addEventListener('keydown', e => {
        if (!e.isTrusted || printing) return;
        const now = Date.now();
        if (e.key && e.key.length === 1) {
            if (now - lastKey > SCAN_DELAY || !buf) { buf = e.key; bufStart = now; }
            else buf += e.key;
            lastKey = now; return;
        }
        if (e.key === 'Enter') {
            if (!buf) { lastKey = now; return; }
            const avg       = (now - bufStart) / Math.max(1, buf.length);
            const isScanner = buf.length >= 4 && avg < SCAN_DELAY && /^[\x20-\x7E]+$/.test(buf);
            const active    = document.activeElement;
            const isSearch  = active && (active.placeholder?.includes('F3') || active.placeholder?.includes('F7') || active.className.includes('search') || active.className.includes('k-input'));

            if (!isScanner) {
                const s = getSearch(); if (s) { s.focus(); s.select(); }
                buf = ''; lastKey = now; return;
            }

            const isInput = active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA') && active.type !== 'button';
            if (!isInput || !isSearch) { showWarn(); }
            else if (isSearch && awaitSucc) { hideWarn(); showSucc(); awaitSucc = false; }

            const s = getSearch();
            if (s) {
                s.focus(); s.select();
                /* Focus guard: chained timeouts instead of setInterval */
                let n = 0;
                const tick = () => { if (n++ >= 10) return; if (document.activeElement !== s) { s.focus(); s.select(); } setTimeout(tick, 100); };
                tick();
            }
            buf = ''; lastKey = now; return;
        }
        buf = ''; lastKey = now;
    });

    /* Ctrl+` quick print */
    document.addEventListener('keydown', e => {
        if (!e.ctrlKey || e.key !== '`') return; e.preventDefault();
        const now = Date.now(); if (now - lastPrint < PRINT_COOL) return;
        lastPrint = now; printing = true;
        qs('#printTransaction,#printOrder')?.click();
        setTimeout(() => { printing = false; }, PRINT_COOL);
    });

    /* Block Ctrl+P */
    window.addEventListener('keydown', e => {
        if (e.ctrlKey && (e.key === 'p' || e.key === 'P')) { e.preventDefault(); e.stopPropagation(); }
    }, true);

    /* Hide cursor while typing in search box */
    (() => {
        let blocked = false, autoT;
        function block() {
            if (blocked) return; blocked = true;
            document.body.style.cursor = 'none';
            const bl = Object.assign(document.createElement('div'), { id: 'mouseBlocker' });
            Object.assign(bl.style, { position:'fixed', inset:'0', zIndex:'999999', background:'transparent', cursor:'none' });
            document.body.appendChild(bl);
            window.addEventListener('mousemove', unblock, { once: true });
            clearTimeout(autoT); autoT = setTimeout(unblock, 15000);
        }
        function unblock() { qs('#mouseBlocker')?.remove(); document.body.style.cursor = ''; blocked = false; clearTimeout(autoT); }
        function attach() {
            const inp = getSearch(); if (!inp || inp._mouseBlock) return;
            inp._mouseBlock = true;
            inp.addEventListener('keydown', e => {
                if (document.activeElement !== inp || e.key.length !== 1 || e.ctrlKey || e.altKey || e.metaKey) return;
                block();
            });
        }
        attach();
        waitFor('#productSearchInput').then(attach).catch(() => {});
    })();
})(); // end S6


/* ════════════════════════════════════════════════════════
   S7 — LUNAR DATE PLACEHOLDER
════════════════════════════════════════════════════════ */
(function s7() {
    const lunarFmt   = new Intl.DateTimeFormat('vi-VN-u-ca-chinese', { day: 'numeric', month: 'numeric', timeZone: 'Asia/Ho_Chi_Minh' });
    const weekdayFmt = new Intl.DateTimeFormat('vi-VN', { weekday: 'long', timeZone: 'Asia/Ho_Chi_Minh' });

    function updatePlaceholder() {
        const inp = qs('#productSearchInput'); if (!inp) return;
        const parts = lunarFmt.formatToParts(new Date());
        let day = '', month = '';
        for (const p of parts) { if (p.type === 'day') day = p.value; if (p.type === 'month') month = p.value; }
        let wd = weekdayFmt.format(new Date());
        if (wd.toLowerCase() === 'chủ nhật') wd = 'Thứ Tám';
        const dt = day === '15' ? 'Rằm' : day;
        const mt = month === '1' ? 'Giêng' : month === '12' ? 'Chạp' : month;
        inp.placeholder = `nay ${wd} (âm ${dt} tháng ${mt}) - F3 tìm hàng hóa`;
    }

    /* Only update when the input element appears (debounced), plus the 60s tick */
    onDOMChange(debounce(() => { if (qs('#productSearchInput')) updatePlaceholder(); }, 500));
    setInterval(updatePlaceholder, 60000);
    updatePlaceholder();
})(); // end S7


/* ════════════════════════════════════════════════════════
   S8 — CART SOUNDS + SPEAKER BUTTON
════════════════════════════════════════════════════════ */
(function s8() {
    /* Speaker toggle button via waitFor — no recursive setTimeout retry */
    waitFor('a.sale-mode').then(target => {
        const btn  = document.createElement('a');
        btn.className = 'btn-icon-lg sale-mode enable';
        btn.title     = 'Thử bật lại âm thanh (click để test)';
        btn.style.cursor = 'pointer';
        const icon = document.createElement('i');
        icon.className = 'fal fa-volume-mute'; icon.style.color = 'red';
        btn.appendChild(icon); target.replaceWith(btn);

        function updateIcon() {
            if (!_ctx)                    { icon.className = 'fal fa-volume-mute';  icon.style.color = 'red'; }
            else if (_ctx.state === 'running')   { icon.className = 'fal fa-volume-up';    icon.style.color = 'rgb(46,204,113)'; }
            else if (_ctx.state === 'suspended') { icon.className = 'fal fa-volume-slash'; icon.style.color = 'orange'; }
            else                                 { icon.className = 'fal fa-volume-mute';  icon.style.color = 'red'; }
        }
        onAudioStateChange(updateIcon);
        btn.addEventListener('click', () => { getCtx(); SND.itemChime(); setTimeout(updateIcon, 100); });
        document.addEventListener('keydown', updateIcon, { once: true });
    });

    /* Per-element chime observers on cart totals — each watches its own span, not body */
    function attachChime(el) {
        if (el._chimeOn) return; el._chimeOn = true;
        let last = parseFloat(el.textContent.trim()) || 0;
        new MutationObserver(() => {
            const v = parseFloat(el.textContent.trim());
            if (isNaN(v) || v === last) return;
            const pb = normalize(qs('pricebook-component .k-dropdown-wrap .k-input span')?.textContent || '');
            if (pb.includes('tiền mặt')) SND.cashChime(); else SND.itemChime();
            const frac = +(v - Math.floor(v)).toFixed(2);
            if (frac) setTimeout(() => SND.fraction(frac), 150);
            last = v;
        }).observe(el, { childList: true, subtree: true, characterData: true });
    }

    function hookCartSpans() {
        qsa('span.fbpos-total-quantity,span.text-bg-default').forEach(attachChime);
    }
    hookCartSpans();
    onDOMChange(muts => {
        for (const m of muts) for (const node of m.addedNodes) {
            if (!(node instanceof HTMLElement)) continue;
            if (node.matches?.('span.fbpos-total-quantity,span.text-bg-default')) attachChime(node);
            node.querySelectorAll?.('span.fbpos-total-quantity,span.text-bg-default').forEach(attachChime);
        }
    });

    /* Welcome chime once cart is ready */
    waitFor('.cart-footer').then(() => SND.welcomeOnce());

    /* Switch ding on payment-type / tab click */
    document.addEventListener('click', ev => {
        const el = ev.target instanceof Element ? ev.target : null; if (!el) return;
        if (el.closest?.('.btn-change-type') || el.closest?.('a.nav-link,li.nav-item'))
            { SND.switchDing(); setTimeout(() => SND.welcomeOnce(), 80); }
    }, true);
})(); // end S8


/* ════════════════════════════════════════════════════════
   S9 — DOUBLE-CTRL CART ANNOUNCER  (own AudioContext for buffers)
════════════════════════════════════════════════════════ */
(function s9() {
    const BASE  = 'https://raw.githubusercontent.com/tasuaongvang/kov/main';
    const FMAP  = { 0.25: 'point25.mp3', 0.5: 'point5.mp3',  0.75: 'point75.mp3' };
    const SFMAP = { 0.25: '0.25.mp3',    0.5: '0.5.mp3',     0.75: '0.75.mp3'    };
    const ctx9  = new (window.AudioContext || window.webkitAudioContext)();
    const cache = new Map();

    window.addEventListener('keydown', () => { if (ctx9.state === 'suspended') ctx9.resume(); }, { once: true });

    async function load(name) {
        if (cache.has(name)) return cache.get(name);
        try {
            const buf = await ctx9.decodeAudioData(await (await fetch(`${BASE}/${name}?raw=1`)).arrayBuffer());
            cache.set(name, buf); return buf;
        } catch(e) { return null; }
    }
    async function play9(name) {
        const b = await load(name); if (!b) return;
        return new Promise(res => { const s = ctx9.createBufferSource(); s.buffer = b; s.connect(ctx9.destination); s.start(); s.onended = res; });
    }

    async function announce() {
        const el = qs('div.col-form-wrap.d-flex span.text-bg-default');
        const t  = parseFloat(el?.textContent.replace(',', '.'));
        if (!el || isNaN(t) || t === 0) { await play9('zero.mp3'); return; }
        const i = Math.floor(t), f = +(t - i).toFixed(2);
        await play9('total.mp3');
        if (i > 0)  await play9(`${i}.mp3`);
        if (i >= 1 && FMAP[f])  await play9(FMAP[f]);
        if (i === 0 && SFMAP[f]) await play9(SFMAP[f]);
    }

    /* Double-Ctrl detector */
    setTimeout(() => {
        let c = 0, last = 0;
        window.addEventListener('keyup', e => {
            if (e.key !== 'Control') return;
            const now = Date.now();
            if (c === 0)               { c = 1; last = now; }
            else if (now - last <= 300) { c = 0; announce(); }
            else                        { c = 1; last = now; }
            if (c === 1 && now - last > 300) { c = 0; }
        }, true);
    }, 800);
})(); // end S9


/* ════════════════════════════════════════════════════════
   S10 — PAGEUP/PAGEDOWN/END  ROUNDING
════════════════════════════════════════════════════════ */
(function s10() {
    let tPU = 0, tPD = 0, tEnd = 0;

    /* Chained timeouts instead of setInterval for focus recovery */
    function refocusSearch() {
        const s = qs('#productSearchInput'); if (!s) return;
        let n = 0;
        const tick = () => {
            if (n++ >= 8) return;
            if (document.activeElement !== s)
                document.dispatchEvent(new KeyboardEvent('keydown', { key:'F3', code:'F3', keyCode:114, bubbles:true }));
            setTimeout(tick, 120);
        };
        tick();
    }

    function getCartTotal() {
        const el = qs('.payment-content .form-group-price .col-form-wrap.text-right');
        return el ? parseInt(el.innerText.replace(/[^0-9]/g, ''), 10) || 0 : 0;
    }

    function findDiscBtn() {
        for (const lbl of qsa('label.col-form-label'))
            if (lbl.textContent.trim() === 'Giảm giá') { const b = lbl.closest('.form-group-inline')?.querySelector('button.form-discount'); if (b) return b; }
        return null;
    }

    /* Double PageUp → làm tròn tiền via surcharge */
    async function roundUp() {
        const surBtn = qs('#btnSurcharge');
        if (!surBtn) return;
        surBtn.click();
        surBtn.dispatchEvent(new KeyboardEvent('keydown', { key:'Enter', keyCode:13, bubbles:true }));
        await sleep(380);
        const win = qs('.surcharge-window'); if (!win) return;
        const row = [...qsa('tbody tr', win)].find(r => r.innerText.includes('làm tròn tiền')); if (!row) return;
        const cb = row.querySelector('input[type="checkbox"]'); if (cb && !cb.checked) cb.click();
        const btn = row.querySelector('button[id^="surchargeItem_"]'); if (!btn) return;
        btn.click();
        await sleep(150);
        const inp = qs('.popover-surcharge input.form-control'); if (!inp) return;
        const diff = (() => { const r = getCartTotal() % 1000; return r === 0 ? 0 : 1000 - r; })();
        if (diff <= 0) { win.querySelector('.k-window-action')?.click(); refocusSearch(); SND.ping(); return; }
        inp.focus(); inp.value = String(diff);
        inp.dispatchEvent(new Event('input', { bubbles: true }));
        await sleep(120);
        inp.dispatchEvent(new KeyboardEvent('keydown', { key:'Enter', keyCode:13, bubbles:true }));
        await sleep(130); win.querySelector('.k-window-action')?.click();
        await sleep(150); refocusSearch(); SND.ping();
    }

    /* Double PageDown → trim last comma group via discount */
    async function trimDiscount() {
        const el = qs('.form-group-price .col-form-wrap.text-right'); if (!el) return;
        const parts = el.textContent.replace(/[^\d,]/g, '').split(','); if (parts.length < 2) return;
        const remove = parseInt(parts[parts.length - 1], 10); if (!remove || remove >= 1000) return;
        const btn = findDiscBtn(); if (!btn) return;
        btn.click();
        await sleep(240);
        const inp = qs('#priceInput'); if (!inp) return;
        inp.focus(); inp.value = String(remove);
        inp.dispatchEvent(new Event('input',  { bubbles: true }));
        inp.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(120);
        inp.dispatchEvent(new KeyboardEvent('keydown', { key:'Enter', keyCode:13, bubbles:true }));
        await sleep(120); document.body.click(); qs('.popover-discount')?.style.setProperty('display','none');
        await sleep(120); refocusSearch(); SND.ping();
    }

    /* Double End → clear discount + uncheck làm tròn tiền */
    async function clearAll() {
        const discBtn = findDiscBtn(); if (!discBtn) return;
        discBtn.click();
        // Wait for #priceInput to appear
        const inp = await waitFor('#priceInput', 3000).catch(() => null); if (!inp) return;
        inp.focus(); inp.value = '0';
        inp.dispatchEvent(new Event('input',  { bubbles: true }));
        inp.dispatchEvent(new Event('change', { bubbles: true }));
        inp.dispatchEvent(new KeyboardEvent('keydown', { key:'Enter', keyCode:13, bubbles:true }));
        // Open surcharge widget
        const surBtn = qs('#btnSurcharge');
        if (!surBtn?.offsetParent) { refocusSearch(); SND.ping(); return; }
        surBtn.click();
        surBtn.dispatchEvent(new KeyboardEvent('keydown', { key:'Enter', keyCode:13, bubbles:true }));
        await sleep(300);
        const win = qs('.surcharge-window'); if (!win) { refocusSearch(); SND.ping(); return; }
        const row = [...qsa('tbody tr', win)].find(r => r.innerText.includes('làm tròn tiền'));
        const cb  = row?.querySelector('input[type="checkbox"]');
        if (cb?.checked) cb.click();
        win.querySelector('.k-window-action')?.click();
        refocusSearch(); SND.ping();
    }

    document.addEventListener('keydown', e => {
        const now = Date.now();
        if (e.key === 'PageUp')   { if (now - tPU  < 350) roundUp().catch(()=>{});    tPU  = now; }
        if (e.key === 'PageDown') { if (now - tPD  < 350) trimDiscount().catch(()=>{}); tPD  = now; }
        if (e.key === 'End')      { if (now - tEnd < 350) clearAll().catch(()=>{});     tEnd = now; }
    });
})(); // end S10


/* ════════════════════════════════════════════════════════
   S11 — CART QUANTITY HOTKEYS
════════════════════════════════════════════════════════ */
(function s11() {
    let lastDel = 0;
    const DEL_DELAY = 400;
    const BL_UNITS  = new Set(['lon','set','bịch','cái','cây','hộp','gói','hũ','túi','que','thanh']);
    const BIG_UNITS = ['thùng','hộp','gói','dây','box','set'];

    const kdd = el => (el && typeof $ !== 'undefined') ? $(el).data('kendoDropDownList') || null : null;

    function removeOne() { qs('.carts-item .cell-actions button[title="Xóa hàng hóa"]')?.click(); }
    function removeAll() { qsa('.carts-item .cell-actions button[title="Xóa hàng hóa"]').forEach(b => b.click()); }
    function focusS()   { setTimeout(() => qs('#productSearchInput')?.focus(), 30); }

    function switchBigUnit() {
        const dd = kdd(qs('#unit')); if (!dd) return;
        const cur  = dd.text().trim().toLowerCase();
        const SMALL = new Set(['bịch','lốc','túi','thanh','cái']);
        if (!SMALL.has(cur)) return;
        const data = dd.dataSource.data();
        const tgt  = BIG_UNITS.map(u => data.find(o => o.Unit.toLowerCase() === u)).find(Boolean);
        if (tgt) { dd.value(tgt.Id); dd.trigger('change'); }
    }

    function setHalfQty() {
        const inp = qs('#note-cartitem-0'); if (!inp || inp.disabled) return;
        const dd  = kdd(qs('#unit')); if (!dd) return;
        let cur = dd.text().trim(), fill = false;
        if (cur === 'thùng' || cur === 'dây') { fill = true; }
        else {
            const data = dd.dataSource.data();
            const tgt  = data.find(o => o.Unit === 'thùng') || data.find(o => o.Unit === 'dây');
            if (tgt)                              { dd.value(tgt.Id); dd.trigger('change'); fill = true; }
            else if (!BL_UNITS.has(cur.toLowerCase())) fill = true;
            else return;
        }
        if (!fill) return;
        const kn = (typeof $ !== 'undefined') ? $(inp).data('kendoNumericTextBox') : null;
        if (kn) { kn.value(0.5); kn.trigger('change'); } else { inp.value = '0.5'; inp.dispatchEvent(new Event('change', { bubbles: true })); }
        focusS();
    }

    function nudgeQty(step) {
        const inp = qs('#note-cartitem-0'); if (!inp) return;
        const kn  = (typeof $ !== 'undefined') ? $(inp).data('kendoNumericTextBox') : null;
        const nv  = Math.max(0, (parseFloat(inp.value) || 0) + step);
        if (kn) kn.value(nv); else inp.value = nv;
        inp.dispatchEvent(new Event('change', { bubbles: true }));
    }

    window.addEventListener('keydown', e => {
        if (e.repeat) return;
        if (e.ctrlKey && e.key === '.') {
            const now = Date.now();
            if (now - lastDel < DEL_DELAY) removeAll();
            else setTimeout(() => { if (Date.now() - lastDel >= DEL_DELAY) removeOne(); }, DEL_DELAY + 10);
            lastDel = now;
        }
        if (e.ctrlKey && e.key === '/')                                  { e.preventDefault(); setHalfQty(); }
        if (e.ctrlKey && (e.key === '*' || e.code === 'NumpadMultiply')) { e.preventDefault(); switchBigUnit(); focusS(); }
        if (e.ctrlKey && e.key === 'ArrowUp')                            { e.preventDefault(); nudgeQty(1);   focusS(); }
        if (e.ctrlKey && e.key === 'ArrowDown')                          { e.preventDefault(); nudgeQty(-1);  focusS(); }
    });
})(); // end S11


/* ════════════════════════════════════════════════════════
   S12 — AUTO TOMORROW FOR SAVED BILLS
════════════════════════════════════════════════════════ */
(function s12() {
    function handle(inp) {
        inp.style.border    = '2px solid red';
        inp.style.boxShadow = '0 0 5px red';
        if (inp.dataset.tmrSet === '1') return;
        const k = (typeof $ !== 'undefined') ? $(inp).data('kendoDatePicker') : null;
        if (!k) return;
        const d = new Date(); d.setDate(d.getDate() + 1);
        k.value(d); k.trigger('change');
        inp.dataset.tmrSet = '1';
    }
    function check() { const el = qs('#rebindMaxDateOrder'); if (el) handle(el); }
    onDOMChange(debounce(check, 200));
    check();
})(); // end S12

})();