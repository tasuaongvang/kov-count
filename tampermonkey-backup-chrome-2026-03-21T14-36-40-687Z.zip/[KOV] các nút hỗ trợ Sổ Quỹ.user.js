// ==UserScript==
// @name         [KOV] các nút hỗ trợ Sổ Quỹ
// @namespace    http://tampermonkey.net/
// @version      2.3
// @description  V2.0 Style | Event-Driven (No constant loops) | SPX Date Fix
// @match        https://cov.kiotviet.vn/man/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const BUTTON_SIZE = 80;
    const BUTTON_LEFT = window.innerWidth / 40;
    const COLUMN_TOP = 150;

    let state = {
        spxLock: false,
        spxConfirming: false,
        spxSaveLocked: false,
        overlay: null,
        hole: null,
        pendingTunnel: false,
        overlayColor: '#FFA500',
        floatingDateBox: null,
        amountElementRef: null,
        originalParent: null,
        originalNextSibling: null,
        keyBlockerRef: null,
        escHandlerRef: null,
        amountFocusHandlerRef: null,
        amountKeydownHandlerRef: null
    };

    // --- Performance Improvement: Event-Driven UI Management ---
    function updateUI() {
        if (location.hash === '#/CashFlow') {
            createButtons();
        } else {
            ['floating-spx-btn', 'floating-thukhops-btn', 'floating-chi-btn'].forEach(id => {
                const el = document.getElementById(id); if (el) el.remove();
            });
        }
    }

    // Listen for URL changes instead of checking every second
    window.addEventListener('hashchange', updateUI);
    // Also check once on load
    setTimeout(updateUI, 1000);

    function waitForElement(selector, timeout = 8000) {
        return new Promise((resolve, reject) => {
            const t0 = performance.now();
            const check = () => {
                const el = document.querySelector(selector);
                if (el) return resolve(el);
                if (performance.now() - t0 > timeout) return reject();
                requestAnimationFrame(check); // CPU Friendly polling
            };
            check();
        });
    }

    // ... [Rest of your V2.0 Tunnel & Auto-fill Logic remains exactly the same] ...
    // (I've kept all your preferred logic for spawnInstantTunnel, cleanupTunnel, triggerFlow, etc.)

    function freezeKeyboard() {
        state.spxLock = true;
        document.addEventListener('keydown', hardBlock, true);
    }

    function unfreezeKeyboard() {
        state.spxLock = false;
        document.removeEventListener('keydown', hardBlock, true);
    }

    function hardBlock(e) {
        if (!state.spxLock || e.key === 'Escape') return;
        e.stopPropagation();
        e.preventDefault();
    }

    function spawnInstantTunnel() {
        if (state.overlay) return;
        state.overlay = document.createElement('div');
        Object.assign(state.overlay.style, {
            position: 'fixed', inset: 0, background: state.overlayColor,
            backdropFilter: 'blur(2px)', zIndex: 99998
        });
        document.body.appendChild(state.overlay);

        state.hole = document.createElement('div');
        Object.assign(state.hole.style, {
            position: 'fixed', top: '40%', left: '50%', transform: 'translate(-50%, -50%)',
            width: '200px', height: '60px', background: '#fff', borderRadius: '8px',
            padding: '10px', zIndex: 99999, boxShadow: '0 0 25px rgba(0,0,0,0.4)'
        });
        document.body.appendChild(state.hole);
        state.pendingTunnel = true;
    }

    function cleanupTunnel() {
        if (state.overlay) state.overlay.remove();
        if (state.hole) state.hole.remove();
        state.overlay = state.hole = null;
        state.pendingTunnel = false;
        removeFloatingDate();
        const amount = state.amountElementRef;
        if (amount) {
            amount.style.zIndex = '';
            amount.style.position = '';
            if (state.originalParent) {
                try {
                    if (state.originalNextSibling && state.originalNextSibling.parentNode === state.originalParent) {
                        state.originalParent.insertBefore(amount, state.originalNextSibling);
                    } else {
                        state.originalParent.appendChild(amount);
                    }
                } catch (e) { console.warn(e); }
            }
        }
        document.removeEventListener('keydown', state.keyBlockerRef, true);
        document.removeEventListener('keydown', state.escHandlerRef, true);
        if (amount) {
            amount.removeEventListener('focus', state.amountFocusHandlerRef, true);
            amount.removeEventListener('keydown', state.amountKeydownHandlerRef, true);
        }
        unfreezeKeyboard();
        state.amountElementRef = null;
    }

    async function autoFillNguoiNop() {
        try {
            await waitForElement('.k-window-cashflow');
            const input = await waitForElement('#partnerSearchInput');
            input.focus();
            input.value = 'A';
            input.dispatchEvent(new Event('input', { bubbles: true }));
            let tries = 0;
            const trySelect = setInterval(() => {
                const li = document.querySelector('ul li[ng-click="itemClicked(suggestion)"], ul[ng-hide*="suggestions"] li.suggestion');
                if (li && li.innerText.trim().includes('A')) {
                    li.click();
                    clearInterval(trySelect);
                } else if (tries++ > 30) clearInterval(trySelect);
            }, 150);
        } catch (err) { console.warn('AutoFill Failed', err); }
    }

    function triggerFlow(type, spxId = null) {
        const cash = document.querySelector('input[name="CashFlowTypeRadio"][value="1"]');
        if (!cash) return;
        if (!cash.checked) {
            const link = cash.parentElement.querySelector('a');
            if (link) { link.click(); return setTimeout(() => triggerFlow(type, spxId), 250); }
        }
        const selector = (type === 'chi') ? 'a.kv-btn[title="Phiếu chi"]' : 'a.kv-btn[title="Phiếu thu"]';
        const btn = document.querySelector(selector);
        if (!btn) return;
        btn.click();
        setTimeout(autoFillNguoiNop, 700);
        waitDropdown(spxId, type);
    }

    function waitDropdown(spxId, type, attempt = 0) {
        const select = document.querySelector('#ddlCashflowGroup');
        if (select && $(select).data('kendoDropDownList')) {
            const dd = $(select).data('kendoDropDownList');
            const chk = setInterval(() => {
                if (dd.dataSource.data().length > 0) {
                    clearInterval(chk);
                    dd.value(spxId);
                    dd.trigger('change');
                    if (spxId !== '60734') { // SPX ID CHECK
                        setPreviousDayDate();
                        showFloatingDate(type);
                    }
                    setTimeout(focusSoTien, 600);
                }
            }, 150);
            return;
        }
        if (attempt < 20) setTimeout(() => waitDropdown(spxId, type, attempt + 1), 200);
    }

    function focusSoTien() {
        const amount = document.querySelector('input[kv-auto-numeric]');
        if (!amount) { cleanupTunnel(); return; }
        state.originalParent = amount.parentElement;
        state.originalNextSibling = amount.nextSibling;
        const rect = amount.getBoundingClientRect();
        Object.assign(state.hole.style, {
            top: `${rect.top - 10}px`, left: `${rect.left - 10}px`,
            width: `${rect.width + 20}px`, height: `${rect.height + 20}px`, transform: ''
        });
        amount.style.position = 'relative';
        amount.style.zIndex = 100000;
        state.hole.appendChild(amount);
        state.amountElementRef = amount;
        state.keyBlockerRef = (e) => {
            if (!state.spxLock) return;
            const inAmount = document.activeElement === amount;
            const isNum = (e.key >= '0' && e.key <= '9') || (e.code && e.code.startsWith('Numpad') && /\d/.test(e.key));
            if (inAmount && (isNum || ['Enter', 'Backspace', 'Delete', 'Escape'].includes(e.key))) return;
            if (!inAmount && e.key === 'Escape') return;
            e.preventDefault(); e.stopPropagation();
        };
        state.escHandlerRef = (e) => { if (e.key === 'Escape') cleanupTunnel(); };
        state.amountFocusHandlerRef = () => unfreezeKeyboard();
        state.amountKeydownHandlerRef = (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                if (state.spxConfirming || state.spxSaveLocked) return;
                state.spxConfirming = true;
                state.spxSaveLocked = true;
                const saveBtn = document.querySelector('a.kv-btn-primary[ng-click="savePayment()"]');
                if (saveBtn) saveBtn.click();
                let tries = 0;
                const interval = setInterval(() => {
                    const agreeBtn = document.querySelector('button.kv-btn-confirm.kv-btn.kv-btn-lg.kv-btn-primary');
                    if (agreeBtn) {
                        agreeBtn.click();
                        clearInterval(interval);
                        state.spxConfirming = false;
                        setTimeout(() => { state.spxSaveLocked = false; }, 2000);
                    }
                    if (tries++ > 20) { clearInterval(interval); state.spxConfirming = false; state.spxSaveLocked = false; }
                }, 120);
                cleanupTunnel();
            }
        };
        document.addEventListener('keydown', state.keyBlockerRef, true);
        document.addEventListener('keydown', state.escHandlerRef, true);
        amount.addEventListener('focus', state.amountFocusHandlerRef, true);
        amount.addEventListener('keydown', state.amountKeydownHandlerRef, true);
        amount.focus();
    }

    function setPreviousDayDate() {
        const dateInput = document.getElementById('dateTimePickerCashflowForm');
        if (!dateInput) return;
        const prev = new Date();
        prev.setDate(prev.getDate() - 1);
        prev.setHours(23, 59, 0, 0);
        const picker = $(dateInput).data('kendoDateTimePicker');
        if (picker) { picker.value(prev); picker.trigger('change'); }
    }

    function showFloatingDate(type) {
        const dateInput = document.getElementById('dateTimePickerCashflowForm');
        if (!dateInput) return;
        const rect = dateInput.getBoundingClientRect();
        state.floatingDateBox = document.createElement('div');
        state.floatingDateBox.textContent = `${dateInput.value} — phiếu ${type}`;
        Object.assign(state.floatingDateBox.style, {
            position: 'fixed', top: `${rect.top}px`, left: `${rect.left}px`,
            width: `${rect.width}px`, height: `${rect.height}px`, lineHeight: `${rect.height}px`,
            background: '#fff', color: '#000', fontSize: '14px', fontWeight: 'bold',
            textAlign: 'center', border: '1px solid #ccc', borderRadius: '4px', zIndex: 100100, pointerEvents: 'none'
        });
        document.body.appendChild(state.floatingDateBox);
    }

    function removeFloatingDate() {
        if (state.floatingDateBox) { state.floatingDateBox.remove(); state.floatingDateBox = null; }
    }

    function createButtons() {
        if (document.getElementById('floating-spx-btn')) return;
        const create = (id, text, color, top, clickFn) => {
            const btn = document.createElement('button');
            btn.id = id; btn.textContent = text;
            Object.assign(btn.style, {
                position: 'fixed', left: BUTTON_LEFT + 'px', top: top + 'px',
                width: BUTTON_SIZE + 'px', height: BUTTON_SIZE + 'px', borderRadius: '12px',
                background: color, color: '#fff', fontWeight: 'bold', border: 'none',
                cursor: 'pointer', boxShadow: '0 4px 10px rgba(0,0,0,0.3)', zIndex: 9999
            });
            btn.addEventListener('click', clickFn);
            document.body.appendChild(btn);
        };
        create('floating-spx-btn', 'SPX', '#FFA500', COLUMN_TOP, () => {
            state.overlayColor = 'rgba(255,165,0,0.85)';
            cleanupTunnel(); freezeKeyboard(); spawnInstantTunnel(); triggerFlow('thu', '60734');
        });
        create('floating-thukhops-btn', 'THU ‎ ‎ khớp sổ', '#00BFFF', COLUMN_TOP + BUTTON_SIZE + 20, () => {
            state.overlayColor = 'rgba(0, 191, 255, 0.85)';
            cleanupTunnel(); freezeKeyboard(); spawnInstantTunnel(); triggerFlow('thu', '61128');
        });
        create('floating-chi-btn', 'CHI ‎ ‎ khớp sổ', '#FF7F7F', COLUMN_TOP + 2 * (BUTTON_SIZE + 20), () => {
            state.overlayColor = 'rgba(255, 127, 127, 0.85)';
            cleanupTunnel(); freezeKeyboard(); spawnInstantTunnel(); triggerFlow('chi', '61129');
        });
    }

    (function blockZoom() {
        const prevent = (e) => {
            if (e.ctrlKey && (['+', '=', '-', '0'].includes(e.key) || e.type === 'wheel')) {
                e.preventDefault(); e.stopImmediatePropagation();
            }
        };
        window.addEventListener('keydown', prevent, true);
        window.addEventListener('wheel', prevent, { passive: false, capture: true });
    })();

})();