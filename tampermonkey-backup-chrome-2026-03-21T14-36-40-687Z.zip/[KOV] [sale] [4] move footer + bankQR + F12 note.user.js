// ==UserScript==
// @name         [KOV] [sale] [4] move footer + bankQR + F12 note
// @namespace    http://tampermonkey.net/
// @version      1.5
// @description  Moves cart footer above action buttons, removes Bank QR for Chuyển khoản, removes page footer, and enables F12 note focus
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// ==/UserScript==

(function () {
  'use strict';
/* ============================================================
   SECTION 1: Move Cart Footer Above Action Buttons (Reliable)
============================================================ */
(function moveCartFooter() {
  function moveFooter() {
    const cartFooter = document.querySelector('.cart-footer');
    const rightPanel = document.querySelector('.col-right');
    if (!cartFooter || !rightPanel) return;

    const cartActions = rightPanel.querySelector('.cart-actions');

    // Ensure footer is inside right panel
    if (cartFooter.parentNode !== rightPanel) {
      rightPanel.appendChild(cartFooter);
      console.log('[FooterMove] Moved cart footer into right panel');
    }

// Style cart-footer
cartFooter.style.setProperty('padding', '5% 0 2% 0', 'important');
cartFooter.style.setProperty('margin', '0', 'important');
cartFooter.style.setProperty('width', '100%', 'important');
cartFooter.style.setProperty('box-sizing', 'border-box', 'important');

// Style the textarea inside cart-footer
const textareas = cartFooter.querySelectorAll('textarea');
textareas.forEach(ta => {
  ta.style.setProperty('background-color', '#fff5b8', 'important'); // light gold
  ta.style.setProperty('border-radius', '11px', 'important');       // rounded corners
  ta.style.setProperty('border', '0px solid #ccc', 'important');    // remove border
  ta.style.setProperty('padding', '6px 8px', 'important');          // inner padding
  ta.style.setProperty('box-sizing', 'border-box', 'important');
  ta.style.setProperty('width', '100%', 'important');
  ta.style.setProperty('height', '120px', 'important');             // force taller textarea
  ta.style.setProperty('font-size', '16px', 'important');
  ta.style.setProperty('line-height', '1.4', 'important');
  ta.style.setProperty('resize', 'none', 'important');             // prevent manual resize
});



  }

  // Run once when ready
  const init = setInterval(() => {
    const footer = document.querySelector('.cart-footer');
    const right = document.querySelector('.col-right');
    if (footer && right) {
      moveFooter();
      clearInterval(init);
    }
  }, 500);

  // Observe dynamic DOM changes
  const observer = new MutationObserver(() => moveFooter());
  observer.observe(document.body, { childList: true, subtree: true });
})();



  /* ============================================================
     SECTION 2: Remove Bank QR for Chuyển khoản
  ============================================================ */
  (function removeBankQR() {
    const parentSelector = '#bankAccounts, .payment-method-right';

    function shouldRemoveQR() {
      const checkedInput = document.querySelector('.form-check-methods input.form-check-input:checked');
      if (!checkedInput) return false;
      const labelText = checkedInput.closest('label')?.querySelector('.text-check span')?.textContent.trim().toLowerCase();
      return labelText === 'chuyển khoản';
    }

    function removeQRDivs() {
      if (!shouldRemoveQR()) return;
      document.querySelectorAll('.payment-method-left').forEach(div => {
        div.remove();
        console.log('[Bank QR] Removed for Chuyển khoản');
      });
    }

    function init() {
      const parent = document.querySelector(parentSelector);
      if (parent) {
        const observer = new MutationObserver(removeQRDivs);
        observer.observe(parent, { childList: true, subtree: true });
        removeQRDivs();
      } else {
        setTimeout(init, 300);
      }
    }

    init();
    setInterval(removeQRDivs, 500);
  })();


  /* ============================================================
     SECTION 3: Remove Footer
  ============================================================ */
  (function removeFooter() {
    let tries = 0;
    const maxTries = 12;

    const remove = () => {
      const footer = document.querySelector('footer-component.page-footer');
      if (footer) { footer.remove(); console.log('[PageFooter] Removed'); return true; }
      return false;
    };

    const id = setInterval(() => {
      tries++;
      if (remove() || tries >= maxTries) clearInterval(id);
    }, 1000);

    new MutationObserver(remove).observe(document.body, { childList: true, subtree: true });
  })();


  /* ============================================================
     SECTION 4: Add (F12) to "Ghi chú đơn hàng" placeholder & F12 Focus
  ============================================================ */
  (function addF12Support() {
    function applyF12Features() {
      const noteField = document.querySelector(
        'textarea[ng-model="$root.activeCart.Description"], textarea[placeholder*="Ghi chú đơn hàng"]'
      );

      if (noteField) {
        // Ensure placeholder includes (F12)
        let ph = noteField.getAttribute('placeholder') || '';
        if (!ph.includes('(F12)')) {
          ph = ph.replace(/(\s*\(F12\))?/i, '').trim();
          noteField.setAttribute('placeholder', `${ph} (F12)`);
        }

        // Enforce single-line behavior
        noteField.setAttribute('rows', '1');
        noteField.style.resize = 'none';
        noteField.style.overflow = 'hidden';
        noteField.style.whiteSpace = 'nowrap';
        noteField.style.textOverflow = 'ellipsis';
        noteField.style.height = '40px';

        noteField.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            noteField.blur();
          }
        }, { passive: false });
      }
    }

    // Bind F12 hotkey
    document.addEventListener('keydown', (e) => {
      if (e.key === 'F12') {
        e.preventDefault();
        const noteField = document.querySelector(
          'textarea[ng-model="$root.activeCart.Description"], textarea[placeholder*="Ghi chú đơn hàng"]'
        );
        if (noteField) {
          noteField.focus();
          noteField.select();
          console.log('[F12] Focused note field');
        }
      }
    });

    // Observe SPA changes
    applyF12Features();
    new MutationObserver(applyF12Features).observe(document.body, { childList: true, subtree: true });
  })();

  /* ============================================================
     SECTION 5: REPLACE SPINNER
  ============================================================ */

const spinner = document.querySelector('#loading-bar-spinner');
if (spinner) spinner.style.display = 'none';

(function replaceSpinner() {
    const spinner = document.querySelector('#loading-bar-spinner');
    if (spinner) spinner.remove();

    // Create image element
    const inVi = document.createElement('img');
    inVi.id = 'inVi-loading-image';
    inVi.src = 'https://upload.wikimedia.org/wikipedia/commons/c/ca/1x1.png';
    Object.assign(inVi.style, {
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: '50px', // Adjust size as needed
        height: '50px',
        zIndex: 9999,
        pointerEvents: 'none'
    });

    document.body.appendChild(inVi);

    // Remove image once cart-footer exists
    const interval = setInterval(() => {
        if (document.querySelector('.cart-footer')) {
            clearInterval(interval);
            setTimeout(() => {
                if (inVi.parentNode) inVi.remove();
            }, 1000);
        }
    }, 200);
})();
//
})();
