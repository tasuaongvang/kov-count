// ==UserScript==
// @name         [KOV] [sale] [11] deal with cart quantity
// @namespace    http://tampermonkey.net/
// @version      2.0
// @description  Cart quick delete + quantity hotkeys merged
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
'use strict';

/* ---------------- DELETE SYSTEM ---------------- */

let lastDeleteTime = 0;
const DOUBLE_PRESS_DELAY = 400;

function removeOneItem() {
    const firstItemBtn = document.querySelector('.carts-item .cell-actions button[title="Xóa hàng hóa"]');
    if(firstItemBtn) firstItemBtn.click();
}

function removeAllItems() {
    const allButtons = document.querySelectorAll('.carts-item .cell-actions button[title="Xóa hàng hóa"]');
    allButtons.forEach(btn => btn.click());
}


/* ---------------- QUANTITY SYSTEM ---------------- */

const UNIT_BLACKLIST = [
    'lon','set','bịch',
    'cái','cây','hộp',
    'gói','hũ','túi',
    'que','thanh'
];

function isBlacklisted(unit) {
    return UNIT_BLACKLIST.includes(unit.toLowerCase());
}

function switchSmallToBigUnit() {

    const unitSelect = document.querySelector('#unit');
    if (!unitSelect || !window.kendo) return;

    const kendoDropdown = $(unitSelect).data('kendoDropDownList');
    if (!kendoDropdown) return;

    const currentUnit = kendoDropdown.text().trim().toLowerCase();
    const SMALL_UNITS = ['bịch', 'lốc', 'túi', 'thanh', 'cái'];

    if (!SMALL_UNITS.includes(currentUnit)) return;

    const data = kendoDropdown.dataSource.data();

    const target =
        data.find(o => o.Unit.toLowerCase() === 'thùng') ||
          data.find(o => o.Unit.toLowerCase() === 'hộp') ||
          data.find(o => o.Unit.toLowerCase() === 'gói') ||
          data.find(o => o.Unit.toLowerCase() === 'dây') ||
          data.find(o => o.Unit.toLowerCase() === 'box') ||
        data.find(o => o.Unit.toLowerCase() === 'set');

    if (target) {
        kendoDropdown.value(target.Id);
        kendoDropdown.trigger('change');
    }
}

function setQuantity() {

    const input = document.querySelector('#note-cartitem-0');
    if (!input || input.disabled) return;

    const unitSelect = document.querySelector('#unit');
    if (!unitSelect || !window.kendo) return;

    const kendoDropdown = $(unitSelect).data('kendoDropDownList');
    if (!kendoDropdown) return;

    let currentUnit = kendoDropdown.text().trim();
    let shouldFill = false;

    if (currentUnit === 'thùng' || currentUnit === 'dây') {

        shouldFill = true;

    } else {

        const data = kendoDropdown.dataSource.data();

        const target =
            data.find(o => o.Unit === 'thùng') ||
            data.find(o => o.Unit === 'dây');

        if (target) {

            kendoDropdown.value(target.Id);
            kendoDropdown.trigger('change');
            shouldFill = true;

        } else {

            if (!isBlacklisted(currentUnit)) {
                shouldFill = true;
            } else {
                return;
            }
        }
    }

    if (shouldFill) {

        const kendoQty = $(input).data('kendoNumericTextBox');

        if (kendoQty) {
            kendoQty.value(0.5);
            kendoQty.trigger('change');
        } else {
            input.value = '0.5';
            input.dispatchEvent(new Event('change', { bubbles: true }));
        }
    }

    focusSearch();
}

function changeQuantity(step) {

    const input = document.querySelector('#note-cartitem-0');
    if (!input) return;

    const kendoQty = $(input).data('kendoNumericTextBox');

    let current = parseFloat(input.value) || 0;
    let newValue = current + step;

    if (newValue < 0) newValue = 0;

    if (kendoQty) {
        kendoQty.value(newValue);
    } else {
        input.value = newValue;
    }

    input.dispatchEvent(new Event('change', { bubbles: true }));
}

function focusSearch() {
    const searchInput = document.querySelector('#productSearchInput');
    if (searchInput) {
        setTimeout(() => searchInput.focus(), 30);
    }
}


/* ---------------- GLOBAL HOTKEY HANDLER ---------------- */

window.addEventListener('keydown', function (e) {

    if (e.repeat) return;

    /* Ctrl + . (single / double) */
    if (e.ctrlKey && e.key === '.') {

        const now = Date.now();

        if (now - lastDeleteTime < DOUBLE_PRESS_DELAY) {

            removeAllItems();

        } else {

            setTimeout(() => {
                if (Date.now() - lastDeleteTime >= DOUBLE_PRESS_DELAY)
                    removeOneItem();
            }, DOUBLE_PRESS_DELAY + 10);

        }

        lastDeleteTime = now;
    }


    /* Ctrl + / */
    if (e.ctrlKey && e.key === '/') {
        e.preventDefault();
        setQuantity();
    }

    /* Ctrl + * */
    if (e.ctrlKey && (e.key === '*' || e.code === 'NumpadMultiply')) {
        e.preventDefault();
        switchSmallToBigUnit();
        focusSearch();
    }

    /* Ctrl + ArrowUp */
    if (e.ctrlKey && e.key === 'ArrowUp') {
        e.preventDefault();
        changeQuantity(1);
        focusSearch();
    }

    /* Ctrl + ArrowDown */
    if (e.ctrlKey && e.key === 'ArrowDown') {
        e.preventDefault();
        changeQuantity(-1);
        focusSearch();
    }

});

})();