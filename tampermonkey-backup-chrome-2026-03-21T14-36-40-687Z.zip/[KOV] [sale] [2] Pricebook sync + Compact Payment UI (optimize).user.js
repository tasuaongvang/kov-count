// ==UserScript==
// @name         [KOV] [sale] [2] Pricebook sync + Compact Payment UI (optimize)
// @namespace    http://tampermonkey.net/
// @version      6.2
// @description  Pricebook↔payment auto-sync, compact UI, hotkeys, and multi-payment (Kết hợp) button with pause + robust survive tab switch
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
    'use strict';
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    const normalize = s => (s || '').toString().trim().toLowerCase();
    const stripDiacritics = s => (s || '').normalize ? s.normalize("NFD").replace(/[\u0300-\u036f]/g, "") : s;
    const normPlain = s => stripDiacritics(normalize(s));

    /************************************************************
     PART 1 — COMPACT PAYMENT UI (STYLE)
    *************************************************************/
    (function compactPaymentUI() {
        const keywords = ['Thẻ', 'Ví'];
        function cleanPaymentLabels() {
            document.querySelectorAll('label.form-check, label.form-check-inline, label.form-check.form-check-inline')
                .forEach(label => {
                    try {
                        const txt = (label.textContent || '').trim();
                        const input = label.querySelector('input[type="radio"], input[type="checkbox"]');
                        const ngClick = input?.getAttribute('ng-click') || '';
                        const val = input?.getAttribute('value') || '';
                        if (keywords.includes(txt) || /Card|Wallet/i.test(ngClick + val)) {
                            Object.assign(label.style, {
                                display: 'none',
                                visibility: 'hidden',
                                position: 'absolute',
                                width: '0',
                                height: '0'
                            });
                        }
                    } catch (err) {}
                });
        }
        cleanPaymentLabels();
        setInterval(cleanPaymentLabels, 2000);
        new MutationObserver(cleanPaymentLabels).observe(document.body, { childList: true, subtree: true });

        const style = document.createElement('style');
        style.id = 'kiotviet-payment-style';
        style.textContent = `
        .form-group-row.form-check-methods span.text-check::before { display: none !important; content: none !important; }
        .form-group-row.form-check-methods input.form-check-input {
            appearance: none !important; width: 0 !important; height: 0 !important;
            margin: 0 !important; position: absolute !important;
        }
        .form-group-row.form-check-methods label.form-check,
        .form-group-row.form-check-methods label.form-check-inline {
            display: inline-flex !important; align-items: center !important; justify-content: center !important;
            gap: 10px !important; padding: 12px 18px !important; border-radius: 8px !important;
            background: transparent !important; font-size: 1.2rem !important;
            transform: scale(1.15) !important; transform-origin: center !important;
            font-weight: 700 !important; cursor: pointer !important; white-space: nowrap !important;
            margin-right: 10px !important;
        }
        .form-group-row.form-check-methods span.text-check span {
            text-transform: lowercase !important; color: #222 !important; font-weight: 700 !important;
        }
        .form-group-row.form-check-methods input[type="radio"]:checked + .text-check,
        .form-group-row.form-check-methods input[type="radio"]:checked ~ .text-check {
            background-color: #27ae60 !important; color: #fff !important;
            padding: 10px 16px !important; border-radius: 8px !important;
            box-shadow: 0 0 4px rgba(0,0,0,0.2) !important;
        }
        .form-group-row.form-check-methods input[type="radio"]:checked + .text-check span,
        .form-group-row.form-check-methods input[type="radio"]:checked ~ .text-check span {
            color: #fff !important;
        }
        `;
        document.head.appendChild(style);

        const normalizeLabels = () => {
            document.querySelectorAll('.form-group-row.form-check-methods .text-check span').forEach(s => {
                const txt = s.textContent.trim().toLowerCase();
                if (['tiền mặt', 'chuyển khoản'].includes(txt)) s.textContent = txt;
            });
        };
        normalizeLabels();
        let runs = 0;
        const id = setInterval(() => {
            normalizeLabels();
            if (++runs > 8) clearInterval(id);
        }, 800);
    })();

    /************************************************************
     PART 2 — PRICEBOOK ↔ PAYMENT BINDING
    *************************************************************/
    const PB_TO_PAY = { 'bảng giá chung': 'chuyển khoản', 'tiền mặt': 'tiền mặt' };
    const PAY_TO_PB = { 'tien mat': 'Tiền mặt', 'chuyen khoan': 'Bảng giá chung' };

    function readPricebookText() {
        const kSpan = document.querySelector('pricebook-component .k-dropdown-wrap .k-input span');
        if (kSpan?.textContent?.trim()) return normalize(kSpan.textContent);
        const sel = document.querySelector('pricebook-component select#pricebook, select#pricebook');
        if (sel && sel.options && sel.selectedIndex >= 0) return normalize(sel.options[sel.selectedIndex].text || '');
        return null;
    }

    function readPaymentTextFromRadio(radioEl) {
        if (!radioEl) return '';
        const label = radioEl.closest('label');
        const spanInner = label?.querySelector('.text-check span');
        if (spanInner?.innerText) return spanInner.innerText.trim();
        return (radioEl.parentElement?.textContent || '').trim();
    }

    function clickPaymentLabelByText(paymentText) {
        const want = normalize(paymentText);
        const labels = document.querySelectorAll('label.form-check, label.form-check-inline');
        for (const label of labels) {
            const txt = normalize(label.innerText || '');
            if (txt.includes(want)) {
                try { label.click(); return true; } catch (e) {}
            }
        }
        return false;
    }

    async function applyPricebookToPayment(currentPricebook) {
        if (!currentPricebook) return false;
        for (const [pbKey, payment] of Object.entries(PB_TO_PAY)) {
            if (currentPricebook.includes(normalize(pbKey))) {
                for (let i = 0; i < 10; i++) {
                    if (clickPaymentLabelByText(payment)) return true;
                    await sleep(200);
                }
            }
        }
        return false;
    }

    async function selectPricebookByVisibleText(targetText, maxRetries = 12) {
        const wantNorm = normPlain(targetText);
        for (let attempt = 0; attempt < maxRetries; attempt++) {
            const sel = document.querySelector('pricebook-component select#pricebook, select#pricebook');
            const kInputSpan = document.querySelector('pricebook-component .k-dropdown-wrap .k-input span');
            if (sel && sel.options && sel.options.length) {
                try {
                    const jq = (window.kendo && window.kendo.jQuery) || window.jQuery || window.$;
                    if (jq && jq(sel).data) {
                        const widget = jq(sel).data('kendoDropDownList');
                        if (widget) {
                            for (let i = 0; i < sel.options.length; i++) {
                                const optText = sel.options[i].text || '';
                                if (normPlain(optText).includes(wantNorm)) {
                                    widget.select(i); widget.trigger('change');
                                    if (kInputSpan) kInputSpan.innerText = optText;
                                    return true;
                                }
                            }
                        }
                    }
                } catch {}
                for (let i = 0; i < sel.options.length; i++) {
                    const optText = sel.options[i].text || '';
                    if (normPlain(optText).includes(wantNorm)) {
                        sel.selectedIndex = i;
                        sel.dispatchEvent(new Event('change', { bubbles: true }));
                        if (kInputSpan) kInputSpan.innerText = optText;
                        return true;
                    }
                }
            }
            await sleep(200);
        }
        return false;
    }

    let lastSeenPricebook = null;
    let pricebookPaused = false;

    (async function pricebookPoller() {
        while (true) {
            try {
                if (!pricebookPaused) {
                    const current = readPricebookText();
                    if (current && current !== lastSeenPricebook) {
                        await applyPricebookToPayment(current);
                        lastSeenPricebook = current;
                    }
                }
            } catch {}
            await sleep(400);
        }
    })();

    async function handlePaymentRadio(radioEl) {
        try {
            const raw = readPaymentTextFromRadio(radioEl);
            const plain = normPlain(raw);
            for (const [payPlain, pbTarget] of Object.entries(PAY_TO_PB)) {
                if (plain.includes(payPlain)) {
                    await selectPricebookByVisibleText(pbTarget);
                    return;
                }
            }
        } catch (e) {}
    }

    document.addEventListener('click', e => {
        const r = e.target.closest && e.target.closest('input[type="radio"].form-check-input, input[type="radio"]');
        if (r) setTimeout(() => handlePaymentRadio(r), 40);
    }, true);

    /************************************************************
     PART 3 — HOTKEYS (robust: wait for pricebook, then payment)
    *************************************************************/

    function playTone(type = 'neutral') {
        let url = '';
        if      (type === 'flingeringDouble') url = 'https://github.com/tasuaongvang/cov/raw/refs/heads/main/bank.mp3';
        else if (type === 'deepGong')         url = 'https://github.com/tasuaongvang/cov/raw/refs/heads/main/cash.mp3';
        else return;
        try { const a = new Audio(url); a.volume = 1.0; a.play().catch(() => {}); } catch (e) {}
    }

    /** Poll until readPricebookText() reflects targetText, or timeout */
    async function waitForPricebookChange(targetText, timeout = 2000) {
        const wantNorm = normPlain(targetText);
        const deadline = Date.now() + timeout;
        while (Date.now() < deadline) {
            const current = readPricebookText();
            if (current && normPlain(current).includes(wantNorm)) return true;
            await sleep(100);
        }
        return false;
    }

    /** Poll until a payment radio matching targetText is :checked, or timeout */
    async function waitForPaymentChecked(targetText, timeout = 1500) {
        const want = normalize(targetText);
        const deadline = Date.now() + timeout;
        while (Date.now() < deadline) {
            const radios = document.querySelectorAll(
                '.form-group-row.form-check-methods input[type="radio"]'
            );
            for (const radio of radios) {
                if (!radio.checked) continue;
                const label = radio.closest('label');
                if (label && normalize(label.textContent || '').includes(want)) return true;
            }
            await sleep(80);
        }
        return false;
    }

    /** Click a payment label, retrying until it registers as :checked */
    async function clickPaymentUntilChecked(paymentText, maxMs = 2000) {
        const deadline = Date.now() + maxMs;
        while (Date.now() < deadline) {
            clickPaymentLabelByText(paymentText);
            await sleep(120);
            if (await waitForPaymentChecked(paymentText, 300)) return true;
        }
        return false;
    }

    /**
     * Full robust switch:
     * 1. Trigger pricebook selection
     * 2. Wait until pricebook DOM confirms the change
     * 3. Retry payment click until the radio registers as checked
     * 4. Play sound only after both are confirmed
     */
    async function switchPricebook(targetPricebook, toneType = 'neutral') {
        const paymentTarget = targetPricebook === 'Bảng giá chung' ? 'chuyển khoản' : 'tiền mặt';

        const selected = await selectPricebookByVisibleText(targetPricebook, 12);
        if (!selected) {
            console.warn('[switchPricebook] Could not find pricebook option:', targetPricebook);
            return;
        }

        const pbConfirmed = await waitForPricebookChange(targetPricebook, 2000);
        if (!pbConfirmed) {
            console.warn('[switchPricebook] Pricebook UI did not confirm change in time');
            // Still attempt payment — don't bail entirely
        }

        const payConfirmed = await clickPaymentUntilChecked(paymentTarget, 2000);
        if (!payConfirmed) {
            console.warn('[switchPricebook] Payment radio did not confirm in time for:', paymentTarget);
        }

        playTone(toneType);
    }

    function forceFocusSearchBoxRobust(retries = 5, delay = 80) {
        const searchInput = document.querySelector('#productSearchInput');
        if (!searchInput) return;
        const tryFocus = count => {
            try {
                if (document.activeElement) document.activeElement.blur();
                searchInput.focus({ preventScroll: true });
                searchInput.setSelectionRange(0, searchInput.value.length);
            } catch (e) {}
            if (count > 0) setTimeout(() => tryFocus(count - 1), delay);
        };
        tryFocus(retries);
    }

    // Debounce guard — prevents double-fire from rapid key presses
    let switchInProgress = false;

    window.addEventListener('keydown', async e => {
        if (!e.ctrlKey) return;
        if (!['=', '+', '-'].includes(e.key)) return;
        e.preventDefault();
        e.stopPropagation();

        if (switchInProgress) return;
        switchInProgress = true;

        try {
            if (['=', '+'].includes(e.key)) {
                await switchPricebook('Bảng giá chung', 'flingeringDouble');
            } else if (e.key === '-') {
                await switchPricebook('Tiền mặt', 'deepGong');
            }
        } finally {
            forceFocusSearchBoxRobust();
            switchInProgress = false;
        }
    }, true);

    /************************************************************
     PART 4 — ROBUST KẾT HỢP BUTTON (MULTI-PAYMENT)
    *************************************************************/
    (function addKetHopButtonRobust() {
        async function insertKetHopBtn() {
            const parent = document.querySelector('.form-group-row.form-check-methods');
            if (!parent) return;
            if (document.querySelector('#btn-kethop')) return;

            const buttons = Array.from(parent.querySelectorAll('label.form-check, label.form-check-inline'));
            const cashBtn = buttons.find(b => b.textContent.toLowerCase().includes('tiền mặt'));
            const bankBtn = buttons.find(b => b.textContent.toLowerCase().includes('chuyển khoản'));
            if (!cashBtn || !bankBtn) return;

            const ketHopBtn = cashBtn.cloneNode(true);
            ketHopBtn.id = 'btn-kethop';
            ketHopBtn.querySelector('span').textContent = 'hỗn hợp';
            ketHopBtn.querySelector('input')?.remove();

            ketHopBtn.addEventListener('click', e => {
                e.preventDefault(); e.stopPropagation();
                pricebookPaused = true;
                document.querySelector('.btn-multi-methods')?.click();
                ketHopBtn.style.backgroundColor = '#27ae60';
                ketHopBtn.style.color = '#fff';

                const obs = new MutationObserver((mutations, observer) => {
                    const popup = document.querySelector('.k-widget.k-window.payment-invoice');
                    if (popup) {
                        popup.querySelector('button.btn-icon[ng-click*="removePayment"]')?.click();
                        const amountInput = popup.querySelector('#txtCurrentAmount');
                        if (amountInput) {
                            amountInput.value = '';
                            amountInput.dispatchEvent(new Event('input', { bubbles: true }));
                            amountInput.focus();
                        }
                        observer.disconnect();
                    }
                });
                obs.observe(document.body, { childList: true, subtree: true });

                const closeObs = new MutationObserver((mutations, obsClose) => {
                    if (!document.querySelector('.k-widget.k-window.payment-invoice')) {
                        pricebookPaused = false;
                        ketHopBtn.style.backgroundColor = '';
                        ketHopBtn.style.color = '';
                        obsClose.disconnect();
                    }
                });
                closeObs.observe(document.body, { childList: true, subtree: true });
            });

            bankBtn.parentNode.insertBefore(ketHopBtn, bankBtn.nextSibling);

            if (window.angular) {
                const $scope = angular.element(ketHopBtn).scope();
                const $injector = angular.element(document.body).injector();
                const $compile = $injector.get('$compile');
                $compile(ketHopBtn)($scope);
            }
        }

        insertKetHopBtn();

        const observer = new MutationObserver(insertKetHopBtn);
        observer.observe(document.body, { childList: true, subtree: true });
    })();

    /************************************************************
     PART 2.A — AUTO-FIX PRICEBOOK ↔ PAYMENT ON NEW BILL
    *************************************************************/
    (function autoFixOnNewBill() {
        const cartSelector = '#cartListProduct';
        let lastCartItemCount = 0;
        let scheduledFix = null;

        function getCartItemCount() {
            const cartList = document.querySelector(cartSelector);
            if (!cartList) return 0;
            return cartList.querySelectorAll('.carts.active.cart-materials').length;
        }

        async function fixPaymentForPricebook() {
            scheduledFix = null;
            const currentPB = readPricebookText();
            if (!currentPB) return;
            await applyPricebookToPayment(currentPB);
            setTimeout(() => {
                const search = document.querySelector('#productSearchInput');
                if (search) search.focus();
            }, 50);
        }

        const observer = new MutationObserver(() => {
            const currentCount = getCartItemCount();
            if (lastCartItemCount === 0 && currentCount > 0 && !scheduledFix) {
                scheduledFix = setTimeout(fixPaymentForPricebook, 400);
            }
            lastCartItemCount = currentCount;
        });

        const cartList = document.querySelector(cartSelector) || document.body;
        observer.observe(cartList, { childList: true, subtree: true });
    })();

    /************************************************************
     PART 5 — MOVE ... INTO THE TOP BAR
    *************************************************************/
    function cutAndMoveMultiPaymentEllipsis() {
        const icon = document.querySelector('button.btn-multi-methods i.far.fa-ellipsis-v');
        if (!icon) return false;

        const wrapperDiv = icon.closest('div');
        if (!wrapperDiv) return false;
        if (wrapperDiv.__moved) return true;

        const printBtn = document.querySelector('#printConfig');
        if (!printBtn) return false;

        const printLi = printBtn.closest('li.icon-item');
        if (!printLi) return false;

        const newLi = document.createElement('li');
        newLi.className = 'icon-item';
        newLi.appendChild(wrapperDiv);
        printLi.insertAdjacentElement('afterend', newLi);
        wrapperDiv.__moved = true;

        return true;
    }

    const timer = setInterval(() => {
        if (cutAndMoveMultiPaymentEllipsis()) clearInterval(timer);
    }, 300);

    /************************************************************
     PART 6 — WATCH "TỔNG TIỀN HÀNG" NUMBER
    *************************************************************/
    (function watchTotalQuantityAutoSwitch() {
        let lastValue = null;
        let targetSpan = null;
        let observerInstance = null;

        function findTotalSpan() {
            return document.querySelector("span.text-bg-default[ng-show*='UseTotalQuantity']");
        }

        async function onTotalChanged(newValue) {
            console.log('[Tổng tiền hàng changed]:', newValue);
            if (newValue === "0") {
                await switchPricebook('Bảng giá chung', 'flingeringDouble');
                forceFocusSearchBoxRobust();
            }
        }

        function setupObserver(span) {
            if (!span) return;
            const obs = new MutationObserver(() => {
                const current = span.textContent.trim();
                if (current !== lastValue) {
                    lastValue = current;
                    onTotalChanged(current);
                }
            });
            obs.observe(span, { childList: true, characterData: true, subtree: true });
            return obs;
        }

        setInterval(() => {
            const newSpan = findTotalSpan();
            if (newSpan && newSpan !== targetSpan) {
                targetSpan = newSpan;
                lastValue = targetSpan.textContent.trim();
                if (observerInstance) observerInstance.disconnect();
                observerInstance = setupObserver(targetSpan);
            }
        }, 300);
    })();

})();