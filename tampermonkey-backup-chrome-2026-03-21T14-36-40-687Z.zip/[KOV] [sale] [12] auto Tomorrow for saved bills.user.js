// ==UserScript==
// @name         [KOV] [sale] [12] auto Tomorrow for saved bills
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  Highlight Đến ngày, set tomorrow once, update real data model
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
  const selector = '#rebindMaxDateOrder';

  function getTomorrowDateObj() {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d;
  }

  function styleField(input) {
    input.style.border = "2px solid red";
    input.style.boxShadow = "0 0 5px red";
  }

  function setKendoDatePickerValue(input) {
    if (input.dataset.tmrSet === '1') return; // avoid re-setting

    const k = $(input).data('kendoDatePicker');
    if (!k) return; // widget not ready yet

    const tmr = getTomorrowDateObj();
    k.value(tmr);  // set real date
    k.trigger("change"); // notify Angular + KiotViet

    input.dataset.tmrSet = '1';
  }

  function watchField() {
    const input = document.querySelector(selector);
    if (!input) return;
    styleField(input);
    setKendoDatePickerValue(input);
  }

  const mo = new MutationObserver(watchField);
  mo.observe(document.body, { childList: true, subtree: true });

  watchField();
})();
