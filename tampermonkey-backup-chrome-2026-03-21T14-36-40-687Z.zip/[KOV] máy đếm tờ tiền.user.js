// ==UserScript==
// @name         [KOV] máy đếm tờ tiền
// @namespace    http://tampermonkey.net/
// @version      1.6
// @description  VND calculator: Tab navigation & Auto-focus. 1x ESC hide, 2x ESC clear.
// @author       Gemini
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 1. Create the Modal Overlay
    const overlay = document.createElement('div');
    overlay.id = 'tm-calc-overlay';
    Object.assign(overlay.style, {
        position: 'fixed',
        top: '0',
        left: '0',
        width: '100vw',
        height: '100vh',
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
        display: 'none',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: '2147483647',
        backdropFilter: 'blur(4px)',
        fontFamily: 'Segoe UI, Arial, sans-serif'
    });

    const modal = document.createElement('div');
    Object.assign(modal.style, {
        width: '340px',
        backgroundColor: '#fff',
        borderRadius: '16px',
        padding: '24px',
        boxShadow: '0 20px 50px rgba(0,0,0,0.3)',
        position: 'relative',
        border: '1px solid #eee'
    });

    const denominations = [500000, 200000, 100000, 50000, 20000, 10000, 5000, 2000, 1000];
    let html = `<h2 style="margin: 0 0 20px 0; font-size: 18px; color: #1a1a1a; text-align: center; font-weight: 700;">Cash Calculator</h2>`;

    denominations.forEach((val, index) => {
        html += `
            <div class="calc-row" data-val="${val}" style="margin-bottom: 8px; display: flex; align-items: center; justify-content: space-between; padding: 6px 10px; border-radius: 8px; transition: all 0.2s; cursor: default;">
                <span style="width: 90px; font-size: 14px; color: #444; font-weight: 500;">${val.toLocaleString()}</span>
                <input type="number" class="calc-qty" data-index="${index}" placeholder=""
                    style="width: 70px; padding: 6px; border: 1px solid #dcdcdc; border-radius: 6px; text-align: center; background: #fafafa; outline: none; transition: border 0.2s;">
                <span class="row-total" style="width: 100px; text-align: right; font-size: 14px; font-weight: 600; color: #000;">0</span>
            </div>`;
    });

    html += `
        <div style="margin-top: 15px; padding: 12px 10px 0; border-top: 2px solid #f0f0f0; display: flex; justify-content: space-between; font-size: 18px; font-weight: 800; color: #0078d4;">
            <span>Total:</span>
            <span id="calc-grand-total">0</span>
        </div>

        <div style="display: flex; gap: 8px; margin-top: 20px; justify-content: space-between;">
            <button id="btn-clear" style="flex: 1; padding: 10px 0; border: 1px solid #dcdcdc; background: white; border-radius: 8px; cursor: pointer; font-size: 12px; font-weight: 600; color: #666; transition: 0.2s;">Clear</button>
            <button id="btn-hide" style="flex: 1; padding: 10px 0; border: none; background: #f0f0f0; border-radius: 8px; cursor: pointer; font-size: 12px; font-weight: 600; color: #333; transition: 0.2s;">Hide</button>
            <button id="btn-clear-close" style="flex: 1.2; padding: 10px 0; border: none; background: #0078d4; border-radius: 8px; cursor: pointer; font-size: 12px; font-weight: 600; color: white; transition: 0.2s;">Clear & Close</button>
        </div>

        <p style="font-size: 10px; color: #bbb; margin-top: 15px; text-align: center; letter-spacing: 0.5px;">
            <b>ESC</b>: Hide | <b>Double ESC</b>: Clear All | <b>TAB</b>: Navigate
        </p>
    `;

    modal.innerHTML = html;
    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    const rows = modal.querySelectorAll('.calc-row');
    const inputs = modal.querySelectorAll('.calc-qty');
    const grandTotalLabel = modal.querySelector('#calc-grand-total');

    const updateTotals = () => {
        let grandTotal = 0;
        rows.forEach(row => {
            const input = row.querySelector('.calc-qty');
            const qty = parseInt(input.value) || 0;
            const val = parseInt(row.getAttribute('data-val'));
            const rowTotal = qty * val;
            row.querySelector('.row-total').textContent = rowTotal.toLocaleString();
            grandTotal += rowTotal;
        });
        grandTotalLabel.textContent = grandTotal.toLocaleString();
    };

    const clearAll = () => {
        inputs.forEach(input => {
            input.value = "";
            input.parentElement.querySelector('.row-total').textContent = "0";
        });
        grandTotalLabel.textContent = "0";
    };

    // Button Events
    modal.querySelector('#btn-clear').onclick = clearAll;
    modal.querySelector('#btn-hide').onclick = () => overlay.style.display = 'none';
    modal.querySelector('#btn-clear-close').onclick = () => { clearAll(); overlay.style.display = 'none'; };

    // Row Interaction (Mouse Wheel + Hover)
    rows.forEach(row => {
        row.addEventListener('wheel', (e) => {
            if (overlay.style.display === 'none') return;
            e.preventDefault();
            const input = row.querySelector('.calc-qty');
            let val = parseInt(input.value) || 0;
            if (e.deltaY < 0) val++;
            else if (val > 0) val--;
            input.value = val === 0 ? "" : val;
            updateTotals();
        }, { passive: false });

        row.onmouseenter = () => {
            row.style.backgroundColor = "#f5f9ff";
            row.querySelector('input').style.borderColor = "#0078d4";
        };
        row.onmouseleave = () => {
            row.style.backgroundColor = "transparent";
            row.querySelector('input').style.borderColor = "#dcdcdc";
        };
    });

    modal.addEventListener('input', (e) => {
        if (e.target.classList.contains('calc-qty')) {
            if (e.target.value === "0") e.target.value = "";
            updateTotals();
        }
    });

    // Shortcut & Keyboard Navigation Logic
    let lastKey = "";
    let lastTime = 0;
    let lastEscTime = 0;
    let escTimer = null;

    window.addEventListener('keydown', (e) => {
        const currentTime = Date.now();
        const isVisible = overlay.style.display === 'flex';

        // 1. Alt + C + C Toggle
        if (e.altKey && e.key.toLowerCase() === 'c') {
            if (lastKey === 'c' && (currentTime - lastTime < 500)) {
                e.preventDefault();
                overlay.style.display = isVisible ? 'none' : 'flex';
                // Always focus 500,000 field when opening
                if (!isVisible) {
                    setTimeout(() => inputs[0].focus(), 50);
                }
            }
            lastKey = 'c';
            lastTime = currentTime;
        }

        // 2. ESC Logic (1x Hide, 2x Clear)
        if (e.key === 'Escape' && isVisible) {
            e.preventDefault();
            e.stopPropagation();
            if (currentTime - lastEscTime < 400) {
                clearTimeout(escTimer);
                clearAll();
            } else {
                escTimer = setTimeout(() => { overlay.style.display = 'none'; }, 250);
            }
            lastEscTime = currentTime;
        }

        // 3. Custom Tab Navigation (to keep focus inside modal only)
        if (e.key === 'Tab' && isVisible) {
            const activeInput = document.activeElement;
            const currentIndex = Array.from(inputs).indexOf(activeInput);

            if (currentIndex !== -1) {
                e.preventDefault();
                if (e.shiftKey) {
                    // Go Back (Up)
                    const prev = inputs[currentIndex - 1] || inputs[inputs.length - 1];
                    prev.focus();
                } else {
                    // Go Forward (Down)
                    const next = inputs[currentIndex + 1] || inputs[0];
                    next.focus();
                }
            }
        }
    }, true);

})();