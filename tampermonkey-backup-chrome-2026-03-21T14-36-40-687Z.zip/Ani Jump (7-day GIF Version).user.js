// ==UserScript==
// @name         Ani Jump (7-day GIF Version)
// @namespace    http://tampermonkey.net/
// @version      2.0
// @description  Shiba walks along bottom; jumps on click; different GIF each day. Disabled inside iframe or popup.
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';

    // ==========================
    // 🚫 STOP SCRIPT IN IFRAMES & POPUPS
    // ==========================
    const isIframe = window.self !== window.top;

    const isModalOrPopup = () => document.querySelector(`
        .ant-modal-root,
        .ant-drawer,
        [class*="modal"],
        [class*="popup"],
        [data-testid*="modal"],
        [data-testid*="popup"]
    `);

    if (isIframe || isModalOrPopup()) {
        console.log('[Shiba] Disabled in iframe/popup.');
        return;  // FULL STOP
    }

    // ==========================
    // 🐕 SHIBA LOGIC
    // ==========================
    const shiba = document.createElement('img');

    // ----------- 7 GIFs (one for each day) -----------
    // Fill in your 7 GIF URLs here ↓↓↓
    const day = new Date().getDay(); // 0=Sun ... 6=Sat
    const gifs = [
/* Sunday */       "https://raw.githubusercontent.com/tasuaongvang/spx/refs/heads/main/shiba.gif",
/* Monday */       "https://raw.githubusercontent.com/tasuaongvang/spx/refs/heads/main/butterfly.gif",
/* Tuesday */      "https://raw.githubusercontent.com/tasuaongvang/spx/refs/heads/main/shit.gif",
/* Wednesday */    "https://raw.githubusercontent.com/tasuaongvang/spx/refs/heads/main/fight.gif",
/* Thursday */     "https://raw.githubusercontent.com/tasuaongvang/spx/refs/heads/main/rain.gif",
/* Friday */       "https://raw.githubusercontent.com/tasuaongvang/spx/refs/heads/main/dancer.gif",
/* Saturday */     "https://raw.githubusercontent.com/tasuaongvang/spx/refs/heads/main/ufo.gif"

    ];
    shiba.src = gifs[day];
    // -------------------------------------------------

    shiba.style.position = 'fixed';
    shiba.style.bottom = '0px';
    shiba.style.left = '0px';
    shiba.style.width = '100px';
    shiba.style.zIndex = 999999;
    shiba.style.cursor = 'pointer';
    document.body.appendChild(shiba);

    let posX = 0;
    let velocityX = 2;
    const baseBottom = 0;
    let jumpOffset = 0;
    let jumpVelocity = 0;
    const gravity = 0.5;

    const update = () => {
        const maxX = window.innerWidth*3/4 - shiba.width;

        posX += velocityX;

        if (posX < 0 || posX > maxX) velocityX *= -1;

        // Jump physics
        jumpVelocity -= gravity;
        jumpOffset += jumpVelocity;
        if (jumpOffset < 0) {
            jumpOffset = 0;
            jumpVelocity = 0;
        }

        shiba.style.left = `${posX}px`;
        shiba.style.bottom = `${baseBottom + jumpOffset}px`;

        requestAnimationFrame(update);
    };

    shiba.addEventListener('click', () => {
        if (jumpOffset === 0) jumpVelocity = 25;
    });

    update();

    // -------------------- Disable F1 Key Except on KiotViet Sale Page --------------------
    window.addEventListener('keydown', (e) => {
        const url = window.location.href;

        // Allow F1 ONLY on this pattern:
        // https://cov.kiotviet.vn/sale/*
        const allowF1 = url.startsWith("https://cov.kiotviet.vn/sale/");

        if (!allowF1 && e.key === 'F1') {
            e.preventDefault();
            e.stopPropagation();
            return false;
        }
    }, true);

})();
