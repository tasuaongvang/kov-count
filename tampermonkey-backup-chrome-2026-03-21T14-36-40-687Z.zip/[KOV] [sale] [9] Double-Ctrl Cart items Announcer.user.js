// ==UserScript==
// @name         [KOV] [sale] [9] Double-Ctrl Cart items Announcer
// @namespace    http://tampermonkey.net/
// @version      2.3
// @description  Double Ctrl speaks cart total — gapless audio (fixed autoplay + CORS)
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function(){
'use strict';

// Force raw GitHub audio fetch
const base = "https://raw.githubusercontent.com/tasuaongvang/kov-count/main";

const fractionMap = {0.25:"point25.mp3",0.5:"point5.mp3",0.75:"point75.mp3"};
const standaloneFractionMap = {0.25:"0.25.mp3",0.5:"0.5.mp3",0.75:"0.75.mp3"};
const ZERO = "zero.mp3";
const TOTAL = "total.mp3";

const ctx = new (window.AudioContext || window.webkitAudioContext)();
const cache = new Map();

async function load(name){
    if(cache.has(name)) return cache.get(name);

    try {
        const res = await fetch(`${base}/${name}?raw=1`);
        const arr = await res.arrayBuffer();
        const buf = await ctx.decodeAudioData(arr);
        cache.set(name, buf);
        return buf;
    } catch(e){
        console.warn("Audio missing:", name, e);
        return null;
    }
}

async function play(name){
    const buf = await load(name);
    if(!buf) return;
    return new Promise(res=>{
        const src = ctx.createBufferSource();
        src.buffer = buf;
        src.connect(ctx.destination);
        src.start();
        src.onended = res;
    });
}

// Fix Chrome autoplay block
function unlockAudio(){
    if(ctx.state === "suspended") ctx.resume();
}
window.addEventListener("keydown", unlockAudio, {once:true});

// read total
function getTotal(){
    const el = document.querySelector('div.col-form-wrap.d-flex span.text-bg-default');
    if(!el) return 0;
    const v = parseFloat(el.textContent.replace(',', '.'));
    return isNaN(v) ? 0 : v;
}

async function announce(){
    const t = getTotal();

    if(t === 0){
        await play(ZERO);
        return;
    }

    const i = Math.floor(t);
    const f = +(t - i).toFixed(2);

    await play(TOTAL);

    if(i > 0) await play(`${i}.mp3`);
    if(i >= 1 && fractionMap[f]) await play(fractionMap[f]);
    if(i === 0 && standaloneFractionMap[f]) await play(standaloneFractionMap[f]);
}

// double CTRL
function listen(){
    let c = 0, last = 0;
    const limit = 300;

    window.addEventListener("keyup", e=>{
        if(e.key === "Control"){
            const now = Date.now();
            if(c === 0){
                c = 1; last = now;
            } else if(now - last <= limit){
                c = 0; announce();
            } else {
                c = 1; last = now;
            }
        }
        if(c === 1 && Date.now() - last > limit){
            c = 0; last = 0;
        }
    }, true);
}

// Ready
setTimeout(listen, 800);
})();
