// ==UserScript==
// @name         [KOV] [sale] [1] monitor Shiba + after sale effects
// @namespace    http://tampermonkey.net/
// @version      5.0
// @description  Merge unified monitor bar, shiba text, smiley, swoosh success, and giant cart number
// @match        https://cov.kiotviet.vn/sale/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';
    /*** ======= CONFIG ======= ***/
    const BOX_DEFAULT_BG = 'rgba(232, 247, 255, 0.1)';
    const BOX_REFUND_BG = 'rgba(250, 219, 20, 0.7)';
    const BOX_DEBT_BG = 'rgba(255, 77, 79, 0.7)';
    const BOX_BACKDROP_FILTER = 'blur(1px)';
    const BOX_OPACITY = 0.95;

    const IMG_URL = 'https://upload.wikimedia.org/wikipedia/commons/c/ca/1x1.png';
    const IMG_ID = 'kv-center-smiley';
    const SHIBA_ID = 'shiba-loading-text';

    /*** ======= SMILEY + SHIBA IN CART ======= ***/
    (function() {
        function addSmiley(container) {
            if (document.getElementById(IMG_ID)) return;
            const img = document.createElement('img');
            img.id = IMG_ID;
            img.src = IMG_URL;
            Object.assign(img.style, {
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                width: '120px',
                height: '120px',
                borderRadius: '50%',
                zIndex: '99998',
                opacity: '0',
                transition: 'opacity 0.5s ease-in-out',
                pointerEvents: 'none',
            });
            container.appendChild(img);
            requestAnimationFrame(() => (img.style.opacity = '1'));
        }

        function addShibaText(container) {
            if (document.getElementById(SHIBA_ID)) return;
            const shibaText = document.createElement('div');
            shibaText.id = SHIBA_ID;
            shibaText.textContent = 'shiba đang đếm ...';
            Object.assign(shibaText.style, {
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                fontSize: '28px',
                fontWeight: '700',
                color: '#d4380d',
                fontFamily: `'Inter','Segoe UI','Helvetica Neue',Arial,sans-serif`,
                zIndex: '99999',
                pointerEvents: 'none',
                background: 'transparent',
                padding: '0',
                textAlign: 'center',
                opacity: '0',
                transition: 'opacity 0.5s ease-in-out',
            });
            container.appendChild(shibaText);
            requestAnimationFrame(() => (shibaText.style.opacity = '1'));

            const stopCheck = setInterval(() => {
                if (document.querySelector('.cart-footer')) {
                    clearInterval(stopCheck);
                    setTimeout(() => {
                        shibaText.style.opacity = '0';
                        setTimeout(() => shibaText.remove(), 700);
                    }, 800);
                }
            }, 300);
        }

        const waitForCart = setInterval(() => {
            const container = document.querySelector('.cart-container');
            if (container && container.offsetParent !== null) {
                clearInterval(waitForCart);
                const spinner = document.querySelector('#loading-bar-spinner');
                if (spinner) spinner.style.display = 'none';
                if (getComputedStyle(container).position === 'static'){}
                    container.style.position = 'relative';
                addSmiley(container);
                addShibaText(container);
            }
        }, 300);
    })();

/*** ======= UNIFIED MONITOR BAR WITH BANK & CASH LINES ======= ***/
(function() {
    let boxCreated = false;
    let lastScale = 1.0;

    const box = document.createElement('div');
    box.id = 'sale-info-box';
    Object.assign(box.style, {
        display: 'block',
        padding: '12px 20px',
        borderRadius: '6px',
        fontFamily: `'Inter','Segoe UI','Helvetica Neue',Arial,sans-serif'`,
        fontSize: '22px',
        fontWeight: '700',
        textAlign: 'center',
        position: 'fixed',
        zIndex: 9999,
        opacity: '0',
        transform: 'translateY(73px)',
        transition: 'opacity 0.5s ease, transform 0.5s ease, all 0.4s ease',
        pointerEvents: 'none',
        backdropFilter: BOX_BACKDROP_FILTER,
    });
    document.body.appendChild(box);

    const topLine = document.createElement('div');
    topLine.id = 'sale-info-topline';
    Object.assign(topLine.style, {
        fontFamily: `'Inter','Segoe UI','Helvetica Neue',Arial,sans-serif'`,
        fontSize: '22px',
        fontWeight: '700',
        textAlign: 'left',
        position: 'fixed',
        zIndex: 9999,
        opacity: '0',
        transform: 'translateY(50px)',
        transition: 'opacity 0.5s ease, transform 0.5s ease',
        pointerEvents: 'none',
        color: '#003a8c',
    });
    document.body.appendChild(topLine);

    function shibaVisible() {
        const shiba = document.querySelector('#shiba-loading-text');
        return shiba && shiba.offsetParent !== null;
    }

    function getRefundValue() {
        const refundLabel = Array.from(document.querySelectorAll('label'))
            .find(l => l.textContent.toLowerCase().includes('tiền thừa trả khách'));
        if (!refundLabel) return null;
        const textContent = refundLabel.closest('div')?.textContent || '';
        const match = textContent.replace(/\s+/g, ' ').match(/-?\d[\d.,]*/);
        if (!match) return null;
        return parseFloat(match[0].replace(/[^\d.-]/g, '').replace(',', '.')) || 0;
    }

   function updateBoxContent() {
    const span = document.querySelector('span.text-bg-default');
    const cart = span ? parseFloat(span.textContent.replace(/[^\d.\-eE]/g, '')) || 0 : 0;
    let debt = 0;

    // Detect debt
    const debtLabel = Array.from(document.querySelectorAll('label'))
        .find(l => l.textContent.toLowerCase().includes('tính vào công nợ'));
    if (debtLabel) {
        const textDebt = debtLabel.closest('div')?.textContent || '';
        const match = textDebt.replace(/\s+/g, ' ').match(/-?\d[\d.,]*/);
        if (match) debt = parseFloat(match[0].replace(/[^\d.-]/g, '').replace(',', '.')) || 0;
    }

    // --- Scaling logic ---
    let scale = 1.0;
    if (cart >= 21) scale = 1.5;
    else if (cart >= 16) scale = 1.4;
    else if (cart >= 11) scale = 1.3;
    else if (cart >= 6) scale = 1.15;

    if (scale > lastScale) {
        box.animate([
            { transform: 'scale(1)', boxShadow: '0 0 0 rgba(0,0,0,0)' },
            { transform: 'scale(1.1)', boxShadow: '0 0 20px rgba(255,200,0,0.6)' },
            { transform: 'scale(1)', boxShadow: '0 0 0 rgba(0,0,0,0)' }
        ], { duration: 600, easing: 'ease-out' });
    }
    lastScale = scale;

    box.style.fontSize = `${22 * scale}px`;
    box.style.padding = `${12 * scale}px ${20 * scale}px`;

    // --- Base cart text ---
    let text = cart === 0
        ? '🛒 đơn <span style="color:red">méo</span> có hàng nha!'
        : `🛍️ có <span style="color:#d4380d;font-weight:800">${cart}</span> món‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ `;

    // --- Payment detection ---
    let payment = '';
    let warningApplied = false;

    function getMixedPayment() {
        const container = document.querySelector('.single-payment-box');
        if (!container || container.offsetParent === null) return false;
        const label = container.querySelector('span');
        if (!label || !label.textContent.includes('Thanh toán kết hợp')) return false;
        const methods = container.querySelector('span[ng-if]');
        if (!methods || !methods.textContent.trim()) return false;
        return true;
    }

    const paySpan = document.querySelector('span.amount-pay');
    const payValue = paySpan ? parseFloat(paySpan.textContent.replace(/[^\d.-]/g, '')) || 0 : 0;

    // Gray out box and disable Thanh toán if cart = 0
    const payBtn = document.querySelector('.btn-thanh-toan');
    if (cart === 0) {
        box.style.filter = 'grayscale(100%) brightness(0.8)';
        box.style.opacity = '0.6';
        if (payBtn) payBtn.disabled = true;
    } else {
        box.style.filter = 'none';
        box.style.opacity = BOX_OPACITY;
        if (payBtn) payBtn.disabled = false;
    }

    if (payValue > 0) {
        if (getMixedPayment()) {
            payment = '💰 + 💳 🢠 ba rọi 🢠 ';
        } else {
            const checked = document.querySelector('.form-check-methods input.form-check-input:checked');
            const rawPayment = checked?.closest('label')?.querySelector('.text-check span')?.textContent.trim().toLowerCase() || '';

            if (rawPayment === 'tiền mặt') payment = '💰 TM 🢠';
            else if (rawPayment === 'chuyển khoản') payment = '⇪ 💳 CK 🢠';

            // Refund detection for bank
            if (rawPayment === 'chuyển khoản') {
                const refundVal = getRefundValue();
                if (refundVal !== null && refundVal > 0) {
                    box.style.background = BOX_REFUND_BG;
                    box.style.border = '2px solid #d4b106';
                    box.style.color = '#000';
                    box.style.boxShadow = '0 4px 12px rgba(250,200,0,0.4)';
                    text += ` ⚠️ <span style="color:#fff;font-weight:800">dư tiền rồi!</span>`;
                    warningApplied = true;
                }
            }
        }

        if (payment) text = `<span style="color:#d4380d;font-weight:700">${payment}</span> ${text}`;
    }

    // Debt detection
    if (!warningApplied && debt < 0) {
        box.style.background = BOX_DEBT_BG;
        box.style.border = '2px solid #a8071a';
        box.style.color = '#fff';
        box.style.boxShadow = '0 4px 12px rgba(255,0,0,0.3)';
        text += ` ⚠️ <span style="color:#fff;font-weight:800">thiếu tiền rồi!</span>`;
    } else if (!warningApplied) {
        box.style.background = BOX_DEFAULT_BG;
        box.style.border = '2px solid #1890ff';
        box.style.color = '#003a8c';
        box.style.boxShadow = '0 4px 10px rgba(0,0,0,0.1)';
    }

    box.innerHTML = text.toLowerCase();

    // --- Position main box ---
    const leftCol = document.querySelector('.col-left .cart-container');
    if (leftCol && leftCol.offsetParent !== null) {
        const rect = leftCol.getBoundingClientRect();
        box.style.width = 'auto';
        box.style.minWidth = '120px';
        box.style.left = rect.left + 'px';
        box.style.bottom = (window.innerHeight - rect.bottom + 0) + 'px';
        box.style.whiteSpace = 'nowrap';
        box.style.display = 'inline-block';

// --- Unified Bank/Cash Refund/Top Line ---
let topText = '';
const checked = document.querySelector('.form-check-methods input.form-check-input:checked');
const rawPayment = checked?.closest('label')?.querySelector('.text-check span')?.textContent.trim().toLowerCase() || '';

if (cart > 0) {
    if (getMixedPayment()) {
        // Mixed payment: do not show thối lại
        topText = '';
    } else if (rawPayment === 'chuyển khoản') {
        const bankSpan = document.querySelector('span[ng-show*="dataItem.Account"][ng-show*="dataItem.BankCode"]');
        if (bankSpan && bankSpan.offsetParent !== null && bankSpan.textContent.trim() !== '') {
            topText = bankSpan.textContent.trim();
        }
    } else {
        const refundVal = getRefundValue();
        if (refundVal !== null) {
            if (refundVal >= 0) topText = `‎ ‎ thối lại 🢡 ${refundVal.toLocaleString()}đ`;
            else topText = `ㅤㅤㅤcẩn thận ⚠️ tiền thối đang âm`;
        }
    }
}


        topLine.textContent = topText;
        topLine.style.left = rect.left + 'px';
        topLine.style.bottom = (window.innerHeight - rect.bottom + box.offsetHeight + 23) + 'px';
        topLine.style.width = box.offsetWidth + 'px';
        topLine.style.opacity = topText ? 1 : 0;
        topLine.style.transform = topText ? `translateY(23px)` : `translateY(50px)`;
    }
   }


    function showBoxOnce() {
        if (!boxCreated) {
            boxCreated = true;
            updateBoxContent();
            requestAnimationFrame(() => {
                box.style.opacity = BOX_OPACITY;
                box.style.transform = 'translateY(0)';
                topLine.style.opacity = BOX_OPACITY;
                topLine.style.transform = `translateY(23px)`;
            });
        }
    }

    const interval = setInterval(() => {
        if (!shibaVisible() && document.querySelector('.cart-footer')) {
            clearInterval(interval);
            setTimeout(showBoxOnce, 1000);
        }
    }, 200);

    setInterval(updateBoxContent, 1500);
    window.addEventListener('resize', updateBoxContent);
})();





    /***************** AFTER-SALE GIANT CHECK EFFECT *****************/
    (function afterSaleEffect() {
        const SOUND_URL = 'data:audio/mpeg;base64,//vURAAOBIB1oYhmZ6CJjkRTBKyeVrHStiKllQI9OdloJJrxAP/+UxaWKymSOnLFMWn5GRv9lZRYsIpkeZEZGRkYwwtHllM5f3pFSaFxZRqx6Fw7PSkE2/70pBOHZ2lIOpONyiIceEEzHZ/+7bAhl4kjcGYiHcDNq/Sl83IS8SRkEY6H6y/WdNy2sh+jaEYlEfywfrL0vTc21f69NmZ+l4GVRueL2NzbdS+dMzs3mZvSF48YABCKc/Mkmj/8jMwof7sz//9mdtUKPFyL/+giPBw4qKhXZh5Dt2Z/Y9/q06ijijifcv3P02Zmd23XpeBk+NkBWofcfcXv0mZlgploZj4fmC+YCSNwZg0K6ZauOSUNgYCOYJ0iGQhJDIIw8J9L0bTKTQ/pfsZXIBYM1jcELS1Gbni/N+Bl5GoXkaZIf0IA4BmIAgEkYYAAAAQr1Q/+kFELd1+QEnIza+z2iAEAw75/dQtsbBMn39NHNj//3XwH5IJixw4JlV6ymwFMd8mYY1jb7ZLEMCYURS2+xTtJB5xXP5beJB0ed8nYllvztcAgDDL+n5wucpvwiGW5prRMTn8/ESIX4Fl6iGjuxEVB07bOAggPyw4diWT4my4BAAAPOvA8JDsckg1LZhG2V0ESImGRLAgIhg5q9p18zjK5biJb1BOFKaclaKyK8IIOQnXf39AgjDi589IBQx7bIyes67ajH64repk5sZ5+yM3U9UQIIt3q5GT7cyAMRXbKChiGf4u3/1xWGzHumPDP8I256gJIsZekDtQMTC4nEDP9IBaexID19///5hBNow9IIJ1dn1H7k5PT55MBrj2D0Qzv77/8og/xoP2PG+9/ukG/MIICFUC0iEOmICE9MLAdKswm5QANHtDkJ2MZ0/njGhByeX9Z7ZDfZMne4TVZiHvXTjDykPewlCZQkEZvEYUHCNZ1o0e0AgkEZsQElpAmaJJiASZTWIpzqt5R5SAr1evKBjjvzsQAtitJ2ihDD9JeLIQwnCLZ2dEKlCyeJUhCJQY+//vURD6PFqp0toDJf5LU7sbQGM+eFkHY9AGx/wLMu17UND/QD6OdC0QqSEMqHwlBdSGeXoUsth7o5xJ2riCH6Og53NqQyDOp2ZLlsUpO1cXBMmWiCx7U754yaPxlLhBQ9RsRBENIWeguaiHoRJxthfDwZy7ps0GRrUbBqSO59g6wApA9PSE7D5pj1DpxpiAs4IPSQtMENC2IR7JnST0QgxNpJrISmxNNsPSkBpJw92fv27/+wAAwwHOVbCwsomyD7jEDRlt+5P+VX2muwPUPalWfiaUbYoGSG7Q9iOhvW1ZFQ9Hp9mOhImWiGU52dfJ2tIYuTrYjQVpCEieZyKlLnIbJrnWnJVwZ5Xj0HyZb1PubY8gmmZhYC+HI0DfMoJANMIOOQIOXQ6TLOdLD0C7jHhm+aQBAPkUscgmCJHAmVonDCxIxXwlW2PF2hZfFCXPeX780uZeaBGWHmTBWpiP2IqEtf4noSFIp0+V4SUho/1ihkUvs/e+rq9bbsa5+/WPXVTtbe7LFbXpAzd+603PGIHH1D/UgHuC6wuF8lu8Vmz0wE4Ul0riGg0Dt4+NB3PCYTw7eMDMJ1pLHjToPDMgg2EKFmMliA6I5NHUeERcK/GaEIA5LS+/Zj8NFHSM1jIajoRZ2HAxqNQMb5Fmufqbcl1U61RpyaBJ2pQm8mnjXJHWFG/xJEgyaUjRSJMcSxVZSN624YHDcQZ1HsSXDw1R4shGiPYSTIgVCJHuac9Qnp6lwyUeN9OT4dzxxLOH733VOfoeXnMcNBocCzJAOaH4N4b9R5jsFI121dV7JDRjyOzwY8l1hvb1tMISzLtD041Qj9NtGmc9ZFIaZzq46GVXl8XyFlvVdWFClOYKOaWZpO1VHaXpkKEpkKMlCmcfhyRi/xWF4c51GKm0mrojZlkbzsdDDQ6JSLtWiVzdI0dDBOIk46MnDKdJaREdJe5aFZ/FjN02lTDsnMzr5RleZH+7uoRaTu4xqy+R7b0zRhnW4I6WO2dFN6y9jokDjSBchgFxQ//vURCSHVbB1vYBpf7K4bte1DS/2F53Y+LQ3gALSu18ChsAANiU6sC0CgZAuZYQosFZMHwPXIS5ABZghOBAgACg088kXSXb2xMQrqxmOpPrtPomhLWU6Q6ZUJQtcH63KdeQoW9DpFYnzvUJ1MpxkmQgxDZZVyTgtxKSiaIyHgm1ILwyzIZVAXI8xujXT7Q5QZZAEADEvi6LBsep9FECKiyWHUEkLc89yyB4u9yMTDEZefI+Y1zBjSZgvpb4Y1ex+MxrJ39RIlllb7DVTizEkVhOc9ttpDzbyiINLjWLFU5IWGByQpejchFSIWEYfPxikuuZBgHkQ4TIBOTtsSRhrLxkRTIhVTZewlIhrxOztkc336tOU0H5vpxBRFlgLA4pNOKs0C/oQrzhQ0XzRMdyEI46m5NtZ9CaJclT8f7grU8dCJJOzmYuoVZtAvgrmZvtEfKJ9WpeuPe+fvwpPmHfFNU1fN71o37xm9JPqsCJq9b+uNb16Zvi0O89I2Kb3alN7rFpjWq4rfvIOpZJ4EDThms2M0n1DZbQZ2Nxl7Zt+zwVhaa4TzXYHJuXplAcm1FNl6r7M6jTikZVHI+fYYX6LRylkRBp1RCIZny7SCk3tyVsO6uUJTs6JQKCbGRdxI5/bfM6jW0ecyhXRc1YuSaqB2WMu43mfZb9IczHId6HoxKwXmTjQ9/DcW7VdEJfIFubtpzPZ//y7f3htOQzt34MvM/C3lMx+c+lNv9KdSb3vkwXbv2LOcc36Xbj7tv8PS7jPVl9TurcZP3H82z2LF10Tbjalytqr1ChRC2hKbHWze44Qwnih561UiS3xnBicO8OREJj52sNGDImCuAfRYclcCycinoVu4M08ZSHFO2O7A2HsnkQcVbozGRstLgF0oQFVwGZGOVPl0cRLPRYPokAZLROANAW0gFCQcOOcYAAWyOUJCKNtIMcV6hKqc7vnh8z8tm2MY1JySqjaziZ6audsXb5+VV6VdtUafmam52uhm6JNZcpRxzebfKbUlWrMp5ku//vURCKABceHQQ4NYAC/cOgQwbAAF9XbJ7jVgALvu2S3GrAAw2VN6s+8lylbCejB1qScLIMOl661FhsYMZJ8fh6NjIhzcnmx80cfOmi5AkASpaaFqLSeVmI+FiRpR1g73FJ48BsbHj+QBiKZAf/////j0RW0aA2O4lm5WG47UB5DP/////8eykvJxQdEUfREDySg8D8P4JrRHdCQkLpqOZfNKOdub1GJita890rKTN7055Z98tn+xMz+023Xj2u/S99/9h+D5/oJ/r7XPes3TIXmVj32qheuy0MH05Dzlz8NX8V+qZmDa2UMF/3laJMtdTFQ7+w/oZOKBUfRLrHQkmp0rry46OvNIkN9o4jRLzxh944DM3EUkDgylPjVkSBEVCAVy6TDIQpmZmZmZmZmZmS+YHzYrClQuOF4NTYrLjCZmZmZmZmZmZl/FSCPxnxscoaEeGATll0NiURjYXXcai0RhsIg0gSIwuxfLvJc3MRw6o73X4J5GBLJJUP346wTFXj0HruB1gSEI8B4HpIEIBKv/BEJgfAEATCcVDcjA3I//h4BMEGSB0BueOpFI7TUpG3//OB7J9jeHsvMTWTUk20ku//8d5PMiWTx8VJ46DkmqRtKROPGxK///3jsJlEgdhMcNg+E8kExKHGzYSbSSJrX///+T3MJ5/JY7z7R3k8sTJ//////7TVHRJMSSXORSNnf/VXSoIhKIxYNRqJRIGgiCQaQbI5dAe5d49zcxE91R3uvx/Iw3opG34OwGCmyUO78dYBAgHgIDuSG4PVf+Og4UB4JhsSgQmoDcSf/xsHQQ5IHQCe46kUjtOojt//zg6yfY7x3nzFGUSTbTV3//jvJ6xLJ5MVLx0M0XHpcec42///3jsNGEgmHHDsJhPJBMNoSJW42RpJU63//7/ye5g7zeyWO8+iO8fyEKyf/////+iamsoklyJJSXRKice//3DopsZpWFWNFpTxd481d/n9ix7ZZpPzn7PTk1cp1WINt22nMp9c2tp3cz7/k2dYr//vURBcPxWB2P4c9gACn7sgB5bAAFxXW+gMl/srfux9IYbPANNfh2bYzP3mk1n6TFb/d6CfZpzE4td6OnNRZlfVt1tDWXkLI596VKiO6xM8/JfjWPQpz/jtrkahZdS4cMp3SqakxUQmLiZNmrEnHBB09VnB1BCdiIJqkvjZerCg8VnUrT8PBEOzt0Gy4VlZ0zBREPSQ1Tg0UicTVwlGApdsquADUrzTpTW3TDWvhfcl61Yu74LZu47M321Z7L22afFFl06/eW97tPvvV36369+ZmkE/ObbJ7ums/Sevk3135+ZpuxPdm/jFPvjN8+7bMbyOz7PLlexLv3jo3l17lbUSPD1SnLD65AeupXkxUuStlp1XQwcbjQ41SJKfwP2dJRYMCkaJTWo7ipp1DooOCepOGy+Wi4I1YBOLBcsdFyEZ4oKq5DeqDyhhSNI9BnqzvdwcoruS/JGRyFEpMRbdeM6Z9qQjLd+ZO4TIKfM9oXkphjTai/EgidPMQji+L7GDFzTRVeMI6nNOSh197cNgswidUPayGmIxWLsAeUIza4nTXeKGEJowk2gkD5GjQtugF+2WE5OSg4ymn1Sy13DfM0sconCC5xmR6wODY3odAYiKXCsQgvLLlRqQuKENzegXE6k0zq9hQ91HLieBsknV7UoVIu0euTqIt9KtqaRePlCV92NZAQBnSRtS5JppElJM8fd29yrKvIlFFBDVEgtMDB0VmO0RE/L0nb1UWU3569Si0EvVJtDWkoMaIMxLq1q91ZlViy+nUMD3VKrq2kXuQnTWvturkN7pjy8J+UdcJLKF6hYfpCRETSSZJ0p28Yr6lcsPiFjrTVDM9iSgm0YE4dCueMrBGM2kaw7SEbhCJ54glg7XJymWg6JVXCsJ8AYFdchg3J5hCBUdFhuhKhAGxCHD3ki10glpQXVWVDUi+fbD6OxrtFUkiqkKwlJp4c/JeiB73JTJtZa99oOkg/fzbtjaaeU7kDLch5X9K2yiiSJkls7/fPL9lFJ1WFnWLRiwk//vURCKN9cB1voEGfXK1DrfQGMyuVnHa/ieZlcLuux+Bgz54umA01onJ0Gj4JH4w4dgpDzv5WmLCmdvI8K2XO7pXJ5C4sieb5WeIcj54o40Y9UIZWyrkrVwwoYha7gKhS4ZWZk5oo9cYZFU3QxPNG8qR6kKIYjy42QlSnQu36pgq8n6sWSeJ1TKmAcrmlj8jNhLUecKmDqOslBGuaczbeL0IdZrJlu8Q7pJwuXMOndv1Rj2lEzju953Zc5RaZ/JNZBBfqXaEDHqSmb7zzWLIloG4nFL01lFDQkZyDCpB1L/cCL5QIWeTA6BxGkNOm1wNynJ7CYsrZPIlRWsjXp1DJonLFRaqMWkpROanqdpYPBeVEpYNR0XuLh6D5mjIrRTAgPp6qE8eCygkZBUCkmEEdBCRnCw/YI4Gh8Ed0IUZMHJMWScK1IKQCWYnrQ2QDghp1w/LFiam77F5ZocemsVxS2Yl41CaF6TJxrxHzYMX9n+EEBJ9nmHpRusXfvbQPpsY0/dveazk1LdIxPIZWH0Ya+ZzIu5xbJG2ToyLip0uTGSbUgpGkauyHt6xzEuKcV4SevutcU1dJNkLUKzRosbTFY0iJeNI0MnleM6BoWPSLiuYCITDRsfAcHsSTgloZWOyqd6OJaOD1DO3zYvQjwViYM0MgCWXjw0Qz4qFQe194+AyHJdf43cvVsK/a2rtidzuXsLn1K/mZm5Kc3jaZNUzM6XVk5DUse7/BcdtgN2uE0utRVzD+Yi9Qtiz+zcg55uHqw0ybcscdYGfA/eaj1pPPEfyzvI1IkKK7suIzuqoixLwU6p4zudvfKxcpNhfOlFAePYjI5qxOE7ZaR6J5OMq2ntqRXRaKp0p2qlIyGvDko0rk8tM5+Kd+sRWBXM6cQ9wQw5D/ZYZzqlpL+bS0iKRYLmXxZY5EMZRxTYeqilAAwoY/GA2ACmjEARVw4Hib/3ABIDDgijMtbGPuE0zJvTELUU84JlV8EVEJ0/Veoa/p6jtsWRZ69/5vt7tJNb2l2+2//vURCIABc91wRNGYtC/Tsg5aYlOF13XDU2xFwL+OqFptiU5PX7zPbffXzz+1bpE5unmMLIff+X5rW0L6dntq5WCHqQMPIlkxsUUYy42jbbq40ZJX1y8zcPYXXG4Wy5dS+d4T2bqK0szjx4dULuEEjuHDB4oWRldVWNEfMEZwdi3CYpvfRDiJtSemLCQloKlooKXnD9QVeP20iIItfSIFDs9145QZdduCHNa2/cfEtMFC0G8ZgeHB4Vy2hLGS3ASzdhSnkkKD8SHVwgBQaktcGB4PCgRiehiVkqb1Iu1RPbb1AgVfK3oDybCkO65a6OlEm172c/OSrdQht1lQjkq9ym8kdOxBByTjKJJ1omSamMUqmU2Zt0w2vi0MlPJWQFxS6T0EFtZksaImJQxcSRXNqk5DIcNtpCcUmFWmpyOwc1SMVErDZkKSCf1A6Q4npdAR8/eCMsqCKetSqVXXG2gAYi4Gr0oKfJKuGMQ59h88r0Yl0tnZFNP44ED0k7dmoxHdTVPBb9WHXhhgRHEf2oS9EhqCueJSQZwKh3LPuMF/LNs9GraijtBc8vNys6tQ2sEtBgSlSn1SEUpjele2hGuGRIE0uLiSDzkSVpZpiEh7ZexRJsciSkclzpb4ykAQOgxzBRD3PEdIG04qR6EjLlLcm3gRQ5GrjMqj7k8TMLlnmF2x3BA89xJYuHCUoqaSNLEQVkw5VRRWcbbQANu+DlckoNSsDXBAtJfoXHJ7rHwqFipCJSLWdQmKnxqvZJZ4h1Hrj4opF4V1E/KQaQMrGhOJThIyGZk2JsKCJNiYoOSHHoA2kSLslLA2JyDJt4yFBYBQ7PWWlCAVT2GdhonRQfsVWugnFJr1OFNJt6vLZ/6zd5S04VGS9pHWVVQcaWjk2ER953f26SRsXOWUuiQ+L1kRUiMaaRNXU1JG5xOVM8sbMkSzkEUBbeSozJjEJggPYgkaVYpiglHJbZbdLGSbC3BjwTGNAK5czHk+WhvvSyp2JtsUlfeXIJ0yE6YGd+H4El+//vURBYABbZuRWuJHmKxTbi9bYiOVp3PE64wdcrWumHpxho5M3hHJ2nrvvNSt8n/oZ55opWn5wiJnFDZcNk5ukwZeSDRkYIKPwYTP7B7dyuD0cITDgmUjKM1zhKB4aVVpnpY5VrJSdI+sUwuZZsiXvJV3FjyJB5IMQs6ihvr3KO7uXq8ZwwsLwdkFI7bBn4BQG0D9AGwwpUiD46LUG45mfvATplSKIaGY4otGpEG9EMUl1u220ZJi2oNRQQKA4b7uIw1vbzs7qMwhD6OnHU0JK75yPyGkE5ihf8Sx3KhNAsDEFx3IBALANSceqHjuMniBp+VR+aPbFIhE2zB24fUOSvah07HmrWoVjEA6nyEyvsveDpAGstNotMsYkzVUcINF4oDdbsJpqHJGYkMqTsoZq4pfL2vK8a7SzZRxRpraQsjMluirzIj8ZzNXZWjzrVcpVe9q9ZbDNYgemlWLjPBmAG3HJJJJYkAdVXBi0QAI4lAgFhGsCtZY8lQeRUcNTu1BltNSNqPwqGm9eKmo23p4Nd5zB/LhNL5SD8qhA2IJgZHDzAofSMaeLWvPSJGeQeidXrDI4LLEHyysPV5XiX7CvL1GFzNeqcOlMj1htWaf7r/TLmtbuHHZdvpyrPew72VgWIoWsvLTBKtbRDrewWQekQtsgYzRE1dQVJnQSFPzSn+DwpOqdlkXoNUmuRBjHrKD7IzgMoTVdIqNogHP6yaLIBkgBOanQyNn7kUDWmiNk2+UZhqSQw2aHmuB4eJ0Zlp+fD4yZKQ9hXj7g9dGsccRYkYXIoywZkfiscO6z6lSVj1VqNpesUW7jvDr2TMeqZCzaGSowOI/KL83egSUVm1I8kWtwAYnD1GTfco0gxZRSkKTfDJrtlMBVs05uz2D9VJNtPpsnRsuSraKyigX0/Oy8XNCM+NQPiMPF47magqrsvbYxy25eOUWkugmgDE42i0m4yQd2YRkECGFgOXChCIwKIhcQIBiVEYTkL8KbtbZZFsWkMVaw/3WxPrySVZHL28//vURBqABcZ1xGuJRdC6znh8cYaeVp13Ga68z8rUuqIx1hn4nrFmlkpoURAqlsabQMHozRrmVx02RTRmn6hkdNitH5MOSejPQYV+OUMkBRJgswwI0GJolECG0i9utoj67vByA9JiDrZh9sLpL0aNJFWddZUkerkC9Dyz+qGSI66QruOFj55v/u4Ipz6iiUXhaJT+Va/EAaLVitH1B/GnfuLX8hQ8+2IQBoqJtMt0B9CGHwXSEHVcT6BwaBwAcsoAkLRmdBMlg72OgtBqjaypdDT3eaRIBeFAmoJo6TH3zgqnhxGZhEoGRmn5Jq2BUtYXu9pPfbZ9fuNXve+J0zyuKlZcgVMOwOnCI6PFx3BK+9GOjoqdihuU2mW7VgcdvjLpaumYD1slmCUSK8L9Piaf5kZmazlEGqWhvdNQd2WmSx+d1mzVXzNPWyNRBSBpWLp//adkOltP+WSS6HI4xME1yRaQ0Byzxx22WRpGUmBGtRRCINQUCQ6Ba+jBMBVKyzY6AKnKp3UCARQBW4YozQTr6R6jl45mZKvn8eHKmCpduSgMOdihnaqEG3s6yzTKo452B61LF4r1xeLhzSrJI6ko7iaq8bbTD6QXNGGJMxF0AO4OPLuoXpoD/JKMTgWT6NjvTUzWkju/aOKD96xK8zUkinwgQzcLff6yVMWWjzvybvGLlpuizIRw0u5yT34FWcXI8d/zzO68iwDEW4iKrlAwn7QymPIxOBcSFgwRB0wNABRdQdsckgRClXKWbP082/d9KFr6MsNTc4QkBhEIbr8a83PA5Mx0fHM4XL4zlg78/SID648TtYo04N4kL1Fy4ricdSspNS4APxjjGaiKJFOsbcv5Rx9wdVR0Dz5x1tpioeSplLcSVC7dqK2GxNe0xAhk+Xl0Lh3wm423u02QttYvPr6izbDNvKSZKsvx5zcc91wfX6bRsFoy5S/p7dJqAWd4iHh/NrpFDbyA9QZMHAIDAoEQgqHQoH0+gKFhwEPA5bhfbk20BrD6jAH9WGUVedTc//vURBmABQVfSntsNKqjC+k/aSOfFN19K+2w06qDLqR1pI6siGIRiOISmEalA6g1LakmRIfOP8AAAYDFNKmCxGihB5yHVFpJHkLGA49SZB6RxSSz7ejdOZM8npXLlGUHdEuMTmEiyeQSIKh3gMD1LxJ+MRzbVOO2z4kpvvb/3B0vHb1+yfdJFM42sfKLcQVBb0AjS9U8M+l10ah0WJyGZpQahZhgi8zGCkICIE3MWKiQ5ENPRpigywrcWPuvAkSgN26hAyC7AYACAwXAsEQMonLlEDiD6kH1sSKOVZAOFgJ0gmgIPuvIEoOYJFW1Cd2eLB6TR0V2imiqBPZGvCVoT0XRvE5RJ18Jl15GEIhcSmPlqUEqLxgl59gNmzQM1iBMawsw1olFp1QzhBSqcDaEQUIf/+9YLTwsRLPbvdLKVbNqxVPjGgswZAIjQRioYNAoGXak3JEzlbGBxhvVAnxzh2CWHtcXYS2rA+Lza/1fHMolJWXUqGNINhYDdcuW1cHzWCcgMHkJ8tOVa4kO7vG+vwqOZgVlY4UxWhfZocwwuExO/KFbpe+3NuVopFSxjEOLrkGQg3bovexlkyklHKx8NxCNM5lWL8tkaQQ8qxK7QBMnLptZzrzA9ENYhBE22t9rkkaRZ2sZ7wQUIGdBqnAQ0RBQUDTcU3gKq0tDB92rOxG3Wi6tsTfeNV3Fd56ozMaC+LzRjYWQCM6SxRlQVkohOkCBQgPmCMussLa9RojRo0idUnLkiqHTa0ou2MFXK2nji85ozCg5mYUHdiHgOSCMGTgGEpNfgEgQw7MkEGMSwiJjCW+jAEfyqLtoIrSsS0IhI7hVhQV7/sxJXXA7qgOYVlWEWTZ5x4LXz4jzZkiID6nQRgo14uoIEjx3YTooNLmUPaGoehgw1K3BsGmgmiFBRFkROwVXVRauQGScVAaEKgoi0TlWFkWCkxG+hnGKN7dWmn28pqbKtxEBGXXD9yZXcbYjNb753reU/oryoTwvUKqmDZz77rS3thWGT7Hgi76t//vUREGABOdgS3tYSHigK8lvbYZ/U/mBL+0w1SKDsCV9pJrcnKjKGW1BH/XnDIbqaa6WfJ0hzWE7m9RHNKYQzxbuztrvLHKYSbHGjsmc4OA1QI2IOIODoaZKJExJFVgFC5EyNwQJmw+CSEhsPaCoXCUOBMLK18trlI/sGSNT55RQZJ4Eyd0zSmBPW6hFu48RL4ac3GvnDslxv9eswTbmOLPLjdPxaE2cybO6aajk3JFwxX5fyimhZW3vZ6p8do9EIZIwPRMFfKOIMySJ9EKcnileC2xt3xtZtXBaaI0GAXeXZ1ZrNbVJgTdDq5QQfoyJMeDmEKCEEg0BQSdAkjSaSAhh2WYp90TvsQcd23fmmuw7EVh5UIIKROCIPKFUguX99g5On1J2ZmEJ8pyVvvnasR44kVHIi0XEFbqOjjyskkTKk5RLbJh1EC3/mXiMzPb7Pfcvk8yzW1Cps1z9yoQU3JHepOe9unvmZ+h9hny828QgqPGQYQudzOb/SPA0dBaZ5lWRtppE3DD4R9+HNgwOWSCoNUgiAFkH8LQq3qUI0QNGJhdzluXBkEOpBcKvum01Y8qfV25XSrCRGxED5ocZBBgXZ0SiN7CmiBY2yRj7Kp1wtBJJlMwFpzJlIrTKYBmOciks8HJoEDT35r2gUhEYf05a9w+U4zS46FPZFy/KUKRqzjsqKpOtej+VKtR+vUz5jsQ71OM5RWfZ97js9ThtSAAABHDS0GUJDPEpghEYBAsJAAQhQRAaNAAEAOlYAQJRPGgQKwAjXsqZNGaFg7yI2KMMriS1HtEIJx1NqkkJyXhCH2ymO44oRgdF3XTyBM6vOyk3Cetjm2aoJkOyAScFqJjye6hZ5QbCkPjETo0AIdVXZx78zG2efaUbfbGJFTRMrlEb1n8n7mn4+eZn1rIGQ/18/gsgu+Q1sPW3Dt+x04vSy3F322miszjbx3rx3RiEgyxhFEw4oHCBgMLAKqEasYkDTTCB6faomdhwSA8EgxGsOHbE7vvHWKpmJJ6IAfEs//vURHCABRxgRbOsNTCgLAltaYZ9FF19M+0w0SqIL+Nl15l4+PGLGCQ0Pl71OM8JqEU0KBKfGv6QggR1O0AlI+CZMeePQSuFfQRp5pTOET1ZenHls1tpvPLWhdu0UcV2PKc6U9yfJ6/ZcXlkWxtSqCEHtb5roQCHl75Y4mYQ3NotP6Tkk5xgIkPEw7HJLI5Oc18fQYbF6YoKDjbWjkD1logGACIlIUKXr7TXTpWCXrSsSTbKxODFhCMDda84Ux4XQE0shycHxjVNHsVyinMLNSUQcUgeiVFItqR/JIzwsgomFhDt7QH/SR60CnyA6aoPt2Jc9dy9lFnsqiVIsahwNN/CkqB+caxTd7SZUQalZ5WO3xM1VYgdrEkIFpg4hRNh6GnxyhRauN5ZEAIQAAAI2PcI6mIwxzDMOFkBBGBgACgDjIBNQQhRSCAEKIyyWh1tLGai2TMzh0mmZ6SVBN29rZz9YKNSkQhFl8XbcoU89Tc2WJP2fszOKQcKDXGDVNvIEQ1EYTC0I99md8t9JfcKdUrJqY+7ZL2uyNnnFllKZLzBFDl3/EpUfzDeUzPetkM/2yv2ebmW8U1DkEHTJsITKWibarp39mIUp3/+tQ/rvtK7LY3OZV1I0sDBgSXGIQUYbCQiEL6LnCKCxFbwLMSJD6RrlsuaioIsejfSB2TvEsHMyCPu1LDA+HJ4ERLEMlXWHJHWH5bbMkSuq0zbK8NG/quKVIo2x+IA4tITi9f0KrXYLuHBLapGZXorhgfaS3Xv3ooszblnRefN0aomW3g6J16PktlvlNdDL8M1P2m/abY9E0/S7uK5y1HX5+mEI9QPdMj0/Tvr2WjA4ZabJlsYK8B4d1BKd3aIRLftUnioHTYNsqlJkgZxWwVCkxAwYVgqq4sLKA6KjaKhLfpSJ0uoWzfxnBFSP3T+qkVCMfuCskM9D0uSiIhC+cSFltNNHkCX1bDjNrhKrpZJW+MaVJG/ErLase9JHmkMrRdKnhEVohNP/7tq9HVv66fr9v/pdtLm//vUZJoABbxgTWuYYeiIS8mvaeWNVdF9N+3hhWoPFiQxzLxwddWI7s7qxBhTO49cEV3dWhEblkSmPEigYHmOAsnJSNBosXWeaJHyxqIAlobrULrAoSVLUWaq4CoR2LIlumhYdHn1ahQT4huUD8yQCAheuLa70J11eeOMunp2vVlI+5MvOC6U1xmiaeqnXORk9m6zll0BRlyYotZl2F5r37LMe9qG29D2xuTB21t9EKh38uVn3Wfj72mOf/oW1VJljkJZq5iy5z3LN6y591ELzfOrolrzlkLbNMrW2GZDgklE2BMoBGN1CfHOZmogkSQO38azkQwij8dhRxSGnSoaABEby1yb6YiIJaFhp6EuTx2WVreg6OUdoY04pyYLovSIMBnP9IH44K07ENdVO5ytClYmWGuWU/1ZTXu+Z5JppN+b31/etMUmmSoTN/ikKMIijfrHOb/3VUoebhi5iDAQ6//tAHlUM2RJJXHHzJagxQKAQe5YEEwuVGBDZbNAiRAbBlwI8PDLU1pXIXlVtfUxEd2IOz88EQmgUTnB0Ti0CjcKhVjzS4xRV9c7HDGpGiAwe4swCeVppE+WQBSRJDC2EEVhM26Z56UoslukhhpLTITJn1VshkPDyaLyCCBHJQco4tlFIGpFy9787PO7fufl/x/eW1CWRCOgyxpA9wc6aXiGzu80KWt7KJxJArHT5h3wcZGGFQBRTLQCIRZvLy+SOCnlTKLtKZUv1nKvEZ5QeNjmPhfPHDgfWDFc2hGSQrmZNWsRlUGSxwrJ3iAR00YICkVnGTpHB9MIUeohkstCdsKR6GMlUTEH4rIv6ljqqEKvEqud3K4U7E4fHK32LpZXwq15XcV9nn6sdfPzj3T+Z6bz0iOpRCmHlGhwwuq2shlShRtmcwsgYFACCUnTNEUOrJIyAwe0a5I4GlWHFyIFBCyKE9rZcdYZPjik28bO/wJgERBsJhNkjg4XE5llUGhE4MCmT14ok9DBoujgrIugZhQeUq0ZAZm9qaPwkqYeSf49//vURM8ABQ5fzvtsNFihS8mdbYmJU+l1K05lIcqArqd1phn9JvV5MzheKvRkirSBVxxcylKTFLsWRzKPT1rpLK/WvKd902VGLu2MtWcbp9Tb1SNdi2MUblI/XxDBHXj7ilKCKWIPViPE+20kslcjk5kv5EmAwmXGJJCMWhuYMaYAEJEnMBQFHtJpNpiEQb8sASGJVJDY/Rh6frEdDQ7LBmlcLVjBbx6y80vkdWGzp1+ZUxPxQOxwNsJBNivZ288fliUApyYpaDEQeXDQcZNQ2kjTQuSzMOWMDmOgRaxTIImSf9H0KPLpADqEFZEPy8Ui6bOvWf6p8n6VofM4nCe7OKIlaxLGQt8PqhAgAAFSzF2gj8IfDAsGCYzTBEPUA5hIEgYBIMBICAcAiA0SvV7I4jTwuNL8vwy7bchobD0i1IKUO5lk1Ob04ESo3uZTaaJAsRjcPNj3DEeByfggRFY8lw9JHFpq45txCORHDBASktCXPqVr7T5/bBMfcNkj0ly8TmWRLE6g/jNcVpNh1cfWZWLuiotidnJfvFK379rbnV9tlpa3Gtlg6aJDC/LblCxdRNYH4zxT/XhPdXXdaXY7FLEFL4/ro4MIAAAAYxIcA8aU4wgAkMEMAgOFghIcmKAbgKkOAGahhC6yQql7M1KR4C32ktISvYayFPVujkVIs+VDw/Wj8PIclcJDURF4NE6GFeE0d5Aue0RHhypiIRkgvsr3zs7HtRh/G0c1JheMIzQS1R+tNClBfZZcSHDFGFVzO16ay63RIiyjC/V/LcXcx8baKVk4+kpkNGsPHK953NmLWOnFa+07v+51ac3fkLtbpFr8d37/2QT3ddhyn6PlX3SAEAAEilDgHjzKZVQgZDCQBRUIGfi5QFkCUKxla1LBgiu3+LSM8gVl7cV4vw4j6Nq80OQUxzaQBg2VEwxL5kAgsQwuvHZ+ejmdn52nJsrz40M60ozMS8/M0zbfkAhiQXlh2PasoHC9UYLVpUOEI6LawkRtLWHF1Y+mGdehrVdd//vURPuAZepfSUu4YnK7bAkZdwwuFlF5Ku7hhcsIruRl7TwovmImT1srx3fR+zW/o67r7tonLr5yN7Ps1SOlrPQf9/s5uMdK5rUNCgsb0rafdtkFGO6JygMABGbO9WYhg3pgfiJR6RxihisIjFgBIFgQZGpBwI+iXwthzAH4m4qm0BkKQKYvgVx0j6FpNEWVdLRc3A3TvRRICJJcPSq0UfqQVZpos+aFvkOVCzHUEqpfVLenLuBvMrFFVa5Y0huHDYtOaozZC3Bzo40fK5X3fQllHw59Sq9VUXq5bmxskgXbMQl85n0FXuf8a7XF9nerbltiE83bLPGpSaA6ixK6me03NE3XdaX1Z3XN5P4Oq2gwYtvWJJmIxjla6gQhAAAIIUNfv3PByCMxCAMEAdNGfViKRsjMcDMeONSWHRBIYj8aWOpakOgneJ0gJikYD+EIYlgIYz8eEA6FY1lsKwKD4eNH5LN1A4JlL64SMRGTysvOoQPlQ8PB7HJCdXri/Y8RnGLH8+mQr4kNx9VAmWr3ZOTOK/n/n6eFKvUH9Zt2cV347bRTLG2s5PZjM5LkdUj8TLfHF9atSCLDjFlvqy/drcclJWE8vq94ppztduwUYrY+svY4kAACWY+CLJkTgmA4ckwDwEwIAWHAOFACBgUgIwcPAXgAApCMVZKRfnPYdAeiDlmnjrVByGQeChOafRVGQq2JgV6nbUiYTGrEiyAIcmD5xc0mKg8aHhGH9HjpGOrqpU2WUJUJtAeGYonFF2kaPJEUIUTLIEM0ROuswhNtrpMmUS1ovV6eL3OqYOqtJIIKJUpDNT1k2kqE04EBCms5AlDCBQkd5NtI5JyY601zxdVNpcuXWyCiCEJn9mpgQqIAEIEumqlNGtZ4GKAimJ4IjqB3gIGA8IyRGamiQW4HjRYONJmthgRvVOGtr/YaoLAA5GjItgHACBZqhDSD7R8nfPDA9fO3wsN+I6EBzYm18MaWAyEibrSQzDpyvL5ohFk7L9rxWeX0tWUOdX0jZqvW//vURPKABcZgStO6YOC57AlGeelcFxWBMU7lg8LjrqXx3DCxQuKThE0jQlab3lmLGIHaJ9VKaXVMU6ClG2K0736n6p6DV/pYKvM6eRLqTHRzqRrEUV0RwycsQH9jVDvEXT5n7PHNXW6+1YBJCEkACN5spwxpqcxlkFJh2DhikEBgmFIV2dzHcgoBFtWNQQHOWuyV66JpTJGYrDPKwWFgYOSwTCnwwLJiYCs+QjJpWTCInPCAL1jkk8yJi1m4nrtcQkZFKdl6tuA7YEm5l9niJdtuO0atr9bzVsLNsOEiHCZNQOvIT7y9Ysw4Xrl0cKRo/NT655fVh+sO6XY48Xuma+2VP4y7AtPmdMImoPe5Y5z/0U7FE63TF9nYbxUepuPM8jYKVQ7ZtE2UiWQqZX4xq4ICg1GCkZzh1RGUuTUhY8RIGcOcYRtMgwoBKtxgUeLVA5DD3UazDzFRAJIfg4BkhlcQnmADikXNEgOgycdOiuOBWGSmMpHp1c7eODV7WnjihXl2BdBZQfFkuGRPK5gcGo2XGT6AOrxZPTYSTg7LDbMNFjBYUmRwY0jYXIFVCZ+G34kbhLb/bbe9Z9paYs2XjjqFgwgLF4WtqeEuOVi8/acYLvPVdNUqpGDcnqqaclaFxgn6r1gkZYmUUkQAQ01sjiNCMMKgCkUxOGjMAmJmDyTAsoOfLyCAYbcMdYOBAgoORQlp3LvT3RRhxMZUo4MzB5rS40oNETujASsDqiVIZSypDUMlZbisG+fhyDodXiQ8qhdRYi65jmChxLi2q9XqWDF3WFdcOMfD7V+xVYov7esLuytfwXBWTSNyy1RvuG+t/vWVG2q11ey1NZhgPXsH6Z/nUL/ufLEpUNM50SgKMIAABG0srjeWGMJXCyQGAYOGIhBAgczAIMCzxuxABIvyGjl/QsS3cRAgrARAPqGSDgLIAc+kmbJnifmMOYkA8ggBhkIHCMApzbOwkZyM7iTNhSkdDTLGgXpCcx2pRpcw4jSyI1PuaWY0IMVcQ14/z+O+//vUZO4AJi9gT+uZYPiiyIlFcy8uG9GBLy7l50JPoWVZzCG4GsnAZ7o5VC3WZFEpmBofNBwNTDIS5EtL9zgp5ndaSqLkeuCjW1a9ispX0Rq5VyEwXrvKlVUHfZcng/cHC08RWaev2Rvc5Y12XseZGSdwjvGz7tmJAVhb0+3O2xR6j8xmGb6UlsIQ9kVLRR2AgAjMOlPPA85YgzNaGM2goEkQxEETDxMFAsgmBICLAPBwCQDEgJBQkUjk4LElI90kOgojW6MtEIYmyRtngVjWw2dMuvHGg3HMb1dbW4opu8zXIYf50484z8OS/WE1C3RgBpjWoJcgFBcgvkq/y8kHBceJRBbw6Doe7KRBTE1Xywm/JN/+GcXf83//87iD/u+/fYvqIAABhyJdmnIUMY14NRgihRAYsbE+eGqaJUZ26awUZiGPKjioTGgFzEBz6UHZTVQDkQAhihiwKSYAOLGJImNjAVaSYZeVWEADT8Hkt/B60BEFv0qGphAUZ4ebE8jxvArhiCvsmzRpaKumuqdTCn3SqtMZQ9UBu3AsAQ2mTA8DOCtpkMPRtrsaUfV/DM+7jX1YXBVCyR8mgPbJGWW8YJVG1xh0ZciXyHGTui8csazpejZ4++rxVmXt7AjiXnPnmp0FjcQg6B5tvJPAinMa+USZ0YfnLDLIE+G4PvNIjVyflb7VZPI4clbL5inqSmL35qORaB7sUkmNipUnNbnKkrpcqTAFFgAAAABDe6NO4NQzkejQoGAZZi2ny+PymqCn8z0qrKOF0wSCAjwOELSNVQ5QPIFdDArdhaQNYJON8t4dYgQ6S2MrAlhjsIllagDQV5WMyfN5IHCe6GJlUMbnDV3P9JSsh+LRonayf//y7ljV1LDr3/+/Fq6x4FIJ3E/Q+n1yrv8t6tVqKV9IBQrmrFAG1xLmFAHmNgCmLwKF2TDsEjAcPAaChggHx0FBd8Ljhj6abLC8K7kwJGgmdNMZmCkI4XgXg47M4fk2n3dHUecpuE3AjUmYvOjiFQ5IZKcG//vUZO6GCAhgyqvawMCHpgl6cy8eGpWBOS7licnvGKc13TwogS4jQekQfmCQ/H/Fzkttkhe55Ow3NzQ4VRL5MDuVRwuLBcEulyQ6X0MTCh6GJSaogLTisomDtxY2qhHlePJm+T6iS4eMCWZbCbF9xtIsJiEoYxUtSMGFopLrDatRpbbYZTXPlohEsshAPdIyoJxygwE0zHXToeyXSAhmBKLfk8HASjIIBBAAExkMiJwKap/sAlgP4PUGNaMMKYKWhvIglsQIlq0okbQ5wj84PpkA5GgzFISgk0MNxYJ+ulA2GGZA9elt+rVIq0AtqlggnIaKO38WWEhS7UqVPDb3NFSuv///e1d799f0977vib+1fIYLfJpf+vW///ORAL/uAJEQAASPxyCNkiVOBBjtW80c9KVkITzkjY20NNsKRAfmFBJZsycMMLGAoACTKql8K4MUETzL6NGuoQMhcgACrGhlpw68R67rXDONNZKwugjo1mAVd0SUZaxx3BLKP06DYWSKeQRr3aaX/i8QVZDLtzL7Qa+jtNNnFYW7QewiXMviak2RJztLssEiaXa1G7O+vyFw8vtJNRaQO5FFMHbctL9urwMwehW1oUaam6r9SRpdBbYtBKfcNPnJWSv8pWwxx3UXMkyvJrEVf1qyuYHXO9cTaHAD/TMddpGx8o5GGcSXjc2iS2bl74Q66dpy36fklKpfGFwtIYjADMGCIJWPsmbVNyB2WwU4kWX5WdFNBsSe6a656lRTB7AIbXHEk1SR8ZVrG6rxkYmlGhePFjmowgo5oMZxHKYBC2NrANG1plymCpIPUzeWUP9RMwa5HHXaHEGERGXTS4mHsvmQ/mYfilQJ7JM75Ojgpzq1UdnzBbGonDwtXQ5lyvYS71fgh6KdbfD/Lv9FYVYXL5EmmoGCy4wb9n26SMBMBOlM5TcMRypMXwuMMQdMKQTIABJhaMLAOBgGAZQBapuH2gsv0nGocVABcyGb8KUqWvmoBGETF4orxmMNsyx1IBZQ6T7s3fx5//vUZPACCMZiTEu7wFB8hXo9bww+GrGJPq7hicJLJSghtiZYGzs2LhqAs/GhefmwfERKQFSi5h5PRoh3H4tkJQXDN0PT0cCqhondL2IQw5KEiQlcTVHEtaqHxiqG8Pk1Qi6hWLSZBr44RYsXwiV5j90qkx8qUKY9ozeyGfGSHRQkO0ps8woLmL0GMdOK/MIUUMB2ToZH8npCdd55dEuM5XnRRehscmZ08curm9gM+AiVgIzt684woMGRioGGdnYYNmLFxgqSrcPBRiAA8tm2XTeKLJAIzICF/LIZMX8YqRGBiOhDeLYfLCuwRFYDzgh+XioW1rSU7ADw4diLppHzlkxNayIfIziJojRge9GJ20zUFdQo+o2gvUDHnvIdpv//qQtyhiCdkzP8CyvFbXhFMoYKGIcsNDmf8oYz2K1nZD9G5QmhAAQBjsHSMXGceJREmDAQOJAGPChOYhAgABYOCJbUQgdYQOAgmQxSaBZG2YJdwbBBDnlQ5zQheOYOCChqWfqxoN5hNNVptsV5IWdCKGJFaUIJgLEV9od8Olx6fwLXushL3DtcFCw5cYOzcvnrEn9jhlGdsy4aGftYQT9+LGIanggmsp094aQXVqoXk7FGffMHC3T8k5eYTojs4R3Q6Egdr4w2sb5aaVho2vPLTdo80Q1ZeTGFfL0pzwTyp86cUw4fDAAJrVggcdIOFQgBoIBoFBKAAgAQBL9C4AkAAroSvSxLkFADIyIIwzznLA9N4mRyGozDKWCGk2MY6I7Atv08h6TT9joXDaYjizv1W6lcCRwMljgsoWDQnAVJMwgYEJmxoxpGQmhAdLDhXHAgAgyDk01yNQ6yqikCbRAORSRRFNGhs5YIlXHNDxKImSM5BJMLkD1BKGCCJM0cXMrropoaNJkbckfVwqrSbCbYor6kSdRgalsKGudJAPEEvZRizbuPhFEAE1PhQxlDEDHGYUAcDAAMKgaMEgICBMGggAgJMgAQQIdECaKq2kGm4F8VjCzEZ1K3rV2jRSxolG1J//vURN8AFhBfUUuPY2DA6/oFdel6WOGDQq7hK8LtsGihzDD4p0paHbZDPTkGv3AEWl/0jPX7fVllSlqRV/BMgIwyjYEEyU8eBYuXPB1oShogeXRLAGGWhkRrkIoPqIQ8TF21DTRMhTPMgkvysmtMiuP0+TjkECNzBAIUxWiUFjWiA2DgoIQ9GmjiNpGhGyoOJp0gU+HfROR8lLo357yMwIDqp8CduPuh//p4b4L1hyIDqIEOd6wwkUzVYlDgMYXDBEIQsEAAEkGDUpDgYiNUHQKqqDQUxtIVPZqyncidBmkOwiD3cf+D6KcbZq9KdggvMiiWEZRhVAVWCUSIy+lOnExpxkeXJKx1ekw/pr+HKCapXjxy50cvHJOUDigwPa0crlxy7qhQbmTqafupPNE/1KtQsio+gL11TtdCvbFxcjbLCM5lqNJSzqGhpY71sJzFSqtnYj+XawvdO93x0qQjPuma4jnp3UelTboVlQChAAAdh5pgPmJzAYpA5gQIAYiAocmJQKLBIwcBkRyQFIyAIAKUtgTJUisQuyoQhLmmD0PRoPE4mFpYpU8WyOTNXqNMxDEJy6ZU+fSocZVVIyptzT6OdSsqmJhaygEE6Ynwk0RlTCAwsQLFTKNGTlUyQwvNA0TiQCK1V9lXjCER6z8OQQxk3axw1sFF500yb73sbFMz4rF9hLSyDn0Tf+7SG3pHM8P+nJZ+Mxnv/xjz09DvtntADqAARgDqmeDAabFhhAOBAxcswgB2Whw9kKKqsyZzXwMBUdlzP+yRbq1YJrPZNORAtxtGX0zYW4M8cGINPtS53YTNR2BCUxMGLkEiboBEQg2Ym/AWIgwOoylFYorQuDapOwITLRNgHEpZU2wvMvEjMEEFDJM0VRyVTYdK0tXuCMuXg8xaCdxIoi/eDBjqpoccIy6Lm5CE1A/JvEr2kONHAd+Q/jWpMhnv/M0oVvH4DkABDVAABHoeGjOHKOizMx5MFUAEPMEGQtCoQHJyJIqct8hAuBWwLgiW2IkdxYRi//vURMoCJatf0cOPTFKwK/o4cSjMF619R409jwLJr+jhrDB4OIspPTFLYabwdZmsigRRB0yzSoSokexGjpIBVpaiMrrMLA+Fh1gcnSaldSu0M0UQkOFgtrCWwJJVEA4hXqkfm57DVd6cf2aoRxOl1864qE9WshTQH9tEho0wzW1WzSambySehaWVRoC1mJiS+5Uw5D9hzHJ+Bl7a9nTRkeFzJUk9OR1j+Vjm6pVKiJQWVKJk0gBDPpzGhyBaYAuQ7GC6zIMxxAI08ys5ZV7HMaanWyJPVlTEXAUi/7Xh5IwGC8fFl5OkJBOCcfyOOL5bV1LKAw3ghnpXiQXCrAnlmpUHynuL+WFuidwjCAvODonSvO5ElUrxMtbhV1fOX3T85US0WTc+Q0OOkMJlADfm6LHj/Lkj5vRQuTpDNt5Zzx+78SzWqYXKIdmHIHN9qVM5+VmlS4uqZ2UpT35mlJ036yqhswU4lQilCiACoDglUOeCzK2EkAxYcEi0xIAXgn0OjphokDgxCBAthcZUCUCaO57BhSjmSo+yM3L+uDXS6tVq4gtTiaMxbXbvDcfSdYC4RT4VbCtIw52xIQFBMf6AT6EIpURXFrYVE3s7IlWxUOSseOLY0OTf3+GRclI7gt0VGWGj2uSexMWbEQmFZzmyw2wecdwHq93z9jqopgV1oa4iues1Ias9T4rL8dFR7AsJicvF21KMwK5B41IhiHipkBYiA1N1kkcruOpLKH1AfQlNpYDYyAAHnIGnLHGWFUOawYhKBhQUUmZIAEKykUAIzigUv8oEVRznJ0xZl0Bp/sUm3SbHTz0Xaw3fKWLsadK4Bj/H1i1l7gWBg8BAiJ2Fg2jA4Rn5POkgIg8I1yxZYKEagrMqkqQnjqTNV89xvrigEgm0ONyka8k4emlx9x+KtJUa3/9DFRXEWyTZ/9pKtkcCb/wSS//NAA/9AJwomKCfsJIIQCGb7bkpQY2liElBJcZkSGmroErwhtMNCTExFPFFgtgtkSCJesEoi0pQNYOH//vUZM0ANmNgUuNvZHCcK7o4aSLKWdmDS429k8INo+j5tgqo2tw0bg82omKGnuxqNhRkGU/8KhXnqdKpYCCi7NyLTuVRHXD1UvewRorLJSVStzg1uN1NRzb3NGyOrn5AXT5T0cnvfx2ZkpIjlG0DynY8Ny6Q5lkbW5hfzQaK04YiSFpSovAiVTqBh4UmS3x/zs8pooWwFqj8d9acLrbLdefZtS0lwQRBUlxSVDfmiqHK9afCsGYxHEsnKJCBilHVqIQOjEQEAOmEgcPmMNxIBAYMMaQjz6k2tbMSCQCBFgCV6pNH5PB2G4xZZDvOQslcy+YIaq99FMM4HgPSuogEdYggaBpKGRkiZGEwcJnZS+86+XD7B4LwlWiKy86sdLjqB9mvs5MCq+ffvi+e976hhShR/6nIboGcP+CFI+n78M53/+Ig6gNISAQAABnQfJiA2b82mGMBo4WFGMysAMNOzGT0EDS7AIMJiA0FUuT0TdR2BYnS+KkV4fKQQoxi21NlHkyYy2xWNVXLg7dt8yJF+h6rUC0pnkNGDwbIRUfqoGowJS7ZMkpm4PzwxPUfriAXxyWPmUBy0RuhLR6nrCuWk+xq358zcnEk/JTRfIPrzor0NMOSQYpI0pjzamcottY99pRyZ1mI+uYn+5Jg9ZauaMeyKDaKJXHUcpicB6pvIkDomDzlMAsK/751ceLBTEHXQAQGY14cBCJmYGC07HSQYFEZMEzIAHNwuFlnTciFZBACIjC1BghihDW24q8YI05yVsOwy91GhqfgNpUmcBmLt6Z1wDoVpHIND+l1IsK8RZTHtYDM7PRBLCEObSoGhVkd7xMlxydhellZ/ejt0ZZWC3tIA+pHfuUdV1v+p/6P3iABRwAAAEYfQ4YFhYYkjaY3AyYVg4YYCiABUMHBRGALMDAdBYnjNyougqIQIIW3VVV+u1NtuSNCAZm6WzDYAe2QtJgdU6gz2wt+4NXYmLBLZbZyWiYWwB0hNCobJglIgA0C0Fh+BZUMUJQqLjJQOCUB//vUZN2CFktg0mNvY9CBpaoocyw+G12BRY7hicKXL6ghth9S0pnI+IZUGTxMFAl0JpaJbpTHY7K1ysiJ1z9PoYnAlhyYNaPBAgMkYgiSoJqmnlIcdkaA4fLpM6Wim6UvbQy2tj82LxFSupF+r7q4F2tfsj8fLo3FHFd7cMD1CVXUrSCp7x3FhKjTrt8rHT4EAgANcHjz58wpgMtHQqHgoNNCgEVRGWs4MFADHgNrJiIIWAdRIRB5d1lqXiligIEAoEZSsZvH8kcTa8wpu7QlKGzsDVhkr/tzjbauMwd0ZbA7Xc/ct2Q3Vj4yI68gHxOWkmpbHEkD0qUo2ztVEzar6wyir++rYj7fqwY2NQ3+h4iD7hIPnFBox6K431aNCA3zHqTGUHFc/N6Nv8cH1//b9JUvjhNdBulAAkgFQPXBGo1MooBGVICwU4oIyA7QsEvspavBU6CNob4tffRlj845wVDTTnUmX+0Kl1D6BYkXE4ibguhMPYJCMSJtHhOuQtMiZ65w3SCF9pjRw6PLuSQauTIIqrZhMmm0hnKSHVH/fbE4QUg0wrGFwtYSGiWoka/5mmJdDHJSQR2YMvz0fhPLxdE//pukjZqjJHD0FvZOSBdaefGTWUjHbOOOOAKaiQIKg2afJmjGw9MEuPsBhQ2Ju5cwENbghyS8B0VkLJWJIgsBwK7pyOAjLA8JSYs+hk0u0RIicm5XRIUxgV+VJcZP1Mt8knk7ahOwdXsc662hw2jr2P4xD8T0uP0ZXOzl+xi2O3bcvlLmDEUuetP6P3YhpjKeZWw2M52vWvhYmvtO/RVFvN0heTKJnebYW02WemTqc+X/3p106rAtOb7HBEAWAAAAOZwiYgOZhs0mTx0RD4AiUooHZ0nAMOARVCWKhiC7WscUGfhtVJu8ntFYDb5bMvXQsZ8fB6HQfALoZcAMXajJcD5dNwqKS8SjpDKrZbVmC1gJHQdfIq8zHSJBLZdXoZHUphAZcMC4eIkMydnS8dpEFDojLDat9f+VV3fUI5TJ//vUROWABS5gU9NYSXCirAp8bwwOF6mBRS5lhcMUsCfBzDE4YYVc5dKfFUndJ4dPp0VScxS2LF+n7jlc+afR2Z+Zz5Tx3vYxjmx6DyB21kvkoq2OkGzi+29m9CR9fRHqJ0bKUpm9whmLMMAEwSDAxCKWzREByqMe+iCYAt6rx+wVIOEwdUbBlmK2lmWjFrXdbRPNPpWG+1Nx2ts4ia8Wav7BDOIDFIFj8agDCoBj5ylBvchBKvKpKhBFJRpz1RXJw7l5ORQaqJLwxbKz2MLE4glJavWMExsrlYJnDkUmC/F69EVqL3iAVicSTlIYCDDmc2JzxAUF00b+FXSUpQKdZYSIK9ZRZ0ug1f46W5NC8v2vWvPTSn5F51D8zlk8RjViMq/AjQCWoQACAAk4ZBgC2SAlcyQbH4IOjyS1iw4uAQAHAAu6qainVFonKX9YG3i9XYiMW3BwKDw8A+rCIBkQHTIxDBojgsKlkKzcBVI6kpT0bm0kesEq0DSFE+SSxHmwg9VA+HOOZ1TEROqo5B6LEiExXYUJh5dKFkyaCV5JHE2exIRNZOppo3QbY/6x+Yvy5v/x1C8qcIn3+ljvlTc1Ld06ZFXnD+olmywAGb/sRzAOGVxWFwODk4YcChZkoBiAkOFBgACIbpgBwVXMXuQRM/gNqK530eBLigTrVY3BpjtQfA7zQPIJiIy6ebSDmNvk3AfxAIyg4EkrPlt9SPJ/Rtg/0xj8+WxsksvDWaHig/mh6e2J97tFsm8tmh7VYqZR3PIy+upRKadrjmofZbgZVkeb3SAWYUaaGl2iIB0U9EASJjE84h8OlLSlqo7j9dTcoK7HLuf9+3DdmM1cATr74/gTNATjOzA0g+BIQYQLAQhFA1PcWD26GGgS2Jx4EPEhUSB4BGg9ka8kAydbD2TK7ooCZtDbQWuP8qK28zV6ZwW+cKQrpdyw8NJC5yOREEQ6EZaaBIajwfk0kB2hoQhngYCEXTgrunURcEJauCMnFwPcXYI4+SQGkM+L6uoGjIkp//vURO4AZShe02t4SPKyy+oVcYbIWHGBPi2w2wMOL+ehx6bY3CscndfRU6HWzWOm9SBCjsyX2ZO3eZPVWqhP4Dk+BFgwCDjDC51kyLbDH6XJ9HnGOslRxMH3uWo/qPh0C5tDQKgmXKabQEJpg9AqHmOhA3oYHxYHBAWCgCR2EYFUtLmURUACHJ/WBK8RquPE6yaz/qBF72sohLDq0oOt45SkzPQwNkfYH1mOoq5E4qCSshjkpJ4aKeP44kgl1ap0M+EWTlZMpzN67Y3pkoHBx78EtELwaUEFEWA1IPCoH2ASFYuHw+GiQVsIxSjvT0LXmsPIkq1IRFm7IZS6N0YF0RwqknAfhRSaoVIupJ+yXJatSn4rS+rvSxYi1ZGu+4zYn3L+2E7mYQUwAAE0Zwk0lO0yrEQxCDgumIBLMVLMATBgII4BRGNN8AgOo0BTLEQqBWqvlACkujLPKqIGDoVAjFSzwSEKk4inTyQAbxlF1JkmzKOkpDzLwWIQFwGGC1LsjI6QLecJqIPcVLGYXhYW4BbQnEWWFVoM+HaAGgPUdaEqgyR/HulohbTFaHR4oerjIY3zAuT9jrMBkYGIv64qY6ESnC3n8/LeaO1Ku0jDUEJ/KtZXJ1TNSvsr6MzarlFNJLreWNRvkeoLSPoh2satfQtMkS8ZSq5c1bW9yWJ7KFEbeLaGKxjerM3hsEsUPAyjTZIBAAF5VbmUMBQoaACb80dy25ZIeHDgGWoooMFYlIpW0QjUBiPquqy6XQAUZDScVySFZqeIB2lCQpj+INUpFO1NBJMjEpEs0L8Go4MgQ2WkKrKVzzVPZbat7u80IZR67HET6mq0596Pod7dd7U+cd53lhaC6FrmoRmlCZCZvSTDowEKeaxEFlQbRPKxXAsClrcqSQMAeEAEALOJZ026VASODWw/DBSYfGJgIUhAVMJh8wCDRkDGFQurgSREEYUf0A4FC+4kluDx30ASYSdDlJNv7FlePQ4ENuw5cnzdpcb30z+OszlwInD76vPQVRKB//vUZOyABzZfzkO6eXKXixodaYqMGf2DPS5hK8H7ISexthaggLEImOBoCkj5C9A2aFniMQoDQFkyJISlg0FjTBJOIUPixohQqhikY1EF+uSj6cnMBUKs4QJHCVwsJ5kK4lrAyxRUHj8lFkMoGQakb34NkRAgmhGkY4NoGtVEw6jRhL0dEkeQIhlp8VBCHrNCcmUFyJ3sR70GgJzIEAFAICsOdU4mVAgiIxIaMaDwUuCwWDBEyIEMoXAdpOiJAsUbu/Lxs5WYni8jWmlKm7Stah5n4aBPYnlVh4JRtGfpViQ7QB4IxsjSRiQ42JC8kK1J0TxC98mF9errnyl2mwmSh3Kd+LDsOYxQn/xXrK5Ref+Uw///vIzvJAhYQAAABUMSTw5YgjEpgNGhxHYxYNjDICCgaAw4L6AWBK8WgApbAB4RQZPstgq53V3Ngg5KKNtEoGHtyiEusuHPu5G4PWrFZuQ3m8uTx4LQ1iKjKflc9L5lDl2i9ASfVLn1JuWytAvNF9XE777TySyFDRTBZTDKOmGbpVRTrb9YOWxI4uvEfLEL321R9BE03lsotvzzF7J/uonXWSyj6Znm4thtrS6Vsx+Ot/K0IcCe9MsIN0o7dA8zWaVmXgQAAARirABuQaBkiMw8nVGc3gGqMIANBGizAOBgoGVQ9Y2mYkcGHDRi30Z2sBUJnQYGJ2EkEW2eh5p8kRVjtSh5mMI6XdtYFATVHDnS9kTpaPhcpw7cmUo2y7chykOtSqONhrO5sS6tUy/NBXZ0vHRKj/ZmZRLmAsr9FTLmWBAu/cWX5fx4r6Iu8rUWadwjKzcO2WZXSTPn+PWAw3ozQJbQ97m3SHVln1//dw+bZhPu9xP1DfbFKiF3vXgO9wUK1JGBbO2AawABdN7AT1mg14PMYZjDgAHDZlgwNJhUAkvwqsQIIRizkz2eUgVDIIKYsplbdRRvqvX3lCNzoPfC2JU76qedaIMthqRR2G/w/FyAGx/ZUqJWGWLn1bduLDcBAQ4UnjumNUDSs8NU//vURPQCJehgTtOZYnDEK4mmdy8eVyF5OU3hicriryal3DC5K4vIZWyOB6FfC6225HHFSdamZ51OctQWk7f1Nnl1WiYtc+6dPretovpOmernEp72M9yGlTAu5ri1j91RH7ZmqUFZUZPyUqCc2fJWSvhjM6jBI4BAIAMZnzaadCmZIAiYFB4YHgkn2eNB4EQyy4XXJgc1kzZ1iNyVLBbrrYTKcm0pSzh0YswpBMeGw/nA8HoEA+SiwnAGQxHEEf3ADpWR1xedoKU+IRPfVMkRdeHCKJxR8THQ943KhdVllSeK2jpaKGkEvnadEyZL1QjWSPSXbfLqAaF1prJNcdht8uqaPQw/MrmPS+/SdXyVX2kfTXpQ0p0/XXFsH7MUcer46NPLvmCULXoatyzMzGb2AAIAAAGOpPwM8alMwlTMwghMXBADi6MORdMRRPMDBbFiQNfwbDOhI5aC3pslgIw2zwIMbZYKSZADgUNhU8lDcBOQtIAh064/WTmKyUjGEJqu3BQhISoUGlIGQN9bUcJAE4OcwkathemspyRktNYsSKM9Jr5d02M4yVpEqQvpc0uQBCXp1mYnR6yws7YqDsOclaHoaoqHUgY2j+JrL065Np/JI9orm3v3HaiW0mfcSJBM5D1wlTNcoGsoa4rg/oMZcx6lSiXGNRFuScSvfHSkVtTv4atgpM06RFSljonLBIrjn1uG/lcEPSDMrqnnGV2KysKTy1q7QNSsAEAgjH3BBuAWgAc4NMGSF2wUXL3EwdaMgYcutozlRKaeRnb+xVeUbScvAdFetDaIhIxAGCfpCoIFXMGAZJzRzf5sRWD2xYXmKjTXMfNSkgkuZJZCMVOD5A3mm6FOfi6YjZeIl1QRaroQUAw0OFEHDg6gdbUfQ/5RpjxL90lLDra7UCFrAASCUqfr3Z0ltmQhOZMEJg4gQAIw6YHAxi8OGDg6BA4PA06gCGtSuDT0aUArFSwR5JaX5Wwq5sBMB43+YTLHyvQmD4zJL1BORd22dWoLgekZyvmc//vUZOiAB7Ngysu5enCEiPnKaSWcGwGBNU5hi8GyIee1xgnwvw+KzsS+OVwknB45DCyXESE9Aq0RjxO1JDTnxUuZOlQtonjcRrGBXZOXVZIJawvnxeLyCSSXQ0J60mN4HxiJDx6WGoBONGSUW6zlExxAan64+RoZkX/WIaXqtFjiVsnDzJtds3+GFscwR90DdAIloqFdwCwEG4SuderLJIGsUqEMmgdZgogJMgEYwfRTGxrHiqFgCY4FgBFKH08YXCw0DnJZZJpY+kVZ+yMZJlihswNTt92JHCnuSrGxhAfvRIZALx0hnw/7MU4lS/T/L45gUHK46UABGU3MaRHcqq33iP/+bczLdat/0H6P/3affXUDAAABNb49gx8SEjwJjMQlkAGEx4EjduNHwCLGPOQtGZkYyAMCZOTQK7GATRDLllQEwwk6QYqW6WKwZJ4oFXI4D9KBrfL8l7GG0Utj0gWGQVSSdIZEflTRHZlrAJa7DiwXDdWpHo4ytuDI27qIOhPtIbirWpzBjNW+hUkZe1NUduQuSqrGGCuTKm7smeh+6JyXVgiG4edp7X5atehibxmXNbtDUxAennkz2OHbaFDL2N5Foi707ppsVrw+7ciarfh6zTQc79LDdHjDMcgO98flOMrhm/q44NmFXYAt1Y3Xu4v7I9wRUtN87kD516l/CZosJmWy14sLIAZhAAPOYQy2pjM6sMZEwysNQgHGNgkFw8AhADQqYmCxhYIqgIQCKgZJ1FRiKEEBQ+lQ2lFIVcI5Pq3jxByM2SCHAzFYAQlsAREI2QUQpBUbH4SusFQxojOx7HpWnAMDB0yHFWBk/RRZ23bfwR2mq5Rqd+fPOmtQi3ECNqd5qCY5A7Ex/3Q6dEeLfQet3Uc/IN2+sVBpcrEGXwOwYYIfZgOgZGDIAYRAxGAiAyEAmmc+cl5gIDRxhLhBBfsFBDAQMBbq1swymfA5ZXYCIBQbOQaCSBpjrYHhi3yibFRIMP5UPSfmCGITpBnO5D3BuFiK1KkODPbj//vUZPaDB7tfSkPcyBCTKPlUcYWqHXV7KK9l58pFKycxphowTH1Y5C4F6SipICJkOKxVJ1RqMgcI6FSYrtwqrVeaR8tBPlGZyQL89MBMKBtQ45kynTTH4mDpfnlGTplIcfRywELQ5gfvlM7UUj+RFHy/Q+dnjH6ouwnKwMzfGs1tzGhNzub1crryRsn/D2wWz90VsSC8hRGfpSGhrtQv06hTgn1rL/M9GvvDly0BM66gq6R88qpEwwJdSk8BwBMx14DUb6rlCwwcEjQ5EB3BGHJQ8CShzlxTKwSBAoMxaNY6lsKnToQR5SPV4lnAkPtCC4lUPHYdpnPL9zpZVrCwaHig4WMRRVO16y2H1zFZ2c7oUZ/Gc/6ZPju3874ejN3tmw6etFQ/hBnaDMzlh9PIHEMb8snedrb8pBD/lWhEagZ7BBJKJcMzbs20VQhChwjAsCM4ikURS2QADrAqNHmQpmvQmemSLkZKB4GI/tEgoC1VAgl0RTZmA5TjyYndEGrypKeJsoewH5LYT2N76yn+tUKyEuuV7MidrjMbmIy3XarmG0qBQ+hWL+KqK1IY2jt2K0z9rW/kzMdqL3mW5msVrNW5TzXHsMEPu1W1rL9YXXWHawavdZixkfWYFGFt12zxu79delbK7EpzQDdQBUBsQTiRToAAba8BhD3wdpMgcIX8BBkVUd4ZLsr9UagKin1bsnja8x0rHykeh0F46jypVEyJYRSKciqM3Px7QDh61nSoN20hstJZTdZOUqOrFYqm6RlMrPGXFzmUQtuydws0+7Rzm4lWrG/vVpS1m1gRs5jJjOw3WrdStHULNejykyoxq8ENqVpbL/NeWJmo5fj+j+P/SiiqAP0TXobt2dXStldqUxxYcAAmOg0HsI2KZzMJhhkwYHQLwvemoOQCrE8kUggzF31buo8lUzWQF6i70Xa8ky7DcoNhQaAWJYZjQaRhGAoqmD4dAxHo/VYmBNEvLZHHgul9YOyU5QhBHXGYzU1XOtmpktMisuWoRT4+jZOr//vUROCABVRezdOYYNCqS9mZdwweVz13Kq5hhcLYruXxx6XoHjERUhH89SJVhyuMNedWOPoB3EgHOK1lIWVyEvUHKk5gTHBy3EwzCzt17Dx8veOHImv+keO67euQ0c7XJX6dOHL7OdajJ2/t3JnZlnDggBkDABEFzXg5OGicABYaJZhQDlYABQ1LjiQYKgAFhIAAGiOmsimreha9Qjp1oYXw3nSsQiKXZT0Lka0FB5ScimJE+UChZ1TOW89J1Oh7pSWE8CqcwrpDSQBRckLsixC40YHSdfCVCbIyc9iayE+mWTxBM8rU2JkKk2VGzKODLGWjkjLWFlFGnNklCZtglSS7PhNZEsjOeotbWNpZbtJMU7vtdAcEuCy6MkdMjMP5UG0flO8Q2HIChAAAAIlcZ8tnG4CyZeHJicLGNhkFASHCwqhQkFFHlTfRJEYlHm4JqqkSAgyIJ7ucyGHpOwZyXAnn0gaaflepKgmCYByUYYDYJKhQlISceHChokMNRYgIiIsmZUQClCNQMIEK5kUyaVISVUpR6LSJchE1EokEygJILNMrPaZ6AqKWyJYNERNiPUe8TUrKKE+Toq1WShzpj1ep9aMpJLYvhy5zuEVupMT6qmTh/IhVcMN2fLqRRVULzedAaUAAADFnWfJLxkYpGbAmZSAjgmEncmSKBAUVpLvHiNwL/qUOxEIKSKlMrhhZoHgbC5EI5HXE44JhIBqCA/r0BAOKL0xuSTFOSyEGJUOlxg7CbcUTZYcna8pGB5CoPn1h0VWvTNIR2dHCZrLI0iGWIki8pLrazDf1DbeUeRsF/G4lDLC1fPOZV2G3LWbM3rSHHGjpr24oXrWYvfutVFM31bN4DhBOkiGXcTxIR/5fSLoOTUgpOPy2IA03ZTop2NFg0x+XzHoTMWAAGgYAgAfQkoDXIBzdMdKX4TMChC24Oimc8rR1koAUwy6NKr1ezBZUkBEca7oCQVwbgCF81A4NQkEo8YE0URKA5L5sSE4JDjEZj0MI1/HMZoVCSE/X//vUROwDBdJgSsuYSfC3rAlpcwweGAWDJq5hh8LkMCVpzTA4NzFWdeZHnqUTxhEYnKho+Tqj5SZSpHgs7dQu8suKCVVCZyUfrTj6M/2JHYSkOS6cZp8JWv7L8TFZZOnXXrIoefjrMDbiWH9dPZcLa1+ZhYvFFj9eS0b9XaWPDFQAAEAEwws7zrZONFfD1BjwJhYA8mU6ChVWIKhlQI0ioGMv6iA9iXsjgACYXnIkD4JjI8CSVx9JgBT8ohPYrkpaStOnmyfqGVj2Ba8YphrOTNYJRWYRRLD4lkyLYCbJYbOnPQzqjULjjZyytjgsvegaX1gWoaJYfyvrE7VRtapTM5W5hTwm4kWLHbmX817mxNvV51VXIWW3bOeZPZZ7stRc9PD2euoQ1IuZ1g6TmrihfzkMDfnCrkIEGAEAEswkq8x6AUGAIYliAYIgeYHAUAgIbkHafhsIhWjYiksVWlylNwwUGI1qUxFcjWVYF35vm2J76CVPy6s8QE4PtCsTkYSJdwnsyM5xTZC2yZpQor2VyU49gjLNqmFmlfBumEFMGi7ikWu2IWnhETVaUyyGRCmnBdWMIR3fbRieeWsVHw/K6lLLtQjMw6LY+pOG8Zl+cbgfV2JVvioikS6lOeZyE/e/1MUzaBChIAAoI2ZBv5uc6GPhsYSCy0AaEAqAwAGi2YOEogBLVYQ4CmzV81YX/gZiVPByxniLQ4kAcgHCEY0OwpXFUekMlmLzi86L57BESiSkLLlj5U/vq65Y+dPRCq6PrusXIr9/NkJrpcOD1LFlEXFaI3kERt7Ao1xWpteMYhjt2BQonTJsaaK7Z1oweQDYNHJfAaF1RLH0D84+mZg/gesRFUS4lz9UwoO9VTMDLDoTABEApU64qOsTTGmNP80IWLAeMB7QCsMDBQQhwwDjwS+TOhzD9D+HKIGLaoSc3LgqxVGOl11MW9ZVj6PGTKeOsmKGbXRYU8qHqqUyGZViIcKnjLZoobUUSNymPLqCR2sNI5as6m6IZo5KmkUG9snM//vUROSABWZfSsu4SfKrC9lccYacFxGBKU29LYLSMCUpvDB4HVlTBVk+ImTCtxqCLKIFFj6sUJpAfgjJlJFTygeH4Xqw7j1d1WSFleN4V+e9c0vvZEoaNCYMoTKl3MwBw2usEkOsECm2imfB50ABEAJQH5hubKZLEmWE52kWaQGkkzJZAAAYIdSuaAdHxYRe6AJs7wsfaWumKNnJByRx2MUEuADADIyyyTT4rJSfUciKtEhh5o5ViEJ8ECeE7kOLp3tpdtDOoIEJGtY8ySqWXjvFaxqzK6Jl9Ihsf6G/E6qjcTMsMXy77j605rFAn73lbLJ9EtgUwJV6S+4rgeh95bbqtszO2mb3rHDaOJ0+eMotWxUrMSEXf02OfpSndtUGAFIJAAAAEZt7EZapgYdE0ShWYeB6IAfMSiCMJDVPgBg4Z4beAMGRI1QEtQPJgSB7MEloiot4ez0MwPwNQhK4XR/kGCMMCqJMcx0s4pp4jdHi9KV4n0woDoaD8Ykk9VnVSSlPJsO1aPBWrZvvm2IqDeY29WHKqCWq5xULSulErnrw8GBQNjIgVy8SCuStlG9Z0+3rpwUuqqR939U+v10dKokacNy4VvrDfumnUOaKqocWZaX87x7rG1zW++37a5X2oM8VMrmC+SMQ6nmuxH9K5WX01WMyP3lL5Vrv/+oAUggAAgY+4pyoOmNxQBScYmBaE8wefioezAAdAQhEaAnYCEaVs4jbYC/xRdQJEV1IS280ydNZZiQbOWte67gNGfikiqxo7JXElzdQfCAdTA468gsmsGpAgKyZUIDyEXUHQN0ovHY2WXYIi60VTDajSGSiEr0JVlD9aZQsyqtncfngqKWWEJmtuJ86+P8t6yJaLEhddtswXs9lV6Pd7ADQACYoyHBkfhVEQQg4AMFby+JqhkEwskMoARoCuiI1rLBA4VSaEaQRdIagAwzM03U+0qEAVBeAdxNS9Pywn6pyjZztOtHiqPdWJkuqYORPE5PxULxY1MrDLYWpCy8GqmIq5Ty7//vUZPACJuhgR+O4ebCeCIj7cwlOGul9Hw9l48JxHyOhzLx42csB6l0NMlFwVwqHdlMxqVS0UspuJuA3WNFVKI+WR6r6LtTR05HORIvT/gv3jC4qNGNkZrblK4LLk5QGthgMc6ob2eZifLlZhyqBviuKk326HJJCcXre1r9PCzhMxmVyYWx+zbpd00w1itvKx31TDubSAiQAAZAgRxINhcdGZD6f5hjBkphu1GECdkoQqGPiQjFG7J5t3VhRrWMgPchQ1dzWgWydOkTVBISYSGC5CxFkW1tJMb65SReDbQgb7JAMQ8llkU7ioHZ0LpdphXzNCZXB0mVGL0sxp4Di57xr/wdybkm1Ej+0bNYVd4q8vSPq8Te///j4/9H/kYjiG2u/RTmbUeUsMUUK7bsbbTph+gCcCAAAgDGtvKG3oGGHhEhxemN4WgALQEDxgwD5gsBhg4EAUSIxKLDxyyLvkrUT1gGslpVSueXXdmQQ8paz2TRNTtqyglRrt51YyzCFONEoaIY0EYRR5IhqIwIgEbHQxQhGMxwAI6vYE2RFTlNQIZ6kLi8riUcWMS+PJfOycSztwdEMml8bLETqHGSDc9t64uK1R+UCsdySkiZMJbiB0B4XS8vPGHx+O6nHoH+Xjt6sSkyQljqo0OT04VHJlrunnFmJckZJJVaEmpXgfL6VSVUp5fkrKpLY/Ktm1hv//6gWAAAA01XMKNTnD4xwpM9UQU6mBAQEC0IDGAovY3BCYXPe9YNrKkAyyuOBiDgLiRpdIeXwpUSiCQtq4Y21fPc5CWKofz14GggsQqkyJYiIEfRFA2DZgndVhJdpEw3CTu092/y2fkblVe4qKEXtrOvNeKBQt/bq67E66/sauY8n/dL69QAGBYAQAGhWDNT5hCimNCJlIiYGBg4XLfyQREYhgooUXixiCSgSGUVLZKGseeaFsBU1aY0mBpFONxa+6rCYyi6iH4J2gEoo0RaH5oB4VHqJE2apT1F60hlCy0c0RTPjUv+xwjVSMro2y9DY//vUZOaAdvZfx+O4YnCDZfj4bel4GcWBIY3hiYKBuuMht5X4vonTkvPGJ2oWmT8JJPithmwXHNqtXPG0HQq4sLZ0f1XRNn7rKRMbR0XSbnSmqQ8ID54ZD8SXFqVS7XUaC0W01ew/XIB6eFeCxSgXJMelk4etlUUHo132rzLuiPTqs00IYTE6wBzbOADXQQlmClZj5WAAwx0DGiMHDJnAwDAEdJDAw1VyNpaNQZK8FMBGaimKwDSFCVqPNATAxkqQpbcxdidKslw32VOoepCFG0hlyBLpxGKwttnqbLKMmzJMk7IywwoxziR7qd3q3cZGrziodHBRFGrURCZrZGtqdmGi7jSN7R7EavEGcarlbpfst/SbTt5Edp9a2+jKTb5MV///2jaJx60CAAGNsUZ3KBgMUmBB4Bg2mAYKDyPAFExYCYUCKgBEPAuCkNxEAU0U0X9TbRReVQJNV5y1jOnkZtHlh2csCacxpdtCo076m8jZ3WfAYmY8kYdGl5WMNWnJZQTKgkBOkPTpajMrSvKp5gnN6PyQ6ODdDUN2eLLKlKfuoi12FvajieqWTo61hgdl6ZlZeGV9ltXW41BVaevlL2P7fMb9YOTlPm9kIOp5Pzl2XUzxv3vdP2K7ACIQyTGLs+2oIYY+GAECAAA0pKDUTCM3hkxmIhYrhwJAQVARJAgBBoJHASJBFZIMBw8A2zo2yBzaFP1OFqCZryrUaG7jqr6YIwyHIU9Tgw+/02xmmfd2XgIMJWJR8dReBInHK1mNY0NWKnz61cWMDiJMUZ0Uz4tJjJI0tPVMZfPWGZ1SYiUR0jbjpZPTFE0ZTG4O0bsJxS3P0DlEWUECQQ6y9wlH3NmDsyU8N5WQBb5Lj8mbX+DS4bPVKEALCQ6OiloFU+ti6jT9Y0XZSAKwQAVpm81rQ4HYwJcZMllQuBMOdCB4KCogIcEBJcQJtUlmaJcxcD+PoxDRy+MlmnUcBTGi8Ti6nfJxiVr4+T9YAQMm0bwsP3It4GkKA43FVknRMao97EZp//vUROwABfhYxquMNlC/qmjYcYbIFKF3JY09K4KgLePlxhpgItUbMkCVH0KFGjmYe5aBM3y8J0kevuvstt038cgfqqq8lI9FW+VsM5b27ZVx64jtPFMjKMUc6v1lfaqcZbcfn2Hyt2UrbxYV2fK/UHegAIISabY5zxAAoekRsBATCwBFQaYJBogDZKCwIBizzW1HU85DArCGGOW4rNXtcSdA4dkAGpIWhEPY4IJKFydaWU5iII4EiJNdCJRX1miKq4/T+yu4nrMpFElCbWEHTpIw0IfCUERAZWpYPBnQMc860ET7ghdrokj0yOGDhpUI3RTbmeUGKZgHMAtyXy5u9fD0kf3mf9aryv/n+w6qlKmCV7W///U8ygSUAAACDZEwK1JwBUDm1pZiYWZQYwUygdHJooG1csAIgV6UEiOdE3aGWysvglQBOOVs3dZoKYLNWmu47Tgw3K30gtcOVZtScJD8Sd+Sw6clKsV419uXKaZ40LSYQxyXOFtUmSrUNY3V5uDnm2sYuJSIyb5c8oqseiXK5PvPZUZr3PGVILHUK2LYr5PtL7W2xgf66aPpr+WoYkrvMNdLLdPmWs2NLrY26ybswSCH0AY8XDT0oTCqrGEwkAAbwwpvbFmQkuaCC5hUJGGQUY4DIsORkCBQALtAwFpyoAEQm5s6b0ODa5gqAJUgJYSpqgJZ+/0AsEdVyou/DDI878CLJg9+Xjib8UNO5EepXphmXr3Kps6YIxrNmC2mLZ0vsaDoRFR2lbEgRUx4UphOEMXHaRtJAMlI9VEu7I5H5LKozwzMTgSTkmqYbqThUdtkw7LAlLLlQhDzUezBzp22Lno7uwvsIV84vwcmy2JenYZn9n8fjTP1GaL2AmLKGIV/t0O8uAMABr+KnbAibAB4VChkcHJHICzAAREg2OBNAsAgNI5MNf5elYZx1WKIkRAkgnNMQ9TeqCZnY8OZQqc+4C7TpITV2qkGxp1UsaQX0m+UIkJSI+nFDEPMpE2CIa6a9IizRZVqOM0KtlJC//vURPQDJcRexktsFmDHK4ilcYPaFp07GQ49L0q6qGMhzLA49A5AWRTtZlZrR17cyjaiNtQq1NhSyIhm05RZ2JEeRh4Lr7isFAsO6VKsl4jD1EvBXF1wwPrLDef/69eWjWSD/a3V+E/+3cEnE3toqIApYARm1Uk8ZBaRouEhqqo4UJOmGWaIae4sWm6DR6ZYVZq7lyLqZmAoBBgAomh6WS8PKowE4KbD+Og6A3GmNmOhlxNuXCacoly9CiXUJxk06PJesbHSheelQgoy8t6y52/VWSSSS0ljPWYKP6tadacZedtHryzcaOViv7U9dDuOsFh9SdLvmm4tv9FlqvPMXbipK5vm7ds72xoBy9FYKvQAiwoEACaPIb0CXQKVdkrVDIEAJQEOXKQ2QTDRgcMDAkwSIQMXhYDjQZaCAACnwFAKXhcJVVhqh6xXCkig6mivJc7q7l4vw5sbbp2++zDuMDk1xutHDnIsYrBed1VoJIOgfJPmj8MA9S0Ydixg4Wq0yck5ct3boTksM12BpBeWS7C1VK1RZx2CdIGiZYijaEnJa005yjTxk70TGZRiRRQ4uWubOskkcXuzm/b+x991Hf2j+/bK/rc2ynlBBeFdjGPetISeFI6IXioAI55XD+BsNADkyoJzEwdGhMJAVLIAgEqg0FBBiCVSnKyp1cKykSl6M/ZoVgB/JAj0xN4XIlxGGrAIk61A5BedBwwJw+qR0cGFoRBZOSzBdDRqysTxHBuPiXUT6VAK69K7i1g9TEJScsIbpPHI0stZfcSNNHI4q1ilwpy8Z5S+P9A/UgaAEHOGogIxIJOYgjajkqL0tENAEfbGfLpIhhv2VjqP0+mj9v3/L1xMKgcWD4q2tJOh2QobB/HBgBkEAkQQ3PKjawTNBlkw6LAMOhEFDAwBEQHLzDwTGAKkcVgZSqBkUHGZy6bIHmZA8qzn5EYkj8P4fHB0PYG1rrJUH173CrQ0AcUyOOSPGxOXPn9lh8mLzqha1kZVuufJ0MK6mtPiWuP44DaD//vURPAAJb9fRcuMNjC8qyiVcYasFp2lFy4wc8LGqWLxxhroz1tpqXbHNZ5m8cbjSe9HHlPNVrUFUZwgsEFGi+ZQEHAiIhQaiqpiaRD40EORITFCR+D8q3fmd2zmxr3U4X/5JYdg4bz+TJIHg6AXEUAAIN+twBxUwiP0vQwjN0MEBcKCcvcOgUwOCWyVFyIax5Q1OWjnW1j7LVrNtK6VqNE+a0oecBx7stLSpeMxEL5CXOrjBEVkj6GoSNNsVTWODxStu3S6UgmMDR1VHR1pf9H5UxKYpVsvxwpb+bJKXhlnDyOFdCztl37RPk+UVAKogLogi92evmglYmYTKdiZgd0S04ialLIN0mtxE2WBAOHZZM47WKjHioXqNSrCj5YN1QAUEgxLqzUxtM4iQwcFTCQDMEAQkIY0AZJjk46SIswtzI9rofVRxX0PKdQqecN5HKcJm8eSqFQvD8tcOx+PapYdmBeTmLo8oqIaZlO00Vrur4kOjLOvrGYrNVqlOq1s63A9jRl/Qc9A5WqqsK3deaUQrT1xtw/Zdq6zA07toLUosx6O+3rNbPwJ120KrMdENpqaZ0357qzdbdylvmtrZA8IjXIRS4qydHG0UpW1dglQMNqJAOwAURgPTpmwUZjGCpIFJMN5gcCA8FzcyYFiEAhwABkCgwAUJ6hSwz+qXQKt58WdM2TCcDSpmGLXe5+YxInadODXC7II1KvYC7IEm2wuDC4LCs97XXRhhnkQXLNuUNAdZKYHWTB8kFCGDdRPOFREgFmEZVI8hxtG2KWiAuhYZJYpZqyGMVCGjSjaI3U0Zha7RKtTkzFdWLFCFfH0rCXQXDG/Xy6uUKh0ikQEa2MwrVh2dFavyN2VehPs78WeQQC0IAMiocktnOwJtyIaSEDIAYyMDggYMAigUkEYCFsfEYGvdtpxAiwHiaRjwFYji3kHRxQqdTvpSqLyzsR4KRcUclE4TB4bsKlSdcSIwwDINtCIcxdz2zZlOzYgJpkwhcfYUJJPQxTR0XsljNC6//vURPCABalXRcuYYXC+ThiYdSLMFr1lFS29LULXuaJhthphamLPLkPLeTy1GFt1ZhKsiJe+CUViWcK7KaxtyrmW0cUE4onzYV7MW1H4xP3nhCe763Y3U881XDVOB0LkNpWfFU7J4zFqVhpLRltAAA9yCKouYSEmblQBAzEyIEAqQrQkiGsigCuUt+2qdsvdmNxpgsmZK12BCiSol6EAeJAt4lHbpUK5yOSM+OrpRJUYuqvMR8fctCYnZzeMPBHpmBWk06HjDIJyWEIpn82tCSfNa9FETYIJVZR5pJJIDQOyZIdBmEGE0MSKTSdBUuTsw4kyHSPMNiUVtczv1X+s2rOS7omXl9H/ztfOjves7pPnOVlQW/bnRmf/fLe8+3l4Y4kqAIIASjE6CDRUajKIIwUDIABUIBFe4qD5gcAosDI6BC1EOt1caxUOc0whcktWDb6Ju087BoAX5Dri0DhR6npXcksafR+4zF3+ZTB88jWmQikRox4CtgZCBUQiBAU3INRaTIySDVLOPk9sJa0ti/QFTkyWGipgTxdJGWPHWl0U4KqLXVNC+ls8W+3FDeqx3X5ulzOQUyoW+aTC0YqTjauSsitKGZ0FXQdb7KZzsdkJ9GrR/sNQZetuD4KEAAEYSxMaYiYYfAsYCAmRA8lau1GVmDwpoJwugW9WIsejYiv9g61XXhyVzbiNEnHrkMed+tE5O/M3hD9JbeGpR0IB9zIJGokKqNZEFGsuYZECcTjjuNSR4MJniQqh2kj5sliXOFkZGtAUs4lSJRpiuzjdeTE8RKnGHG4c2zlINfDok1NiUXf7mXzFMS2LSfjKVy7Ml1U0YleWfPdBZlxwSCboHMzMrpVpsSlNoe/KoklMOBr4r3gpEAEqgHh1Oga+inQm4OrjHgZqZi4EMABMPp3psLEEYE+zOGyKYNgj7KbycsQxbq2zk0j5UTRCnbZc1EToirBNo4Gk1z1IlicqYR+OTbQFxqjEoPLKNFjzmzKIYQIBsVSZc66bJ0cDySMgNoK7//vURO6ABcFqxEOpFmC5zqiIdSPMFl3REQ2kdcrlOqIhtJroGvMzLJCZjoVY5nMtlEnkSrEENKzgwSqr78huLE+ESVQdRQs3EMaOuDvyrx127EixabNJvQb0mzFHBCSvDohXWupbugufQMw8GvUCeNjqiBLMRQQctAAOKwAwsGVuCgDVC4Q3hgAUkKwV0oeRMdZ12USmJutHp2AITL31dS9MTsCPCeUC5AshDCAmODhG+R4miTIjsEl4H1sagpj2F/jETgrUMQIg+2HzbCCP5hpHsSmODKJEblUWXsMrL7quauRxbFFAgjQCfheo8nRgSXzemc6KoI7j8uJnPKSr7lM+tuTXre/zIzzsS3/7pl99eEP3xc/lk22LNzjy+9vEMa/nmYgAoOIAJdNBg/eYQWGfigKJDCQIHC4NAgqBqnTKMRBXRJgUKBKVkCcMyupA664Zg1LaYxUqtFaYyRKtcXQNrF62MPqG75unoTShzD6nYUuPNiJJEsCstkSIgiTJd3J6tRLUpPDIkUIeIc6tLZH7BTLS7JFmlYkwQSm9Whpntj8Jgu7qM0jCvH7yTfKk5pQdoj551/+8+a1mfM3db/t4J1r3pTTT9jtbOvb2d/L2t621QJVEGQQDUdk7kcMxDDEREMIEKjFQpf1lOpf8aWi1BHxUDXmfTMoXqfEYD4cm6VxkdyqSRifA298pAKciJVTl4/MjMrIzMxOCnG093ITVmirFVd0GxQvKlzK1FCXYrM0k6actHkK7qkRgRCZNEOONMw848xApmBnLV/MjO5ukNyKb2kC5Xfbmd3vUvjU3eMSfyV8a23dRj83z/hF2zc1sq+vloHon6M9L5H4WVajtmCjNa/qRBcJ6hACRACQZsQZzEkmHBADhQXdh4waETAwDFgYz9AEmcji0pazkqWqrOS6TRXCpnQX4SiOdHwueWk4jmJmHowQyuuXrMunovddP1yZGWY0rpPUoJil7UDnIEQgKPcJuMOKF7Z5GkMZC4kkkxuuDDTyxS6xjnosH//vURO2ABXpyRWNsM3K37rh5bYaOF0HVDQ4w0wrhuiFVxhopTVrybDzuUCwpTpaOL9HNKNgevEHvmZnSi8vaRxT7rSfcFPD6f1+EL5CiOHH+E0c8geloDANrK//5VmgLwut/Laf3S/ZNVJGAANoDg/WATLBYHieEDEtRA6RMUdlhyVxUBLWFBFOmeyFIGKv+XwROBQBo7OR8JSEBwzCIQT9S+VwbqhxPScWjJyl5VLlxVWulNpU4zC1bIHEkwK0hTUBpqMjSkgROECQxGummQhUoDTUDnNnOBL049NGXRY8pEpUmh0dQJkQxdsQckMlJcGSVGXGXiWctkmmDUueCbvOM9wnzCiCGd6xoOYS7R/37fBABTf/uU39qd/9T2vrVaa2qAGZEsDI1OOQioy6AzBY0KBazBM6nYUj0HAVC5cyh6Cyg7IW/ljKo6+zkwIvmNTs9BMpdhm0rs0MTm5I8srqawuP3RxG3E9RGvLJVa7Uku6CYkfLZp5EHROMowEIEB3C1GgMrUQO2OIjQuAilkUHKMVjInkS0TqRc0Hva2zpWUQNE4DV13R6SBe6hSXNKYgY3QjsV3RnTdROD+imgMa5zR0+MYsqWW4NyGUt/MKSsyNG/y48e3s9wBtStfQ5WigAtIALKBjOvG6SgYnDwqKlttAWni+i5lMXobfYkFmfKaIrrEgaBR+TEMOgLUIBVEkoMNNHradx1MSaVODNMuO+6qGqdk4VmhdL5wZxPudRcnxcspLztVDbY6rfWqh5bPIU+6ZTRptjkEj7tixe5Ol5oLFabkSQTIEy5pkl5q6Igv7bmFXFS7btdrW8w0EN1m5QSePlj6QWg+15ykqx2bcfoQ5KFJ1nW8J60lGkHZZ21cwQcgagACwAqyAYblhuMeGDw2LC4MAj2NBUXVuclTRAUIwHByxSDMIXzYix6VeysxNnzYitoSe7k9VtoqlT68csZR0RS6+BdhEh6xFcES7vZLeq4gmiR5ZE1TBxJCVJZG0IgNnkYlQzTgmQppanD//vURO6ARfFzQsOGR1K1DohpcYaOF3HNCy49LUq1uqGZtJopqqTrVSBD6iosrJFC5XcKh9hqqmxUxdamsZ9SppN/jcFNvzp8E5o6YqKBiBtacN6/qMPBbLvrM3Vl3+/HWW0tXqVzqqQCQ/upzRVZOk6PTL8goakqgAYuO9RDIyks8GFK9kcUjnQhxhCAp2W9ZMvtykBTo5MxB2zIqIA2Th5cMkfD4XQCNxGfI5n2yIm4aITTJpg1aBojSGV2VZNJsoGoo2cRIrtxooFDA4jCaInQqtOhKgaU0025Iib9aPUbLFf3JLxtdk/dRtQmlGOVrcTvU+18VZnjX+oo7GPT7a222ZOMlf8FYf+VDZId+N088tda2+pNurws6hD5IJ15sB8pA1IoAAV0HCEuNG4OChiem6rt0ErmYI/066oBaasJFFVJR8MuzTPVAxdwWDQAxIEVAwGTAWQmBAWAsUsIzZGsbTQGuggbJ1pGA+3qCEWVU7SPkcCN79r5GGMJFJVFNN605VHY5N21UF5wVbqNsdIts/P5Uon89vTZizyStpicV3pauWzLu14MQZMFHsIbZYjN2naTTVSWjOXIB9yUdQyX0sV/uep+02GNSUaWiz8ukzvUQoWS2RmorbjjqfA1L8M2KDNw4eJWwpnCcINfHaYaVVwtK6Vk6rJcqE8gx+HAr37tOqwypGw0GiWRMjFhQbQrJkAWOJGydl5klguJ29QKGpEpZ7mVMJdgYtNdiaBlgo1BYmXBXWCpFNWU9S16dQlLJz23x5xLIXTOKze6pPh0EevirLUtLwb7adWxKPiis6ouZhNimn+iVBzsZIXb2CR8sOl4wTg7xmUJ96xZiP8SSZJtz87wdv2qJOoKTckxbY/4HpzcQ9GTCaQzRfMzRiYkQPCBteUFJfJwJm3LkmaUm6xGA36aCwF8oXEnybyHrNPL3/wfrOGpRLcYTjLOz0ZgJ/aS1qiznr91+3tlEbzsSChmZI0EogiClajYNhH+ohJGMPLs+exrRtrl7LJb//vURO6BFdZ2QjOYSPC5LshBbekuFynVCM2ZPUrOOuFlthootFFxFPuSbJ9nx5tI9mxthVRR0aYsymOfFXSxqPVz0m5VMOjsKNY4ngUrBFZeTIo/orNNvp2Z13Y3zlbR9WCOFDqNyOOPYobUQ5LEzjDBHEaKCqdXGR6xnrSYkGGBCKAweC5Wpk569VAGTRNyGVPAz95Vfv5UfI6ceSKDYiC0Ac8WMMksrEWycfoKn6ttg/RH6Z9esKo/mrKBeW1rjykHpEpJRNEInkMMQIXBNQhkG4eJF7tRca0M+QXrLjP+Pw5rMxvU6vCDv9gq9LqbuylSjDLejAa0qKKJ6zH3/jfFAf6TX5ik4bT3VR0DOBKoMTNglzURw7DFJVpkMf5QTOJlsfDQyEUH7coAYcmBokGGGB2LCgZAjDGTS224iikpM0wSBzpyV6LxyA1BCccVUQkYmKBi4dPKT45MC2MVTMaYliemIK9YNoYDgaIGWkPq6w1RzUfp26yR1x16zabCj7z5WvJne6xbIx9O5fb9ovVf/LT/b4V53WNf5TQkWvyZiVIbuJRhpA/mWYQIRWMb9lZxXiKvuk6tLJocK1fLRLUYu3Q3FqYsiR7okRxuLOvBGiEByygBiKYG2y4ZWCg8T0CnXWWwwPiYRwoLpRIRCM1BfMyaDIGRmsZbFRQMQLCAhuQ0w2KaZc0WtSJmSBPnGBghMsNIomid05/438YZZTblyIuiUuWqRTezIhpi1W0OTup7H33XSUJe/BPf1UKVzkvkoxhF86ja/UdsV6eTIMTfWY/rswgyoq9NAgWbyiObB5uE13Qn4JprpzUbs2WUTtW1Lu4pWgh5KzoQmklERIjJVX7R3Si6JnTQbMOvjMSdBjIKIopXK8QNTm2N1NITIljVYWFnN9RA2JzTVITQCUCM2hO0SkQnIg0jGtS2YpeyeJooqajFbFvKPtrNk3czpeaBFDab3VkGruJupVTRrOimz2mzzFzIMuWx2CyzNTgbgZipScrUIjV+J3EZZhrF//vUROwABVZ0wrOMMvK3DshGcYk+F7nZBA49JULuOuDZtiVwavB1qhQuv2qTKKawPoXTDRJiIlVdqy7ce2jarXEc7Oak84CRem2UZvZIk0OISk1njCJkVrDBwiSIVyEF7KqpDR4GywaJzacwAvyABudYfCImrBSVjH4faK05r9aAVSqB/aItSoelc/jltQSYRLWFIfYzpOZH4VFksLhHHQekM4gmSi4YaKqDorQoWGhAC8XwytR3rc5EirNbm/WYwzwUShPxrnNTgm+sjsnGkqxOM+xNaSsG9kpJd0lU5sRlGSiHGNTkQtKQdOEMvbVi0dQM2uuenT2Y0+6aUWgZi9pGoRGO9tqlYh9Wzi5EjaLuMJmnr0dPrXMofzvm2jskD5lyNTLJ1wBzQABEUDg5XNbCEaLsPMqZe4mTtNmn6GVxqluyOcmJXSvPFIjGYxOSiPbhl1Lkbws15BLM6SDqQCIQkBHjQ40Ai9ksjyx6Mmo9r/qHNtKtZkcez3RmXiWl5MS5DKxXK172dlC+V1JQ5rGJSvpslKruY/PMY3JNn82SbErm73FASdBPNJz0LjCOKuC5URbdOORC24QcwF5w6SUAsu02uxNkbMIyIRyIUSNNETyWVNyWTYiq+4ADEzR55MdCBUrHHwhL6MHfZWBhgWj/GTDokCewfg3LBoTC+gtC4noh3MXYVYoA9h7ET/3tOF02CqIq5RK2Flma6k3omUTSTdya7McUi14019rz2lptyhUslrpWugxzTcoZSqGNtbqZF4dl807YM2vHb1ZGrIsnmzUm1Oy8kaqIwnNEePQg5Cu6F2TolqI8ZXETeMM6Zl4VsiG0JeEjgkenE6MIG0QoCiJNYlOxMGl3u1KzjYnXfUz9pjOoyM/GcWAa9Ibr13hhk8OIFC1MyTyYfFseiSlHEoH1LjdcjXXxVQVGiJFc+QBAKoIgobNyaTncU0o7UMRtUxWQ8VLZrLUSWfO5MeUKj86NXWult9S87Vaibg/2t/cJKxW/rMqOZWWlqU8y//vUROyN1Zx1wbOGTnC2jrghcYlMFcXXBk4xKcLqOqBF1iT5FxxiMHRx/W65H36rNVRNFcs2LMIsTaWPOhBM2zXMmlCZESW5+fplSHFCsEU2yoJSbPpOx50eviAYScMlGIoo6NNpCMiQTMQgNMHwKv5xdKhQYFhoJAYhOWBEbJQyH34kiVcO0VyuFhbJC6TNCgE1ErEIaf1aoPYiSsWhLlEnnGj04VvVjcVmshbrV1jXVOdN6/TErrEUpya9p7TCTpaxBAklbGyYhNPEKdajLMQXVaNbNttJEiwsrj5QQrIGowVnZeQRoDiE40jksiKI1Vok6ImuLVry/R4GDbERUaWVkwQG4FYoRjWWUpmZyNQeDZhtCE1yUVOUao8zQgAkgAB8eoc42GSrJioIBgFNZVsqiOLX3hl3HRpaKpG5HUnHXu0kidyieeLV+aynbkw6T/Rt3t4XAfly4gQwJCZ6LNmtWR558tyxNYivu4epbH3zrkT9dabStLcQejVLxJ0CyWJEdSWmkTEJwVvOOBaR/BIBe6LadqNlJE0LWP8CCWAQOXK8YGXwzEy1RpiVbXGUT3M85LFMXH2woqiUsZW184KhL9uAsG61Zj5bJEC1uBhkf2zNsc0NIadQAGoAAM84+MUgeMRglZwTUu6BKzvEGmT/RjOsOvHh87YNpICyJobXIREOFCUCDarYWNCQ+KBWRucOFuiSvO3FLL2rjVZDdjV5K2an8i3jWwklCcW6mrbcvPanWyjjHY7OWpCdqN2jrrqeaa7VNzQRhUrfql1FBCakV4sPcp21A81U2C0S80KEb/YR4mmZQkSq0GYuXZaNHUCSDJCk9BQQKuo/OiNCXUzYHxSPa4kgNxGCbCROAkAmkNkYQy8NwDwzBZ4450NLh8lDInICpgQ6GCcpE9IcDQDiJMAqAhymxkbLMaiMCtZKS3JjTKrEGqk1cPUU7uW1H7d/wqoXdSlaadNTjPWKqlZvrPX9fJ41m1cfeyxvZ6hb+VBiMZW4hSlSmyWfZQgk//vURPEJld91QLNmZmK1bqgmdekYVgXVBS5hIErlOqBJxiU5nCokjSlKY0jclq0lIHkInqBvEEkSZtJbDpGgyDMIMnOTCqKY+YkomQkqi6obDK9Ti9owMCsvEkGGZlhFEnflNKG7EIcALIKIykXciK85FYkvOFUfCqSSuJy1YTIqCsfTtRsKk5ZBqXVDJpGawhmerVKBCQkJmVRWpaF8gtCVpPyZ/lHYQuGVlXlRhdocdk5v936j47cp2pXteSbUoqmMkZSpdOT7Sj1cVSQ4m7ZwUS3IkMYT2KS6gns/SM8oegpGSBltalm0S6lEBAyqJ9XJxYgeiOQGCIikcsHGAZgUJXiEwKSKTKEPFjxoHhsZ00xM2gkbFQkMnVx9ZAADdmEzEAOTxUyVTOfqA49Mv8/bYAYBZtIkFQoOJiUwJMBdrUVNASZSYVRGiALFW1wwQrdduUl7txjU5Z7u66nzZZcYp21/UGdkzeRipewYerFPPDtSZnIfZ8EkKKMCNaORZa7JikCTUZFdQxuDZVCuw0uNkNz8ZmjezLtvQNEqSEPImneCBpUQMQEIuo21SJuJGaMomiE/orRQWYEa7bIEE7Y4MiCHJ3kLKwoGQmAoJoWo4+YqUFAhSKzSwB/lGG5A6ZDDCNrdoq+zvxmWQ7ViFmUSeKSN2oTGYEoIraJqoOeePWWMwF5ACRQwrCJxFfJDU1sxVyv1GN61oPd4Svlfkb6SbzPyfKLUXhuZxTZua2dJI8hJLGLnNk97RIqaij1OZLAlg0wIiroRiNjuZTnSPQWejbFKQqQwgPRibKGQwmib66hxxssKDhE5mAyh+iRVEyRDQpxggUNA+bcjJQuWM8FThQUlguzhPMhFYZJNFIpFn1As/J3xfnFSufjDImbPsolFY2pBZEjKcDwwD1Ck2jEYyKnE0lMaNIiNwACxMJhwTkwBmkKvQjBV6NC0xJNA0/GbjiTVRhcYZVXClb//6Pc/3ySq/d5K4Z8kyywv81Wuw2rzifpmdyLsx7Zacpp0//vURPGJ1ed1QBO4SEC4zqgBcMmeVk3VAy5lIEqzuyBJ3SQIpaON+pqEeLV5K6wbgkSskULeOstkqIcSFbUzJM4nUf3SIEE5pNPWWXQETd2icBBggPDYDFIHViY4Kg0UadBJ0jKPaVSVaQ0gxMyRF0nCo8sSx0uQDpNieoB+Hb1oxNRlGGZ55olk21jSNAIhbrqnyDv2UAeQ6krNz4yP5LJxhDMTnOcv9u9YuM4vqMk6j6RZ/8nfdDtQqmIW7J5sJ0vGFZ8mnSeZsoYm9W7YXgzPrKnXLqoZnFT5tM4woeqhlUlQyeXTkxh4mzVQ8lCQpgHmyQgDyS47iA90bLB9BZOovRLa5KSkQkRCtGMEZiK8FEBMm+JlAAMTa2MWxGJ2AccV3Hi+VmdLKJ1xc8ucDggkhSjL9nXVyerxMP43bH7hZYN1z6oivWj11230YNnnKNM5BboKzS+zSKnS/+Tk2mDWu6K+rmLr6+3a7qPLZjHdTrezdi8UazkjrNVqxcjTWiYzIDA5qtlNVlrHmoVrj16OnSpZjqRXaJMPRmXR4OSSctOF9t5aRjJMcH7enQcHhga6U+OHzMd1XLpJFh9ePC1IhHg8oitY4ZSpVh2aMvNLSyasiSrLI/p7NIABkVTRWiJ1hYGMgTeEVMtRym+zK/DkuPoTjzi1yz9j1G0+fmNEiksvjs9iMBpzCvYowZLF1i1Ctdaw95d9n6zP1t8cU/M45XGXJ78+tbW9+v7k9HznTt4/y+0VeZQP+y1G1knrFY/unXNapTGP9F/RrobnAkramZzN2TVc2hLjlZRpcZtGjzyzrx2Pz925+iaeMDGpbXIRghtj2sZNHF54loaHKpsml4AxUqP/mDa1H5iTjkQB2WmhzqoRQIjAuH3rIaxzqYiBWCAKSpS+jMVitHZldMzEnPGDBpetV1Woqcn15YfVbfhWnUNcXs6M4EbcS9OQ10V5PajHtatDbTu5+rnLZzn454Rjn93vhO9xSe+VZHcz/ZXaSClpIrXpaCRTXJMs//vURPUN1iF2P5O6YBDCTtfyd0wAFsnVAE6xK8q+uuAFzCQJoJ9YLReag2hnabDE3CkrjQyrBAcp09J1Db2g+2bJpaXEqZMhTwPJgIhUA6WrlRSfRhiSTDGsCoxIXFbTawytIMFEYlihSbsUgEDx8QH5EKQZZhEO18UBAULEW2saUnBISpsmHPm0UMtTUxhnFGDfSYQfvbuldUN3gNyqRdqyq57ZJLXeVLIesZz5426owzP5VlMX82ccX18sSlUJS7o5X7O0zXnsGcZqFIZ1NuCTtTKNwhcuP4s2swqqIxsgYD6DICwtJCklARyKsNKIBKV1hASi1wLMis620WFKpAdXKEY6dBdOKoLYHyx5NsQuFmyQonuB8nGqKE5VADoSDIhCAUJJakAO1Xc5uETJAEhpSDTndi3caPe6KxLsHanKKrUv3bqCrkOWdNmnA0BUAYaprUIlrrMEH+HvFj1Ttk1qWuXpZHxaS/XI9RiTKEai/ajEmIUiRh+JxlsHj9OxTYhWjZu9dCtc6WP2hmtXujaXQ64SvhWIaflyI4YOejVtF9aneFfqGDlMo1K/7onmRqyjeQo0NtAR1L7Sk5RUdTn45lccDJlEHq0+Ox+MUIrRmxsW4nBKbdHYGy83aqU4fjYA7JiTXYEBxpEgExV3ndgfGll1u/nfy1BUV3nKwaxIwo9aQr0FDthzkAQJMZKIgQ3LOfjmbinTWsXpuFW14VEdqqolLS8vY1nvcnmtMQdCB43Cr1VCu1SS+lEqaXn0KkoVJGuoq9mczVxJ3oljwlwlmKzIntAJcnsjRGSjSEVNSQkomZEqFCtAk6MbKSy+iQCcomKEpEwlOCAj5MCYHkIGR5c48gcYRBojAoWFa5ZcmV0qIGR1CGLoWGHwFsiZbDVferU5WpZ3OplFZjCrYw/X8n9Vsq873LHu6a5+dvqQ/L1mS1bLWoSL4fkTIaMxMQ/20fVztwqS1rKlLVd3U/9P4rGY1MSfLnC793DhOxu5bGXpauRAhvnkDmrEvN1u//vUROyN1dR2P4uIZPSxjsgBcQmOFqHZAG6hmwMCux+B0zFw9G2jYbWsML1paQ3CW+8q+9IjY8PlkTrLB3BrxwvKMS87axLUwfbLC0wx07fQKtIeKaiGVEMpGIBcdKrofIJyVE8TDaC8bqodMAO0MoBqKCVQBL1Z1P5SyRTskSlNFgIyV0ppuzhRkoNv1KSmqJcnsO9DtVzq+qisdfu51Myc3taydgZ6V8y7P0Wf09W9LVznIK82f/L0TtrsP+ydsR9K95eXNi87ft65cTH6x85VN6yGlI18HRmBgSTpfeBMXmam5aLVSY84aHpwJEHHN7K1RNQiyVGhqHdBPUMwLQhKR1OUAdlw4HVT8vl/x7Wj2yIzJ4TIaCQOC4KxqB9YUhzLBPWrR/WtHReU9TvJnO0GYrHyWEjm4t2muymn/V6UUeF2I1dS3P2mUepbkRVNFF3sVAotYh6EpSqH3TPBwz1bShIBA6qrGW9Sba24o57u0D1qSqlljdTzl2gZ3VUOstYu1w/xAiyx6eeZmgx5LS0kYFlvbVO/zEcGnqVnkzHWHNQRdQ25kbeqGSz3DcjZT8YNXszKNctbOoEupUWhyHQnFUyRWBOs72Awtm13Y4U8ukurltiRb9NmgdyjlYyQMzx/Bmb1ywIXucgDY2OxrTQMSigrLn9galCqYiWmST9iTZiKpzOGl9OUVfXcdpZEyEiHabN3K6SKvWz/+1L2xprKtCy+zWGmTSkWsd1/aZy0eNObBWLqdB8618y/eamcL21ijrRlk9ZS1hSZCfHKlh+y9Ybl99lfSh3VlDO4rHil5UuHpDVaTGFjheMy3Ht3zBKU1BY2Y8KhKEYc0pXPRIJSCtLjBTKJWMWSMSjExZNxNEgnHxcoDARjIwYKqRo4EkRRKLyMJhmJJSieaUxNNzKZ9BRUdmJUo1hMccSpECpch17/cJe1xqq9K3B9iJf2sT6yyuIm28VD20eADNXbt/DuvrfVT31Hz/cfbOog59nHzL4afuUWNX4RmkWtub25//vUROmN1ep0vwOIfPLBzsfhdMw+Es3VBE4NZcrGOx/BwbE4Q5rptBJ6aSiBxypQkccvJo5rbhc4/cS0ac82lltVfpEldKs1LmG6RSoqbmFbzMliO5VY1KDNh5zEqTL0C+SVdmC8x0p6mxzCNKSVXZuiyv12ICUYxDzEwFQ4LkJDtc4gztuqWd7ZrEviYUTXqd1JnPrPWAPW05my9PRZkN10239tSBn9/qTSm/WGWvU0jksVYbb/yvEsrBdt6edYxmlMZ9W9DcvILsTTLJNjWWZWJ2bqLoS1fRMeNrWUOA5bXaiXYd2XFMS47nho6nOFB+dVQIVh8SSzCsPCkTyk0apj4Gpkd+6OL41XCpI2WF5kPZIMiYYLKIAOMuj0WY1gNbk1mamaWilmW6s7aw5y3av2blmhx3nrW991hjqkr9y3qu7XMMN/jQVc+4/j+/7+/3v8uMZBwdOWcMKbBpzdXOpTSyoe/sbj00/ux3Fll6SYadNC/opTIWKNKqug+SOeBuFwWtuQxm27lmTkVkjvstavRNX6tYW2GTeA3rtRTtiehI89LvUHOxQHcFW3T6OYUauFJO5MTxWVW0qsIlnOBEQ1wmox0qxFq9zOFzP1mYTlMs5aIbDJWn0mpmtI3RhnsqmY48VADnusNuGozIAWIRmMRW9ds2McedwsYZ1cb3abPXO3bne61XyvTD96q3e8dqp+XdapquVSlzwzm8c9fl+WXbCjYQBpjCpzXPaa2X0VrSuuvGSU6yH2f7D/JMhghUzgzWh+z7Igotc1nqNClKdEGqE5YUJWTlRhaSysQZQrLtnzZQLoga08hUzAiH8RdvlpjbLq5tWH7ehDS0IpvL7CQ9U5ZThqo2KA2qBxhpZjN8ud4mZuk8Ieu24tzUcDCdw9SpRq4cE4wGMXd6VdlXDShF/kAJIDWA6AKLo7i6ZJpLdOtFVFBlVVOlQVVsyjE4W2UkpMiq1IIInGOHzhskhatkqPYXoXbNUGVLPyN+kfOWPC4X//wj3KYO2tlmnn//vURPQA1mh2Potpf6DM7rfRcS/2Eb3TBsqNPspzuuABUyfgi2yomA9CP47g/YGyJnOCos2i+s7lXFhqGKSRMVsF8hBHGSZS8uGKHolk01G9iliAhihM0Vig1ojqLCQeYRF7bAzBewMQikFB6O1Rifdjc47ztlKpprWvVdZ97rrPqZbKLtSkWnUDiRWdlK/tQHyDgYpJ3QTjfCT5kmt9+1rWtvlvW9mdWQ7/B7OXMMA1+O80bMHywaFij3h1mFpHpIYX8USmcO6CU3q8s9JEIdA8BGLCg1E0sCXPSpNh5OSKLIjZ41vQdxoLIgdKc9qFCRYZNpEaFIjXJg4mARoNIUUxCPQ7uLUMVweBtpjzy2f+J8pb9FKa/a1zOi1PzOrXJf3T0up4f+FXARJfYMqr8P561JHqdiXO47BXnXczyaLfv1OviV1dqFmShx3cgln0M2bY5e1Rp9dsD66ZZO+kUoFqslVZVuNh8uFpCUYXh5u+eQVaqF0kJGKCcbxDKSJJvTkcW1+kFFB2ul49UiehLGFgkaYicYy9lxO1kM5QRXr2UmTfEYckPSMpgWZ0IIS3nuXxDT8E1N9fLxdBHah6nWrmaqCWopaOorDJK54aKaKQ5zvRiPRyeSZrLmfRlYwB1koxlgBoQESEKkpC/VXm5fr6SbtLKRSfyiZBJB2yfTrX1OTQtcZgVLIo5X6wPML0re5NWHWXPqfg+VM51xiR9u8mIThNEb7T70zvsSxo23Ksrhl9pqpiCy4VbG4UPeAqYrqLFVtWNXK+LEfLyvUqvSKi2wPmF6rnBtTiFqxcoYytizOi2VIp0scJybFBRSuBbVTFOVCE4rkE+lMRHIlSHcyqxXLJ9JUxUofrKgVauX7Mh0dKohBnIqyeKmc6I5fDkUmjuN4iGInDOo8KU0UKJkhQpSdJ4byhQocLKZ62FGuLgYRWJhUHpJxp+IEu37uVa9jvWP1sL91Dc33f/qrkonvy6hql/3U8/9+/Us/3+P3Pu/KT6cLvLnO93zuvkNua//vURP+P1t12vYOsfXDiTrewdS9uVJXXABXEgAqguuAKuJAAnnKHrqbUlMjC4xfGLUezH+VoKTs9FZldVJiywgTxJXD+lNRo0jrUwwI5s0sOo1IlyzSNFVFXF3oDJIw22kogLkI+UFKhcemXBnSBEKiEmCwrQ1M2QIiddgM0ApIbInKiI0rKZYDO2INgO0LAFWOGJykq03Mu65vv4Sr3LY+q/hj45B6eFl3wtPGrINuzOL593/58z5tLe9/2vVT6eb1Ov9h4Ly8J+9+zhs69oLhJQ9nhUrv6cWSevZaoRjGUN9nEjpmUool2FSNIoF104EMjR4F1wmXQSXw+YJQsmiFKkYkd4uE+4lRjsxc0VcOksJGyU/KbzTRMIRCGT4FyBgmDWkAaELasiyNwzYjbSgACCAAD+sITFEBDPg9DBYDzeNEzEMDRoDbTLswgF0BsfuvP5gaB4KB/cvtS02FjWUmo1Ukcbrm8Idrpqn8rSLlmTBgYGQeXOYlsxOXJVFa9E+yhhdRCwyRb2E3qfxwz7jUpy26OYGAUEXQn3MuzB8b3S15XW7YpIAsyKKQGl+xNFBCRz7dLLY2z6MSCrS0EidWHIaWog/D7/vZK59wJf17IHlD4R+JTUuhe4nGa03J3FaS7UYXogu48XL0NMU9J3wcJk66F6Mya5hRSyhai7y+3WbDLXJZRDL9pFxiihmalzmMhlau16J6RFWppbhsObaMtJddnjEoo0N3IdZHRNCYc4yY8W////////////YIpY0VukNvGsWBxoFFRkSJyC8DO5///////////+j4sInRdYO2NVrbF9k7EaGmExbeqVHtpdmJoGG5yVGBQEm3rNmPYWiwC8f6KmDYDhAO4ymctmCYOgIL4Np71Q5JDkildSVw3bxNwI62zPNyjrTpbKIcBzZoAKetzFmGOzs5T03xBfBbhIAxw5FVzynol/N3ZTgYYpdsxgC5CuEr7O6atE7kG4Sqm3Vwqw1NNHSLWuBhC8E7LHVqUz50DhRntiUSK//vUROgACgeHPa53IAFFMOegzuQAHPoc/jmXgAPJQ5/XMvAA9AEfSQQfZ267NG/gZnjMpe/NxwGkPDal7W5Q8T80kNuRPRxu7S0VFhC6Zdtc6vJCzhs6KERVjYooIsRzGTLsUyR7gBrlA6MjikJhxQNTG4vx1W4uEuSJqZrJRyV4SBIQIRLrfd+EV3OdRgTfrLUUbWFNeXLTqbLRVSSqXb///////////+mYrM6rCHshj0b0vlXlyEk2RqGu7///////////+tRW5VgQHftoML9Vj4/MIflG9HaAAACSn1zvDmjutBpW8eeZZBjld/K4MElu/ucvraQWtfivEJJEGq+fqHIAJh8hqQjqmtT798Y156KY5i3In+mL71rH+C2j0p5Djmrv61BxSNSldXp4TKrTRUx/HUy5pqktIblvEW9XeYkFfh9IvE8bydZWd9EiUiXteG7j2spbTMjRELam0kpnNFHcqEJVLFouTG8lvGc0kswsS1iRY7a9tCSbIbbOaUM4jVUafSZYRNUMJEXaJywRD1e/////////pN6aWF80VMaRMlI3K19zE/////////0rTLYFArJD8fqpCUcZ5xJcAASAAARLnpzZyztnliDTMt4bNEwyTvw3gHCOG0fFS2rkW2+N3zwEkP4AizWv3sAHDBENBsp71xTO9/GY2m45iDG7j6pjed/OtE5FtRSHGlm2tbx9Uz7fFpE82nKaLEaRpNddSVzuK1SMtLSNVsHSfrBBhtyKJUvysm3sKZm3lvbcx5Z7KhOZXcM5WpzLo/aVEi4KdP4nxJlYop1wxMDYoGJgN2hP3GSCvJ1geKBNm8hkEw1qAa0xLT3TxXnDGQlhMUto7f////////2RHnSiUNN1HLaclMhOQ2xB/////////n21OlrDsuyOMzbgSBWFiQtREAaN0j8SjSom/r90pvWa128zTXzCz7+mL+nvq/3m+/n/5+s2/1j3rfeL7tu29a9dV3773LWufSWkDOZMUe7zLNTw8PvmL4NYWG3U//vURCYBddh2Pi8N4ADA7se14bwAFqHY9gGZ/kLHOt7ANL/ZXws+0G0B5DYKN1duEBgc472WLDaX6ojq9VJWLHc4B+rhCT/jUfpNLq1DG5wkWkPOVRHKzoZVzTrknEGrDi6ISa7fQXAsKmTykVRrF8ViDhItZVBY12zlMtxjnTaFIepDHbpi0bjdZTCRrefhe1PEgAAB7xaUQ5S4Jt+daxT13nWPjH3/818KvprOKe2t+vp4Hvu9fTVP8UzrF4Fr1kxmH580gYprXlpabXpDjfFIz5wi7cnVbUwyyUhRG3Hc1fBc4Cuq1xW/zwnbUz4nVSTW3FLK5zTLHGeK4/TpmneL6+dqlazzVrXBjEpXZzqo6ni03JDwm1hcU4ZSuX2VCkOYYrjCQhjdTm5GUxkIyZGNZ0ILlgXlKrUMXY/jrGWQovRutaHF6GQYa7UpAnkM91JEdhuGUODKbJV6ydalmv6E6ZPBVIFcssNc8gSuhWHv6t6mxbmu3FupdPH18yfE2qE4sphDFWgTULOzv3sslqsjHGfPWOHR6+vuedcxHjLATr+7A/qxQGtVMiFI5naDeVDkhUzelnN2fissfqrZzkS7mi2RuVrW/Jecqw2F6ZTwLtFZEMazeZlwpiuQByLtoNJPotmTxmLoelnIPo6WszzxSpM1GO0f6mjiyHmwJkvJhuZwQHA9GjBIZ8T3bLSwiX04y+W4KRGS+T+Shu26DkH7TdLHcNDLKk4gNkrzYMTlKGMXuWy6FxdCndVKa6FBDB8+dTUMc8l0C2FH2VI2kjeE86VhobGVmgkSCRlnCYZbBU4GQDkK4KCdEYjGQ1XMzBdmfxD/Qlgcso8/G2I5oaSWyRRKrnax9Hy4J+CqZVOmMspjC4GAsncpTdD2pjIT46FYmjpUhd1KXU6zqGIXJOlijHkqk8hCbaxFEAABZ125qO7GU+52u/q+W0vw02pCykUFyExQWzT4+yyr0qhJnh7/xmdfVJMThLfLpLddMwsXn5MG5pkKJdJm0PXMKFli//vURCKHFbx2vahpf6Czjte1DY/4Fh3Y9qGl/wLQOx7ANL/YAlJo8ZUVNwJWaWqohym8qlwppHJVPVeztr26uZzswtqnbCpoChYmJhNxCHJhNBTo59tJj+PVROTGlNMR+lOzoahyZSpOnA0D8Qo8zIVqWP81ECdq0WJD8oczJk7RayGl8L4sl1Qw1T2NBPn4TVPkkPyPgUUAVQWxhFVCC2qE+Vob2DOWREjxtmDD6pHU8jvut0Y18jS5Y5G0Xvzvrszlcr/Td/LZC+41TmZe2Lshq3ToY7Ru/TDqsSZCOla3R6cNMJJdSRyZNqVyhaS+HlgxZacwiHCI94Dbp766RtFY0RnD4FDstAwK4fIAlmohkgcS4dRpEaORnqZqeRqPcDIQtQp9oOgxE4fh1E6ShdFajCak+0kJ08riVqclIdb54fRXlgJA/usUCaw3MQuZgGPFERHN0zeEWsMhzeAtPz2v33Bw2kd0I+PX7tptVJ3m+s+zyCn+f/LlkzqZ6aR6aktWdiZLKaUESHS6ZOkFDDBaSfJiMUi4MaTsGgd5GA5QqMtiSKECBGaKBSgGJxU4TLAcBD1AfAc4Iz4IUCBGnk1BxEBAFIQwh6jTbKharMxQkifrR2sp1HIPJHKgYi5FzXY3EbZoFviQkwXEqlEc6XN9UH8ezGZZlp9+XVN/J5R4JPDJ7EdPYUJiELWy4RzG3KZ9UmAyfO00IodzjbZkXp9SuUviqsaxpuNTXqzuan+0amYim6j6KSxLRh7U9mIEiTHHrIxY80SESMiZMHzAUOmTQcQLisRiMCaAowIDxCBJaEgGyRjTCWOgwzUcE6qEexbOlfbFtyTDAmEUUKsalRHiZgGC3Jk7iyJeZK2q1UXA8XOKcMrlRHmSf66VKGPnSeIEQ84Uau0LUYbKrb0slBkCvrEK02KnSypg82IdMzKQoWklh9yPzKFkmq5HGuxaIdd8zO+O2/WqZd9yzNmHmJkNhmlTUNx9AAwtAwccUMTWYDC0gdou+jP2Wre/cZFY//vURCiPNVR2vgBmf6CrzsfFDS/2FWXU+AGZ/oqwul8UMb54hSoUkS012dD7QJ25LwVZEgvVcd888qLL4hTnp4yKyKvNqsIUlXAuvOJkfmvFUBP06nIiIXZoKZmTrSWxIsJO2bEElTMgk2eLkfyiaE0dLMiU8f9CvRSba4uQiAASuZwyzaEweMb8aZl2esvJPC+qO+wPgbXky+irenl+YvnlWf3O+veV/41tR1umzdfGGb2bJgizKZhCBPjuVaJ1Fm4HI0dQMqKMI0ZsVyWLAyep4pD2CATEsSAVrkrqNfKZU23yqMZSs62T9Lwl0aCFLV1HHPhCoiJS6ORQ3lMrTlertTF7R6PZjNLw4oe3HE5Jou6jbzpM5Do7wtynXnCCq0Ygi4RJCtSWlFanNrfLxRTdM60R3QNnEUiz+RdTY/c1mZ5/bPkM2I3JXhbbDbV+c7Lg9lTnfIxKYc2jNGQRYw0GdMpFACTovQgLBkXMSeVbiQ6QrzSMalQCrWFh/AjLCpbWddpJyfKhRqlWRnMsTMujwVqQyjm49tKWdVsicSTYfjpbndKtRlgUqPVymP5kUxtua7IfHdDwTDiYB6msS9OxSCnpELkm0NKo4XcZUsysWmq6wEKsUaErDH5ragQ8qYupGPdJUUluMxexK3yr/sR/S+SmfKOWXPoSsZjpkfTUfD0sPXCBtlFtD1JHh11dkeKzMeJPSLujm9ZlhiftSTb23PiPnGE9iwdNcza/uxKlCleekeHdyaESrl2+s0w08xIpER0MPWErVAoEahSclNBLI/BfkqhJeXEvZplghLs+EGrm5XsKPWiAMaSL0SSj9NmAsCTp1CkgeCjUzGtqycoAwAAAOo5ZiwdpnHfiMUJPD+TKcjuNHNEpCgb6R14ea+eWl9yrLDyKlGQ+PaFVx3xxIhEVA8GCEwIJb0LVjt08oyhUhSLrS/WIqH5Pnb4/FRbpfjREzqrlKl4wVFI805SqnXXbE1Ohq1hMMj4gnZuVIxwPVxEP2kAzM17aZlCO//vURD+B9Ih2P0AjZ6CTztfgBEzyE4HY/KGFlwJtOt9AEbOQg9VGoMhENFy0sUE8sE4eyYsjmIwSGA5JyNEZM0OQ5AM/WAfg/wWjZzKjM4gJUtzOXZ3K02bVGLGocSwKSEJrH7diG9rV1VHHZxbtmaU/8ZgTwJeoVGWXW3UplYl3MKLFNY5gVNnUrS+0gnpMdgOi2mFDlFJdjQjpOVPUCSrXJA3OXUVRwVnIiPHg8GNlI+HaCchiyBoohMUxBO3Vxf8tDErCUVXneCYJ/TLI7NdihMY995PpXPBDrC2kRtkdAttEZusn0CQhmTwgCbaSutJ23/enVvSXqbuod7S/Sjh97sW2etRjYnoJ5bVM+trV9Oo7YVjvydFNI5hBPl1NSWRnrEBNJyQSambR8O9i8dHD6ShWUlhdx8UycfnrZaVlAjm4/iEV2h4NTIumA6DsIZ8SIAkPIR2lcS0cJZIJeKpyeiwuWpEMRl22bMxzMK7YwGT8PZmpQGZ8+z0OcyunOZx0OtZsqZ8So0lgVRU6oMHO1XqPSwxtfjhIq8u2Y9SeOHlHlh86+pQG4GC6Yb5+22rPUq5QkWssoTZdNxKJ5+cEhponG8rkNRhGJ5ePDp0mJSXUEy+6RTQqFwlkUioJPJw6AMQysTwTEJOTCWBw5Lg96IBeOm7A2EAdRJVCyI4c/I0hGsmpgGghWivh/Vayr61j4fSJW7z630tvPuv9Mm+Hsuurep9KpVIE8xRHjyVi7DfQ93XpCxD06VXFp0c25KXImWtt2xPoyyfGLDy20DpyXC01GtmWRJPTFkfT5hWZEpVUrH5isOyGRSqhLlY8C6g9F8Ti27ZMqCVVghD2FJAH5w+hw5OnzkpFcpF4u0JJNHo/Doln6mFGXEic8u5o4ZhUNvJz7LD4Rll/2ft/w1L8+Xpepylt0oaxWzgziTVAwrzLqPy1ntavFdM3CmXP0v1HmUJG1G17Jy9XHkJ+l1y6utQlZuBdlTp5lplcczKY+bLx+6mPVYUpn4Gy8QwP//vURH+NlLp2PgAjZPCWztfABGyeEoHU2CCNPIpUulsgIzPZH1VpkSSUZFcdoSaSj1ccuAkhCEHYQiUmNjmy2BtcSVy0kkAeFYTKxBIA5lA7fg+G4n5hALCRGjDiCaohYshCZ8hTUMjJovKfQFVsMmZjWkvkzN/tUbWAxNIVQwIcjUMaxWaWliaNhVwiRqNueyiEJcdXDKIqwmwWJvJXIkSapxcym5ohLJLnmpSlIVQ2DYZSTSOzOCqbpmQDB8ZEANHg0FRpcaA4XUNBVh7MiJtkqJUVogVIyQTRRFYTdmkoLHygmQwVJANe61XysyU6O3y2MFOys8ylN/VW9jKrW5lW8xv/Mm5s1VfXzWJGnChzJdq52PladuHNZGUTnzadi8LCSQkDIDsSNyqlkgUxOAoFEiEyA5EkaKVpGBuKMSS8kXuCUhrCclcsOJ4jdXFUmuwrUz6IyOSsPJ2XCiJJefYVGJykXnpzR64gqisbLBGKqa4dGCCTSU/A243VTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV';
        const PROCESSED_FLAG = 'data-kv-processed';
        const COOLDOWN = 3000;
        let lastTriggered = 0;
        let swoosh = null;

        function preloadSound() {
            swoosh = new Audio(SOUND_URL);
            swoosh.volume = 1.0;
            swoosh.load();
        }
        preloadSound();

        function playSound() {
            try {
                if (!swoosh) preloadSound();
                const audio = swoosh.cloneNode();
                audio.volume = 1.0;
                audio.play().catch(() => {});
            } catch {}
        }

        function showIcon() {
            const id = 'kv-done-icon';
            if (document.getElementById(id)) return;

            const icon = document.createElement('i');
            icon.id = id;
            icon.className = 'fas fa-check';
            Object.assign(icon.style, {
                position: 'absolute',
                top: '50%',
                left: '17%',
                transform: 'translate(-50%, -50%) scale(5.5)',
                fontSize: '190px',
                color: '#00c853',
                opacity: '0',
                zIndex: '99999',
                pointerEvents: 'none',
                transition: 'opacity 0.3s ease, transform 0.3s ease'
            });

            const container = document.querySelector('.cart-container') || document.body;
            if (getComputedStyle(container).position === 'static') {
                container.style.position = 'relative';
            }
            container.appendChild(icon);

            requestAnimationFrame(() => {
                icon.style.opacity = '1';
                icon.style.transform = 'translate(-50%, -50%) scale(1.0)';
            });

            setTimeout(() => {
                icon.style.opacity = '0';
                icon.style.transform = 'translate(-50%, -50%) scale(0.7)';
                setTimeout(() => icon.remove(), 500);
            }, 1200);
        }

        function triggerEffect() {
            const now = Date.now();
            if (now - lastTriggered < COOLDOWN) return;
            lastTriggered = now;
            playSound();
            showIcon();
        }

        function hideToast(el) {
            try {
                if (!el || el.getAttribute(PROCESSED_FLAG) === '1') return;
                el.setAttribute(PROCESSED_FLAG, '1');
                el.style.opacity = '0';
                el.style.transition = 'opacity 0.3s ease';
                setTimeout(() => el.remove(), 300);
            } catch {}
        }

        function looksLikeSuccess(text) {
            const txt = text.toLowerCase();
            const keys = [
                'hoàn tất đơn',
                'lưu thành công',
                'thành công',
                'hóa đơn được cập nhật thành công',
                'tạo đơn thành công'
            ];
            return keys.some(k => txt.includes(k));
        }

        function inspectNode(node) {
            if (!node) return;
            const txt = (node.innerText || node.textContent || '').trim();
            if (!txt) return;

            const isToastLike =
                node.matches?.('.toast, .toast-message, .ant-notification, [role="alert"]') ||
                node.closest?.('.toast, .toast-message, .ant-notification, [role="alert"]');

            if (isToastLike && looksLikeSuccess(txt)) {
                hideToast(node);
                triggerEffect();
            }
        }

        const observer = new MutationObserver(mutations => {
            for (const m of mutations) {
                for (const node of m.addedNodes) {
                    inspectNode(node);
                    if (node.querySelectorAll) {
                        node.querySelectorAll('.toast, .toast-message, .ant-notification, [role="alert"]').forEach(el => {
                            if (!el.getAttribute(PROCESSED_FLAG) && looksLikeSuccess(el.textContent || '')) {
                                hideToast(el);
                                triggerEffect();
                            }
                        });
                    }
                }
            }
        });
        observer.observe(document.body, { childList: true, subtree: true });

        setInterval(() => {
            document.querySelectorAll('.toast, .toast-message, .ant-notification, [role="alert"]').forEach(el => {
                if (looksLikeSuccess(el.textContent || '')) hideToast(el);
            });
        }, 1500);
    })();

/*** ======= GIANT CART NUMBER USING FONT AWESOME (DOT VISUALLY BASED) ======= ***/
(function() {
    const GIANT_ID = 'kv-giant-number';
    const container = document.querySelector('.cart-container') || document.body;
    if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
    }

    const giantNumber = document.createElement('div');
    giantNumber.id = GIANT_ID;
    Object.assign(giantNumber.style, {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        fontSize: '370px',
        fontWeight: '900',
        color: '#000',
        opacity: '0.09',
        pointerEvents: 'none',
        zIndex: '99998',
        fontFamily: `'Inter','Segoe UI','Helvetica Neue',Arial,sans-serif`,
        userSelect: 'none',
        textAlign: 'center',
        whiteSpace: 'nowrap',
        lineHeight: '1', // ensures proper vertical alignment
    });

    const charToFA = {
        '0': 'fa-0',
        '1': 'fa-1',
        '2': 'fa-2',
        '3': 'fa-3',
        '4': 'fa-4',
        '5': 'fa-5',
        '6': 'fa-6',
        '7': 'fa-7',
        '8': 'fa-8',
        '9': 'fa-9',
        '.': 'fa-circle'
    };

    function updateGiantNumber() {
        const span = document.querySelector('span.text-bg-default');
        const cart = span ? span.textContent.replace(/[^\d.]/g, '') || '0' : '0';
        giantNumber.innerHTML = '';

        const chars = String(cart).split('');
        chars.forEach(c => {
            const icon = document.createElement('i');
            if (!charToFA[c]) return;

            icon.className = `fa-solid ${charToFA[c]}`;
            icon.style.display = 'inline-block';

            if (c === '.') {
                // small dot visually aligned with digit feet
                icon.style.fontSize = '0.15em';
                icon.style.verticalAlign = 'bottom';
                icon.style.position = 'relative';
                icon.style.top = '-0.15em'; // nudge upward to match digit base
                icon.style.margin = '0 0.15em';
            } else {
                icon.style.margin = '0 0.1em';
            }

            giantNumber.appendChild(icon);
        });
    }

    const waitInterval = setInterval(() => {
        const box = document.querySelector('.cart-container');
        if (box && box.offsetParent !== null) {
            clearInterval(waitInterval);
            box.appendChild(giantNumber);
            updateGiantNumber();
            setInterval(updateGiantNumber, 1000);
            window.addEventListener('resize', updateGiantNumber);
        }
    }, 200);
})();

// change Thanh Toan button color (RE-BIND SAFE VERSION)
(function syncButtonStyle() {
    const box = document.getElementById('sale-info-box');
    if (!box) return;

function updateButtonStyle(btn) {
    const s = box.style;
    btn.style.background = s.background;
    btn.style.color = s.color;
    btn.style.border = s.border;
    btn.style.boxShadow = s.boxShadow;

    // NEW: mirror faded/grayscale effect when cart = 0
    btn.style.filter = s.filter || 'none';
    btn.style.opacity = s.opacity || '1';
}


    function bindButton(btn) {
        if (btn.dataset.kvBound === "1") return; // prevent double bind
        btn.dataset.kvBound = "1";

        updateButtonStyle(btn);

        // Auto-update style when monitor box changes
        const observer = new MutationObserver(() => updateButtonStyle(btn));
        observer.observe(box, { attributes: true, attributeFilter: ['style'] });

        // Frequent refresh to keep perfect sync
        const int = setInterval(() => {
            if (!document.body.contains(btn)) {
                clearInterval(int);
                btn.dataset.kvBound = "0";
                return;
            }
            updateButtonStyle(btn);
        }, 60);
    }

    // Watch for DOM changes that recreate the button
    const domObserver = new MutationObserver(() => {
        const btn = document.querySelector('#saveTransaction');
        if (btn) bindButton(btn);
    });

    domObserver.observe(document.body, { childList: true, subtree: true });

    // First run
    const firstBtn = document.querySelector('#saveTransaction');
    if (firstBtn) bindButton(firstBtn);
})();

/* ==============================
   TOPLINE FOR ĐẶT HÀNG MODE ONLY
   ============================== */

// detect Đặt hàng mode
function isDatHangMode() {
    return !!document.getElementById('saveOrder');
}

// đọc số "Khách cần trả"
function getKhachCanTra() {
    const el = document.querySelector('.amount-pay');
    if (!el) return null;
    const num = el.textContent.replace(/[^\d]/g, '');
    return parseInt(num || '0', 10);
}

// tính số tiền cần để làm tròn lên bậc 500k
function calcNeedToRoundUp(amount) {
    const step = 500000; // 500k, 1tr, 1tr5, 2tr...
    const target = Math.ceil(amount / step) * step;
    return target - amount;
}

// tạo topline riêng cho Đặt hàng
const topLineDatHang = document.createElement('div');
Object.assign(topLineDatHang.style, {
    position: 'fixed',
    zIndex: 9999,
    fontSize: '20px',
    fontWeight: '600',
    color: '#d4380d',
    background: 'rgba(255,255,255,0.9)',
    padding: '37px 109px',
    borderRadius: '4px',
    opacity: '0',
    transition: 'opacity 0.5s ease, transform 0.3s ease',
    pointerEvents: 'none',
    bottom: '31%',
    right: '0.8%'
});
document.body.appendChild(topLineDatHang);

// interval update
setInterval(() => {

    // nếu không ở ĐẶT HÀNG → ẩn
    if (!isDatHangMode()) {
        topLineDatHang.style.opacity = '0';
        return;
    }

    // nếu payment không phải tiền mặt → ẩn
    const rawPayment = document.querySelector('.form-check-methods input.form-check-input:checked')
        ?.closest('label')
        ?.querySelector('.text-check span')
        ?.textContent.trim().toLowerCase() || '';

    if (rawPayment !== 'tiền mặt') {
        topLineDatHang.style.opacity = '0';
        return;
    }

    const need = calcNeedToRoundUp(getKhachCanTra() || 0);

    topLineDatHang.textContent = `tiền thối cần chuẩn bị = ${need.toLocaleString()}đ`;
    topLineDatHang.style.opacity = '1';

}, 1000);

})();